// Generated from web/src/games.js by npm run web.
"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  (() => {
    const C = ["#83cfff", "#ffb685"], clamp = (v, a, b) => Math.max(a, Math.min(b, v)), dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y), TAU = Math.PI * 2;
    const defs = [
      ["prism", "Prism Breaker", "PHÁ GẠCH", "#84d5fa", "Phá ba lớp gạch bằng bóng và vợt năng lượng.", "JOY1 X: vợt · R: thả bóng · L: vợt rộng"],
      ["orbit", "Orbital Catch", "PHẢN XẠ", "#bbadff", "Xoay lá chắn để thu 20 tín hiệu từ quỹ đạo.", "JOY1 X: xoay · L: xoay chậm · R: khiên rộng"],
      ["crosswalk", "Crosswalk", "VƯỢT CHƯỚNG NGẠI", "#a5e69e", "Vượt sáu làn xe và đến ba điểm an toàn.", "JOY1: di chuyển theo ô"],
      ["colors", "Color Dock", "PHÂN LOẠI", "#ffa2d2", "Hứng đúng màu, tránh màu khác. Thu 20 khối.", "JOY1 X: di chuyển · L/R: đổi màu"],
      ["lander", "Lunar Lander", "ĐÁP TÀU", "#bed3ed", "Hạ cánh nhẹ lên bệ trước khi hết nhiên liệu.", "JOY1 X: lực ngang · R: đẩy lên · L: phanh"],
      ["mines", "Mine Survey", "DÒ MÌN", "#e4c689", "Đánh dấu 12 quả mìn và mở các ô an toàn.", "JOY1: chọn ô · R/SW1: mở · L: cắm cờ"],
      ["memory", "Memory Circuit", "TRÍ NHỚ", "#d0adf4", "Tìm tám cặp ký hiệu giống nhau. Có hai lượt xem nhanh.", "JOY1: chọn ô · R/SW1: lật · L: xem nhanh"],
      ["warehouse", "Warehouse Grid", "ĐẨY THÙNG", "#e8b991", "Đẩy ba thùng đến các vị trí đánh dấu.", "JOY1: đi/đẩy · L: hoàn tác · R: làm lại"],
      ["bubbles", "Bubble Harbor", "BẮN BÓNG", "#9fe3dd", "Nối ba bóng cùng màu, dọn sạch bến cảng.", "JOY1 X: ngắm · R/SW1: bắn"],
      ["courier", "Sky Courier", "GIAO HÀNG", "#efc576", "Thả tám kiện hàng vào xe nhận, tránh drone.", "JOY1: bay · R/SW1: thả hàng"],
      ["hockey", "Paddle Clash", "ĐỐI KHÁNG", "#83cfff", "Hai nửa sân, hai vợt. Ghi năm bàn để thắng.", "P1 JOY1/SW1/L · P2 JOY2/SW2/R", 2],
      ["duel", "Arena Duel", "ĐẤU TAY ĐÔI", "#ffa993", "Né đạn và bắn theo hướng di chuyển. Mỗi người có 5 máu.", "SW1/SW2: bắn · L/R: khiên · hai JOY: đi", 2],
      ["coins", "Coin Sprint", "TRANH ĐIỂM", "#f2d983", "Tranh 20 đồng xu hoặc dẫn điểm sau 60 giây.", "SW1/SW2: lướt · L/R: xung đẩy · hai JOY: đi", 2],
      ["trails", "Trail Riders", "ĐUA VỆT SÁNG", "#a5a4ff", "Tránh vệt sáng của cả hai xe. Thắng ba vòng.", "JOY: rẽ · SW1/SW2: tăng tốc · L/R: nhảy vệt", 2],
      ["rescue", "Rescue Partners", "PHỐI HỢP", "#9ad9b1", "Mỗi người đưa ba kiện cứu hộ về bệ của mình. Chung 3 mạng.", "SW1/SW2: nhặt/thả · L/R: khiên · hai JOY: đi", 2]
    ];
    function box(c, x, y, w, h, color, r = 6) {
      c.fillStyle = color;
      c.beginPath();
      c.roundRect(x, y, w, h, r);
      c.fill();
    }
    function dot(c, x, y, r, color) {
      c.fillStyle = color;
      c.beginPath();
      c.arc(x, y, Math.max(0, r), 0, TAU);
      c.fill();
    }
    function text(c, s, x, y, n = 16, color = "#c4d6e8", align = "center") {
      c.fillStyle = color;
      c.font = "600 ".concat(n, "px system-ui,sans-serif");
      c.textAlign = align;
      c.fillText(s, x, y);
    }
    function move(p, ax, ay, s, dt, min = 22, max = 778) {
      const n = Math.max(1, Math.hypot(ax, ay));
      p.x = clamp(p.x + ax / n * s * dt, min, max);
      p.y = clamp(p.y + ay / n * s * dt, 48, 418);
      if (Math.hypot(ax, ay) > 0.25) {
        p.dx = ax / n;
        p.dy = ay / n;
      }
    }
    class Extra {
      constructor(id, rand) {
        this.id = id;
        this.rand = rand;
        this.t = 0;
        this.nav = 0;
        this.lastDir = -1;
        this.items = [];
        this.players = [{ x: 180, y: 225, dx: 1, dy: 0, hp: 5, score: 0, cd: 0, shield: 0, hurt: 0, boost: 0, carrying: -1 }, { x: 620, y: 225, dx: -1, dy: 0, hp: 5, score: 0, cd: 0, shield: 0, hurt: 0, boost: 0, carrying: -1 }];
        if (id === 11) {
          this.paddle = 400;
          this.ball = { x: 400, y: 386, vx: 160, vy: -245 };
          this.attached = true;
          this.stage = 1;
          this.bricks();
        }
        if (id === 12) {
          this.angle = -Math.PI / 2;
          this.spawn = 0;
          this.caught = 0;
          this.wide = 0;
        }
        if (id === 13) {
          this.x = 6;
          this.y = 9;
          this.goals = 0;
          for (let lane = 2; lane <= 7; lane++) for (let k = 0; k < 3; k++) this.items.push({ x: k * 300 + this.rand() * 60, y: lane, speed: (lane % 2 ? 1 : -1) * (65 + lane * 12) });
        }
        if (id === 14) {
          this.x = 400;
          this.color = 0;
          this.spawn = 0;
          this.caught = 0;
        }
        if (id === 15) this.resetLander();
        if (id === 16) {
          this.cx = 0;
          this.cy = 0;
          this.cells = Array.from({ length: 80 }, () => ({ mine: false, open: false, flag: false, n: 0 }));
          this.placed = false;
        }
        if (id === 17) {
          this.cx = 0;
          this.cy = 0;
          this.cards = Array.from({ length: 16 }, (_, n) => ({ value: n % 8, open: false, done: false }));
          for (let n = 15; n > 0; n--) {
            const k = Math.floor(this.rand() * (n + 1));
            [this.cards[n], this.cards[k]] = [this.cards[k], this.cards[n]];
          }
          this.flips = [];
          this.hide = 0;
          this.peek = 0;
          this.peeks = 2;
          this.moves = 0;
        }
        if (id === 18) {
          this.undo = [];
          this.resetWarehouse();
        }
        if (id === 19) {
          this.grid = Array.from({ length: 7 }, (_, y) => Array.from({ length: 12 }, () => y < 3 ? 1 + Math.floor(this.rand() * 3) : 0));
          this.angle = -Math.PI / 2;
          this.next = 1 + Math.floor(this.rand() * 3);
          this.bubble = null;
          this.misses = 0;
        }
        if (id === 20) {
          this.x = 150;
          this.y = 130;
          this.parcels = [];
          this.truck = 630;
          this.delivered = 0;
          this.spawn = 0;
          this.drop = 0;
        }
        if (id === 21) {
          this.ball = { x: 400, y: 225, vx: 130, vy: 65 };
          this.goalPause = 0;
        }
        if (id === 22) this.bullets = [];
        if (id === 23) {
          this.items = Array.from({ length: 9 }, () => this.coin());
        }
        if (id === 24) {
          this.roundPause = 0;
          this.setupTrails();
        }
        if (id === 25) {
          this.items = Array.from({ length: 6 }, (_, j) => ({ x: 280 + j % 3 * 120, y: 110 + Math.floor(j / 3) * 200, owner: -1, done: false }));
          this.hazards = Array.from({ length: 4 }, (_, j) => ({ x: 100 + j * 200, y: 145 + j % 2 * 160, vx: j % 2 ? 100 : -100 }));
        }
      }
      coin() {
        return { x: 60 + this.rand() * 680, y: 65 + this.rand() * 340 };
      }
      direction(i) {
        let x = i.a[0], y = i.a[1];
        return Math.max(Math.abs(x), Math.abs(y)) < 0.45 ? -1 : Math.abs(x) > Math.abs(y) ? x > 0 ? 0 : 2 : y > 0 ? 1 : 3;
      }
      navStep(dt, i, fn) {
        const d = this.direction(i);
        this.nav -= dt;
        if (d < 0) {
          this.lastDir = -1;
          return;
        }
        if (d !== this.lastDir || this.nav <= 0) {
          fn(d);
          this.nav = d !== this.lastDir ? 0.27 : 0.14;
          this.lastDir = d;
        }
      }
      selectGrid(dt, i, w, h) {
        this.navStep(dt, i, (d) => {
          this.cx = clamp(this.cx + [1, 0, -1, 0][d], 0, w - 1);
          this.cy = clamp(this.cy + [0, 1, 0, -1][d], 0, h - 1);
        });
      }
      bricks() {
        this.items = [];
        for (let y = 0; y < 4; y++) for (let x = 0; x < 10; x++) this.items.push({ x: 55 + x * 70, y: 60 + y * 30, on: true, hp: y === 0 && this.stage > 1 ? 2 : 1 });
      }
      resetLander() {
        this.x = 120;
        this.y = 90;
        this.vx = 20;
        this.vy = 0;
        this.fuel = 100;
        this.pad = 470 + this.rand() * 150;
      }
      resetWarehouse() {
        this.x = 4;
        this.y = 5;
        this.crates = [{ x: 3, y: 3 }, { x: 5, y: 3 }, { x: 4, y: 4 }];
        this.targets = [{ x: 2, y: 1 }, { x: 4, y: 1 }, { x: 6, y: 1 }];
        this.undo = [];
      }
      wall(x, y) {
        return x <= 0 || x >= 8 || y <= 0 || y >= 6 || y === 3 && (x === 2 || x === 6);
      }
      setupTrails() {
        this.trails = Array.from({ length: 18 }, () => Array(36).fill(0));
        this.riders = [{ x: 6, y: 9, dir: 0, want: 0, jumps: 3 }, { x: 29, y: 9, dir: 2, want: 2, jumps: 3 }];
        this.trails[9][6] = 1;
        this.trails[9][29] = 2;
        this.tick = [0, 0];
        this.jumpPending = [false, false];
      }
      winner(g) {
        let [a, b] = this.players;
        g.score = Math.max(a.score, b.score);
        g.end(true, a.score === b.score ? "HÒA!" : a.score > b.score ? "PLAYER 1 THẮNG!" : "PLAYER 2 THẮNG!");
      }
      lose(g, x, y) {
        g.lives--;
        g.burst(x, y, "#ffa7a7");
        g.sound("hit");
        if (g.lives <= 0) g.end(false, "HẾT LƯỢT!");
      }
      step(g, dt, i) {
        this.t += dt;
        const id = this.id;
        if (id === 11) {
          this.paddle = clamp(this.paddle + i.a[0] * 420 * dt, 65, 735);
          const b = this.ball, half = i.b & 1 ? 65 : 43;
          if (this.attached) {
            b.x = this.paddle;
            b.y = 385;
            if (i.p & 6) this.attached = false;
          } else {
            b.x += b.vx * dt;
            b.y += b.vy * dt;
            if (b.x < 12 || b.x > 788) {
              b.x = clamp(b.x, 12, 788);
              b.vx *= -1;
            }
            if (b.y < 20) {
              b.y = 20;
              b.vy = Math.abs(b.vy);
            }
            if (b.vy > 0 && b.y >= 380 && b.y <= 408 && Math.abs(b.x - this.paddle) < half + 9) {
              b.y = 379;
              b.vx = (b.x - this.paddle) * 5;
              b.vy = -Math.sqrt(Math.max(18e3, 95e3 - b.vx * b.vx));
              g.sound("coin");
            }
            for (const a of this.items) if (a.on && b.x > a.x - 8 && b.x < a.x + 64 && b.y > a.y - 8 && b.y < a.y + 28) {
              a.hp--;
              if (!a.hp) {
                a.on = false;
                g.score += 10;
                g.burst(b.x, b.y, "#83cfff", 6);
              }
              b.vy *= -1;
              b.y += Math.sign(b.vy) * 6;
              break;
            }
            if (b.y > 460) {
              this.lose(g, b.x, 430);
              this.attached = true;
            }
            if (!this.items.some((a) => a.on)) {
              if (++this.stage > 3) g.end(true);
              else {
                this.bricks();
                this.attached = true;
              }
            }
          }
        }
        if (id === 12) {
          this.angle += i.a[0] * (i.b & 1 ? 1.3 : 3) * dt;
          this.wide = Math.max(0, this.wide - dt);
          if (i.p & 2 && g.cool <= 0) {
            this.wide = 0.9;
            g.cool = 3;
          }
          this.spawn -= dt;
          if (this.spawn <= 0) {
            this.spawn = 0.95;
            this.items.push({ a: this.rand() * TAU, r: 240, dead: false });
          }
          for (const a of this.items) {
            a.r -= 85 * dt;
            if (a.r <= 150 && !a.dead) {
              a.dead = true;
              let delta = Math.atan2(Math.sin(a.a - this.angle), Math.cos(a.a - this.angle));
              if (Math.abs(delta) < (this.wide ? 0.7 : 0.32)) {
                this.caught++;
                g.score += 25;
                g.sound("coin");
                if (this.caught >= 20) g.end(true);
              } else this.lose(g, 400 + Math.cos(a.a) * 150, 225 + Math.sin(a.a) * 150);
            }
          }
          this.items = this.items.filter((a) => !a.dead);
        }
        if (id === 13) {
          this.navStep(dt, i, (d) => {
            this.x = clamp(this.x + [1, 0, -1, 0][d], 0, 15);
            this.y = clamp(this.y + [0, 1, 0, -1][d], 0, 9);
          });
          for (const a of this.items) {
            a.x += a.speed * dt;
            if (a.x > 880) a.x = -100;
            if (a.x < -110) a.x = 880;
          }
          if (!g.hurt && this.items.some((a) => a.y === this.y && Math.abs(a.x - (40 + this.x * 48)) < 47)) {
            this.lose(g, 40 + this.x * 48, 35 + this.y * 40);
            this.x = 6;
            this.y = 9;
            g.hurt = 1;
          }
          if (this.y === 0) {
            this.goals++;
            g.score += 100;
            this.x = 6;
            this.y = 9;
            g.sound("coin");
            if (this.goals >= 3) g.end(true);
          }
        }
        if (id === 14) {
          this.x = clamp(this.x + i.a[0] * 350 * dt, 35, 765);
          if (i.p & 1) this.color = (this.color + 2) % 3;
          if (i.p & 2) this.color = (this.color + 1) % 3;
          this.spawn -= dt;
          if (this.spawn <= 0) {
            this.spawn = 0.62;
            this.items.push({ x: 40 + this.rand() * 720, y: 20, color: Math.floor(this.rand() * 3), dead: false });
          }
          for (const a of this.items) {
            a.y += 145 * dt;
            if (a.y > 380 && a.y < 410 && Math.abs(a.x - this.x) < 45 && !a.dead) {
              a.dead = true;
              if (a.color === this.color) {
                this.caught++;
                g.score += 20;
                g.sound("coin");
              } else this.lose(g, this.x, 390);
            }
            if (a.y > 465) a.dead = true;
          }
          this.items = this.items.filter((a) => !a.dead);
          if (this.caught >= 20) g.end(true);
          if (this.t > 90) g.end(false, "HẾT GIỜ!");
        }
        if (id === 15) {
          if (this.fuel > 0) {
            this.vx += i.a[0] * 45 * dt;
            this.fuel = Math.max(0, this.fuel - Math.abs(i.a[0]) * 2 * dt);
            if (i.b & 2) {
              this.vy -= 88 * dt;
              this.fuel = Math.max(0, this.fuel - 10 * dt);
            }
            if (i.b & 1) {
              this.vx *= Math.pow(0.4, dt);
              this.vy *= Math.pow(0.6, dt);
              this.fuel = Math.max(0, this.fuel - 7 * dt);
            }
          }
          this.vy += 34 * dt;
          this.x += this.vx * dt;
          this.y += this.vy * dt;
          if (this.x < 15 || this.x > 785) {
            this.x = clamp(this.x, 15, 785);
            this.vx *= -0.4;
          }
          if (this.y < 25) {
            this.y = 25;
            this.vy = Math.abs(this.vy);
          }
          if (this.y >= 385) {
            if (Math.abs(this.x - this.pad) < 49 && Math.abs(this.vx) < 25 && Math.abs(this.vy) < 45) {
              g.score = 500 + Math.round(this.fuel * 5);
              g.end(true, "HẠ CÁNH THÀNH CÔNG!");
            } else {
              this.lose(g, this.x, 390);
              this.resetLander();
            }
          }
        }
        if (id === 16) {
          this.selectGrid(dt, i, 10, 8);
          const at = this.cy * 10 + this.cx, c = this.cells[at];
          if (i.p & 1 && !c.open) c.flag = !c.flag;
          if (i.p & 6 && !c.flag && !c.open) {
            if (!this.placed) {
              this.placed = true;
              let choices = [];
              for (let n = 0; n < 80; n++) if (Math.abs(n % 10 - this.cx) > 1 || Math.abs(Math.floor(n / 10) - this.cy) > 1) choices.push(n);
              for (let k = 0; k < 12; k++) {
                let j = Math.floor(this.rand() * choices.length);
                this.cells[choices.splice(j, 1)[0]].mine = true;
              }
              this.cells.forEach((v, n) => v.n = this.neighbors(n).filter((k) => this.cells[k].mine).length);
            }
            if (c.mine) {
              c.open = true;
              g.lives = 0;
              g.end(false, "CHẠM MÌN!");
            } else {
              let queue = [at], seen = /* @__PURE__ */ new Set();
              while (queue.length) {
                let n = queue.pop(), v = this.cells[n];
                if (seen.has(n) || v.flag || v.mine) continue;
                seen.add(n);
                v.open = true;
                if (!v.n) queue.push(...this.neighbors(n));
              }
              g.score = this.cells.filter((v) => v.open).length * 10;
              if (this.cells.filter((v) => v.open && !v.mine).length === 68) g.end(true);
            }
          }
        }
        if (id === 17) {
          this.selectGrid(dt, i, 4, 4);
          this.peek = Math.max(0, this.peek - dt);
          if (i.p & 1 && this.peeks > 0) {
            this.peeks--;
            this.peek = 0.75;
          }
          if (this.hide > 0) {
            this.hide -= dt;
            if (this.hide <= 0) {
              this.flips.forEach((n) => this.cards[n].open = false);
              this.flips = [];
            }
          }
          if (i.p & 6 && this.hide <= 0) {
            const n = this.cy * 4 + this.cx, a = this.cards[n];
            if (!a.open && !a.done) {
              a.open = true;
              this.flips.push(n);
              if (this.flips.length === 2) {
                this.moves++;
                let [x, y] = this.flips;
                if (this.cards[x].value === this.cards[y].value) {
                  this.cards[x].done = this.cards[y].done = true;
                  this.flips = [];
                  g.score += 100;
                  g.sound("coin");
                } else this.hide = 0.8;
              }
              if (this.cards.every((v) => v.done)) g.end(true, "ĐÃ TÌM ĐỦ 8 CẶP!");
            }
          }
        }
        if (id === 18) {
          if (i.p & 2) this.resetWarehouse();
          if (i.p & 1 && this.undo.length) {
            let s = this.undo.pop();
            this.x = s.x;
            this.y = s.y;
            this.crates = s.crates;
          }
          this.navStep(dt, i, (d) => {
            let dx = [1, 0, -1, 0][d], dy = [0, 1, 0, -1][d], x = this.x + dx, y = this.y + dy;
            if (this.wall(x, y)) return;
            let b = this.crates.find((v) => v.x === x && v.y === y);
            if (b && (this.wall(x + dx, y + dy) || this.crates.some((v) => v.x === x + dx && v.y === y + dy))) return;
            this.undo.push({ x: this.x, y: this.y, crates: this.crates.map((v) => __spreadValues({}, v)) });
            if (this.undo.length > 120) this.undo.shift();
            if (b) {
              b.x += dx;
              b.y += dy;
            }
            this.x = x;
            this.y = y;
          });
          let placed = this.targets.filter((t) => this.crates.some((v) => v.x === t.x && v.y === t.y)).length;
          g.score = placed * 100;
          if (placed === 3) g.end(true, "KHO HÀNG HOÀN TẤT!");
        }
        if (id === 19) {
          this.angle = clamp(this.angle + i.a[0] * 1.6 * dt, -Math.PI + 0.25, -0.25);
          if (!this.bubble && i.p & 6) {
            this.bubble = { x: 400, y: 403, vx: Math.cos(this.angle) * 430, vy: Math.sin(this.angle) * 430, color: this.next };
            this.next = 1 + Math.floor(this.rand() * 3);
          }
          const b = this.bubble;
          if (b) {
            b.x += b.vx * dt;
            b.y += b.vy * dt;
            if (b.x < 151 || b.x > 649) {
              b.x = clamp(b.x, 151, 649);
              b.vx *= -1;
            }
            let hit = b.y < 49;
            for (let y = 0; y < 7; y++) for (let x = 0; x < 12; x++) if (this.grid[y][x] && Math.hypot(b.x - (158 + x * 44), b.y - (48 + y * 44)) < 41) hit = true;
            if (hit) {
              let best = null;
              for (let y2 = 0; y2 < 7; y2++) for (let x2 = 0; x2 < 12; x2++) if (!this.grid[y2][x2]) {
                let near = y2 === 0 || this.bubbleNeighbors(x2, y2).some(([xx, yy]) => this.grid[yy][xx]);
                if (!near) continue;
                let d = Math.hypot(b.x - (158 + x2 * 44), b.y - (48 + y2 * 44));
                if (!best || d < best.d) best = { x: x2, y: y2, d };
              }
              if (!best) {
                g.end(false, "BẾN ĐÃ ĐẦY!");
                this.bubble = null;
                return;
              }
              const { x, y } = best;
              this.grid[y][x] = b.color;
              let cluster = [], q = [[x, y]], seen = /* @__PURE__ */ new Set();
              while (q.length) {
                let [xx, yy] = q.pop(), key = xx + "," + yy;
                if (seen.has(key) || this.grid[yy][xx] !== b.color) continue;
                seen.add(key);
                cluster.push([xx, yy]);
                q.push(...this.bubbleNeighbors(xx, yy));
              }
              if (cluster.length >= 3) {
                cluster.forEach(([xx, yy]) => this.grid[yy][xx] = 0);
                let attached = /* @__PURE__ */ new Set(), todo = [];
                for (let xx = 0; xx < 12; xx++) if (this.grid[0][xx]) todo.push([xx, 0]);
                while (todo.length) {
                  let [xx, yy] = todo.pop(), key = xx + "," + yy;
                  if (attached.has(key) || !this.grid[yy][xx]) continue;
                  attached.add(key);
                  todo.push(...this.bubbleNeighbors(xx, yy));
                }
                let popped = cluster.length;
                for (let yy = 0; yy < 7; yy++) for (let xx = 0; xx < 12; xx++) if (this.grid[yy][xx] && !attached.has(xx + "," + yy)) {
                  this.grid[yy][xx] = 0;
                  popped++;
                }
                g.score += popped * 10;
                g.sound("coin");
              } else if (++this.misses >= 5) {
                this.misses = 0;
                if (this.grid[6].some(Boolean)) g.end(false, "BẾN ĐÃ ĐẦY!");
                this.grid.pop();
                this.grid.unshift(Array.from({ length: 12 }, () => 1 + Math.floor(this.rand() * 3)));
              }
              this.bubble = null;
              if (this.grid.every((r) => r.every((v) => !v))) g.end(true);
              else if (this.grid[6].some(Boolean)) g.end(false, "BÓNG CHẠM VẠCH!");
            }
          }
        }
        if (id === 20) {
          this.x = clamp(this.x + i.a[0] * 240 * dt, 30, 770);
          this.y = clamp(this.y + i.a[1] * 210 * dt, 55, 305);
          this.drop = Math.max(0, this.drop - dt);
          if (i.p & 6 && !this.drop) {
            this.parcels.push({ x: this.x, y: this.y, vy: 80, dead: false });
            this.drop = 0.45;
          }
          this.truck -= 85 * dt;
          if (this.truck < -70) this.truck = 860;
          this.spawn -= dt;
          if (this.spawn <= 0) {
            this.spawn = 1.35;
            this.items.push({ x: 840, y: 65 + this.rand() * 230 });
          }
          for (const a of this.items) {
            a.x -= 170 * dt;
            if (Math.hypot(a.x - this.x, a.y - this.y) < 28 && !g.hurt) {
              this.lose(g, this.x, this.y);
              g.hurt = 1.4;
            }
          }
          this.items = this.items.filter((a) => a.x > -50);
          for (const a of this.parcels) {
            a.vy += 250 * dt;
            a.y += a.vy * dt;
            if (a.y >= 390) {
              a.dead = true;
              if (Math.abs(a.x - this.truck) < 48) {
                this.delivered++;
                g.score += 100;
                g.sound("coin");
              }
            }
          }
          this.parcels = this.parcels.filter((a) => !a.dead);
          if (this.delivered >= 8) g.end(true);
          if (this.t > 90) g.end(false, "HẾT GIỜ GIAO HÀNG!");
        }
        if (id >= 21) this.multi(g, dt, i);
      }
      neighbors(n) {
        const x = n % 10, y = Math.floor(n / 10), out = [];
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          let a = x + dx, b = y + dy;
          if ((dx || dy) && a >= 0 && a < 10 && b >= 0 && b < 8) out.push(b * 10 + a);
        }
        return out;
      }
      bubbleNeighbors(x, y) {
        return [[x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]].filter(([a, b]) => a >= 0 && a < 12 && b >= 0 && b < 7);
      }
      multi(g, dt, i) {
        const id = this.id;
        for (let n = 0; n < 2; n++) {
          let p = this.players[n], sw = n ? 8 : 4, sh = n ? 2 : 1;
          p.cd = Math.max(0, p.cd - dt);
          p.shield = Math.max(0, p.shield - dt);
          p.hurt = Math.max(0, p.hurt - dt);
          p.boost = Math.max(0, p.boost - dt);
          if (id !== 24) {
            move(p, i.a[n * 2], i.a[n * 2 + 1], p.boost ? 410 : 205, dt, id === 21 ? n ? 425 : 24 : 24, id === 21 ? n ? 776 : 375 : 776);
          }
          if (i.p & sh && p.cd <= 0) {
            p.shield = 0.8;
            p.cd = 3;
            if (id === 23) {
              let other = this.players[1 - n];
              if (dist(p, other) < 100) {
                other.x = clamp(other.x + (other.x - p.x) * 0.8, 25, 775);
                other.y = clamp(other.y + (other.y - p.y) * 0.8, 50, 410);
              }
            }
            if (id === 24 && this.riders[n].jumps > 0) this.jumpPending[n] = true;
          }
          if (i.p & sw) {
            if (id === 21) p.boost = 0.2;
            if (id === 22 && p.boost <= 0) {
              this.bullets.push({ x: p.x + p.dx * 20, y: p.y + p.dy * 20, vx: p.dx * 390, vy: p.dy * 390, owner: n, life: 2 });
              p.boost = 0.3;
              g.sound("shot");
            }
            if (id === 23 && p.boost <= 0 && p.hurt <= 0) {
              p.boost = 0.22;
              p.hurt = 1.4;
            }
            if (id === 25) {
              if (p.carrying >= 0) {
                const a = this.items[p.carrying];
                a.owner = -1;
                a.x = p.x;
                a.y = p.y;
                if ((n === 0 ? p.x < 95 : p.x > 705) && p.score < 3) {
                  a.done = true;
                  p.score++;
                  g.score += 100;
                  g.sound("coin");
                }
                p.carrying = -1;
              } else {
                const j = this.items.findIndex((a) => !a.done && a.owner < 0 && dist(a, p) < 34);
                if (j >= 0) {
                  this.items[j].owner = n;
                  p.carrying = j;
                }
              }
            }
          }
        }
        if (id === 21) {
          let b = this.ball;
          if (this.goalPause > 0) {
            this.goalPause -= dt;
            return;
          }
          b.x += b.vx * dt;
          b.y += b.vy * dt;
          b.vx *= Math.pow(0.96, dt);
          b.vy *= Math.pow(0.96, dt);
          if (b.y < 49 || b.y > 417) {
            b.y = clamp(b.y, 49, 417);
            b.vy *= -1;
          }
          for (let n = 0; n < 2; n++) {
            let p = this.players[n], r = p.shield ? 35 : 23, d = dist(p, b);
            if (d < r + 10) {
              let dx = (b.x - p.x) / (d || 1), dy = (b.y - p.y) / (d || 1);
              if (!d) {
                dx = n ? -1 : 1;
                dy = 0;
              }
              let speed = p.boost ? 540 : 340;
              b.x = p.x + dx * (r + 11);
              b.y = p.y + dy * (r + 11);
              b.vx = dx * speed;
              b.vy = dy * speed;
            }
          }
          if (b.x < 12 || b.x > 788) {
            if (b.y > 150 && b.y < 300) {
              this.players[b.x < 12 ? 1 : 0].score++;
              g.score = Math.max(...this.players.map((p) => p.score));
              if (this.players.some((p) => p.score >= 5)) this.winner(g);
              this.ball = { x: 400, y: 225, vx: b.x < 12 ? -170 : 170, vy: 65 };
              this.goalPause = 0.65;
            } else {
              b.x = clamp(b.x, 12, 788);
              b.vx *= -1;
            }
          }
        }
        if (id === 22) {
          for (const b of this.bullets) {
            b.x += b.vx * dt;
            b.y += b.vy * dt;
            b.life -= dt;
            const p = this.players[1 - b.owner];
            if (b.life > 0 && dist(b, p) < 23) {
              b.life = 0;
              if (!p.shield && !p.hurt) {
                p.hp--;
                p.hurt = 0.3;
                g.burst(p.x, p.y, C[1 - b.owner], 7);
              }
            }
          }
          this.bullets = this.bullets.filter((b) => b.life > 0 && b.x > 0 && b.x < 800 && b.y > 40 && b.y < 435);
          if (this.players.some((p) => p.hp <= 0)) {
            this.players.forEach((p) => p.score = Math.max(0, p.hp));
            this.winner(g);
          }
        }
        if (id === 23) {
          for (const a of this.items) {
            const first = Math.floor(this.t * 60) % 2;
            for (const n of [first, 1 - first]) if (dist(a, this.players[n]) < 25) {
              this.players[n].score++;
              Object.assign(a, this.coin());
              g.sound("coin");
              break;
            }
          }
          g.score = Math.max(...this.players.map((p) => p.score));
          if (this.t >= 60 || this.players.some((p) => p.score >= 20)) this.winner(g);
        }
        if (id === 24) {
          if (this.roundPause > 0) {
            this.roundPause -= dt;
            if (this.roundPause <= 0) this.setupTrails();
            return;
          }
          for (let n = 0; n < 2; n++) {
            let d = this.direction({ a: i.a.slice(n * 2, n * 2 + 2) }), r = this.riders[n];
            if (d >= 0 && d !== (r.dir + 2) % 4) r.want = d;
          }
          const moving = this.riders.map((r, n) => {
            this.tick[n] += dt;
            const yes = this.tick[n] >= (i.b & (n ? 8 : 4) ? 0.075 : 0.13);
            if (yes) this.tick[n] = 0;
            return yes;
          });
          if (moving.some(Boolean)) {
            let next = this.riders.map((r, n) => {
              if (!moving[n]) return { x: r.x, y: r.y };
              r.dir = r.want;
              let jump = this.jumpPending[n] && r.jumps > 0;
              if (jump) r.jumps--;
              this.jumpPending[n] = false;
              let s = jump ? 3 : 1;
              return { x: r.x + [1, 0, -1, 0][r.dir] * s, y: r.y + [0, 1, 0, -1][r.dir] * s };
            });
            let dead = next.map((p, n) => {
              var _a;
              return moving[n] && (p.x < 0 || p.x >= 36 || p.y < 0 || p.y >= 18 || !!((_a = this.trails[p.y]) == null ? void 0 : _a[p.x]));
            });
            if (next[0].x === next[1].x && next[0].y === next[1].y) dead = [true, true];
            if (dead.some(Boolean)) {
              if (!dead[0]) this.players[0].score++;
              if (!dead[1]) this.players[1].score++;
              g.score = Math.max(...this.players.map((p) => p.score));
              if (this.players.some((p) => p.score >= 3)) this.winner(g);
              else this.roundPause = 1;
            } else next.forEach((p, n) => {
              Object.assign(this.riders[n], p);
              this.trails[p.y][p.x] = n + 1;
            });
          }
        }
        if (id === 25) {
          for (const h of this.hazards) {
            h.x += h.vx * dt;
            if (h.x < 20 || h.x > 780) {
              h.x = clamp(h.x, 20, 780);
              h.vx *= -1;
            }
          }
          for (let n = 0; n < 2; n++) {
            const p = this.players[n];
            if (p.carrying >= 0) {
              this.items[p.carrying].x = p.x;
              this.items[p.carrying].y = p.y - 24;
            }
            if (!p.shield && !p.hurt && this.hazards.some((h) => dist(h, p) < 30)) {
              this.lose(g, p.x, p.y);
              p.hurt = 1.5;
              if (p.carrying >= 0) {
                let a = this.items[p.carrying];
                a.owner = -1;
                a.x = clamp(p.x, 120, 680);
                a.y = clamp(p.y, 70, 380);
                p.carrying = -1;
              }
              p.x = n ? 740 : 60;
              p.y = 225;
            }
          }
          if (this.players.every((p) => p.score >= 3)) g.end(true, "CẢ HAI HOÀN THÀNH CỨU HỘ!");
        }
      }
      render(g, c) {
        const id = this.id, palette = ["#85cfff", "#ffadbb", "#b5e398"];
        if (id === 11) {
          text(c, "LỚP ".concat(this.stage, "/3"), 400, 32);
          for (const a of this.items) if (a.on) box(c, a.x, a.y, 62, 23, a.hp === 2 ? "#e8d597" : palette[Math.floor(a.y / 30) % 3]);
          box(c, this.paddle - (g._inputB & 1 ? 65 : 43), 399, g._inputB & 1 ? 130 : 86, 12, "#d6edff");
          dot(c, this.ball.x, this.ball.y, 9, "#fff3ba");
          if (this.attached) text(c, "R: THẢ BÓNG", 400, 290, 19);
        }
        if (id === 12) {
          c.strokeStyle = "#253c59";
          c.lineWidth = 2;
          c.beginPath();
          c.arc(400, 225, 150, 0, TAU);
          c.stroke();
          c.strokeStyle = "#b4b1ff";
          c.lineWidth = 13;
          c.beginPath();
          c.arc(400, 225, 150, this.angle - (this.wide ? 0.7 : 0.32), this.angle + (this.wide ? 0.7 : 0.32));
          c.stroke();
          dot(c, 400, 225, 45, "#263250");
          text(c, this.caught + "/20", 400, 232, 26);
          for (const a of this.items) dot(c, 400 + Math.cos(a.a) * a.r, 225 + Math.sin(a.a) * a.r, 7, "#ffe4a0");
        }
        if (id === 13) {
          for (let y = 0; y < 10; y++) box(c, 16, 16 + y * 40, 768, 37, y < 2 || y > 7 ? "#25453b" : "#202d40", 3);
          for (const a of this.items) box(c, a.x - 38, 24 + a.y * 40, 76, 24, palette[a.y % 3]);
          box(c, 25 + this.x * 48, 19 + this.y * 40, 30, 28, "#ecfaba");
          text(c, "ĐÍCH " + this.goals + "/3", 400, 438, 14);
        }
        if (id === 14) {
          text(c, "ĐÚNG ".concat(this.caught, "/20 · ").concat(Math.max(0, 90 - Math.floor(this.t)), "s"), 400, 30);
          for (const a of this.items) box(c, a.x - 13, a.y - 13, 26, 26, palette[a.color]);
          box(c, this.x - 42, 396, 84, 15, palette[this.color]);
          text(c, "L / R: ĐỔI MÀU", 400, 440, 14);
        }
        if (id === 15) {
          box(c, 0, 402, 800, 48, "#374055", 2);
          box(c, this.pad - 58, 399, 116, 8, "#9de5bf", 2);
          text(c, "ĐÁP ÊM", this.pad, 435, 14);
          c.save();
          c.translate(this.x, this.y);
          c.rotate(this.vx / 180);
          box(c, -15, -17, 30, 27, "#d2e5f3");
          box(c, -22, 10, 44, 6, "#8ab9d5");
          if (g._inputB & 2 && this.fuel > 0) dot(c, 0, 24, 7 + Math.sin(this.t * 35) * 3, "#ffb66f");
          c.restore();
          text(c, "NHIÊN LIỆU ".concat(Math.ceil(this.fuel), "  VX ").concat(Math.round(this.vx), "  VY ").concat(Math.round(this.vy)), 400, 32, 14);
        }
        if (id === 16) {
          for (let y = 0; y < 8; y++) for (let x = 0; x < 10; x++) {
            const a = this.cells[y * 10 + x], xx = 170 + x * 46, yy = 39 + y * 46;
            box(c, xx, yy, 42, 42, a.open ? "#263e4e" : "#3e5266");
            if (a.flag) text(c, "⚑", xx + 21, yy + 28, 22, "#ffd99c");
            else if (a.open && (a.n || a.mine)) text(c, a.mine ? "×" : a.n, xx + 21, yy + 28, 20, a.mine ? "#ffaaaa" : palette[a.n % 3]);
          }
          c.strokeStyle = "#fff2ba";
          c.lineWidth = 3;
          c.strokeRect(168 + this.cx * 46, 37 + this.cy * 46, 46, 46);
          text(c, "12 MÌN · L: CỜ · R: MỞ", 400, 436, 14);
        }
        if (id === 17) {
          for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) {
            let a = this.cards[y * 4 + x], xx = 205 + x * 100, yy = 35 + y * 93;
            box(c, xx, yy, 89, 81, a.done ? "#2c574d" : "#34415e");
            text(c, a.done || a.open || this.peek ? ["●", "▲", "■", "◆", "✚", "✦", "☾", "♥"][a.value] : "?", xx + 44, yy + 52, 32, a.done ? "#adedd0" : palette[a.value % 3]);
          }
          c.strokeStyle = "#e8d7ff";
          c.lineWidth = 3;
          c.strokeRect(202 + this.cx * 100, 32 + this.cy * 93, 95, 87);
          text(c, "LƯỢT ".concat(this.moves, " · XEM NHANH ").concat(this.peeks), 400, 433, 14);
        }
        if (id === 18) {
          for (let y = 0; y < 7; y++) for (let x = 0; x < 9; x++) box(c, 157 + x * 54, 30 + y * 54, 51, 51, this.wall(x, y) ? "#455568" : "#182a38", 4);
          for (const a of this.targets) dot(c, 182 + a.x * 54, 55 + a.y * 54, 14, "#739e91");
          for (const a of this.crates) {
            box(c, 163 + a.x * 54, 36 + a.y * 54, 40, 40, "#d5a371");
            text(c, "×", 183 + a.x * 54, 64 + a.y * 54, 30, "#5d483e");
          }
          dot(c, 182 + this.x * 54, 55 + this.y * 54, 17, "#a6d9fa");
          text(c, "L: HOÀN TÁC · R: LÀM LẠI", 400, 435, 14);
        }
        if (id === 19) {
          for (let y = 0; y < 7; y++) for (let x = 0; x < 12; x++) if (this.grid[y][x]) dot(c, 158 + x * 44, 48 + y * 44, 20, palette[this.grid[y][x] - 1]);
          c.strokeStyle = "#8297ac";
          c.lineWidth = 3;
          c.beginPath();
          c.moveTo(400, 412);
          c.lineTo(400 + Math.cos(this.angle) * 65, 412 + Math.sin(this.angle) * 65);
          c.stroke();
          dot(c, 400, 412, 18, palette[this.next - 1]);
          if (this.bubble) dot(c, this.bubble.x, this.bubble.y, 20, palette[this.bubble.color - 1]);
          text(c, "THÊM HÀNG SAU ".concat(5 - this.misses, " LẦN TRƯỢT"), 400, 18, 12);
        }
        if (id === 20) {
          box(c, 0, 418, 800, 32, "#263c43");
          box(c, this.truck - 46, 385, 92, 29, "#a8d3b8");
          dot(c, this.truck - 28, 418, 9, "#596779");
          dot(c, this.truck + 28, 418, 9, "#596779");
          box(c, this.x - 22, this.y - 10, 44, 20, "#efcb7e");
          box(c, this.x - 30, this.y - 16, 60, 4, "#a8d5ed");
          for (const a of this.items) box(c, a.x - 22, a.y - 10, 44, 20, "#d38696");
          for (const a of this.parcels) box(c, a.x - 7, a.y - 7, 14, 14, "#d8ba89", 2);
          text(c, "GIAO ".concat(this.delivered, "/8 · ").concat(Math.max(0, 90 - Math.floor(this.t)), "s"), 400, 30);
        }
        if (id >= 21) {
          const [a, b] = this.players;
          text(c, "P1  ".concat(id === 22 ? "HP " + a.hp : a.score), 50, 27, 17, C[0], "left");
          text(c, id === 23 ? Math.max(0, 60 - Math.floor(this.t)) + "s" : id === 25 ? "MỖI NGƯỜI 3 KIỆN" : id === 24 ? "THẮNG 3 VÒNG" : id === 21 ? "5 BÀN" : "ĐẤU TAY ĐÔI", 400, 27, 14);
          text(c, "P2  ".concat(id === 22 ? "HP " + b.hp : b.score), 750, 27, 17, C[1], "right");
          if (id === 21) {
            box(c, 397, 45, 6, 380, "#29455e", 1);
            box(c, 0, 150, 8, 150, C[0], 1);
            box(c, 792, 150, 8, 150, C[1], 1);
            dot(c, this.ball.x, this.ball.y, 10, "#ecf4dd");
          }
          if (id === 22) for (const s of this.bullets) dot(c, s.x, s.y, 5, C[s.owner]);
          if (id === 23) for (const a2 of this.items) {
            dot(c, a2.x, a2.y, 10, "#f4d47e");
            dot(c, a2.x, a2.y, 5, "#af864c");
          }
          if (id === 24) {
            for (let y = 0; y < 18; y++) for (let x = 0; x < 36; x++) if (this.trails[y][x]) box(c, 40 + x * 20, 49 + y * 20, 18, 18, this.trails[y][x] === 1 ? "#437794" : "#98684f", 2);
            this.riders.forEach((r, n) => {
              box(c, 39 + r.x * 20, 48 + r.y * 20, 20, 20, C[n], 3);
              text(c, "NHẢY " + r.jumps, n ? 735 : 65, 437, 12, C[n]);
            });
            if (this.roundPause > 0) text(c, "VÒNG TIẾP THEO…", 400, 230, 26);
          }
          if (id === 25) {
            box(c, 20, 50, 75, 368, "#193f58");
            box(c, 705, 50, 75, 368, "#583e2f");
            for (const a2 of this.items) if (!a2.done) box(c, a2.x - 11, a2.y - 11, 22, 22, "#d3e6a6");
            for (const h of this.hazards) dot(c, h.x, h.y, 16, "#d28094");
          }
          if (id !== 24) this.players.forEach((p, n) => {
            if (p.shield) dot(c, p.x, p.y, 35, n ? "#664b39" : "#2b4e68");
            dot(c, p.x, p.y, 21, C[n]);
            dot(c, p.x + p.dx * 13, p.y + p.dy * 13, 5, "#142637");
            text(c, n ? "2" : "1", p.x, p.y + 5, 13, "#142637");
          });
        }
      }
    }
    globalThis.ContlExtra = { defs, Extra };
  })();
  (() => {
    const W = 800, H = 450, TAU = Math.PI * 2, clamp = (x, a, b) => Math.max(a, Math.min(b, x)), hyp = Math.hypot;
    const DEFS = [
      ["maze", "Maze Munch", "MÊ CUNG", "#ffc861", "Ăn chấm sáng, tránh những bóng ma.", "JOY1 di chuyển"],
      ["invaders", "Star Defenders", "KHÔNG GIAN", "#7cb6ff", "Bảo vệ quỹ đạo qua từng đợt xâm lăng.", "JOY1 trái/phải · R bắn"],
      ["platform", "Pocket Platform", "PHIÊU LƯU", "#ff977a", "Nhảy qua vực, nhặt xu và tìm lá cờ.", "JOY1 đi/cúi · L chạy/bắn · R nhảy"],
      ["blocks", "Falling Blocks", "XẾP HÌNH", "#bc9cff", "Xoay, xếp và dọn những hàng khối màu.", "JOY1 đi/rơi · L/R xoay · J1 SW thả"],
      ["flappy", "Tiny Flap", "MỘT NÚT", "#ff8ec7", "Một nhịp cánh, thêm một khoảng trời.", "R hoặc J1 SW vỗ cánh"],
      ["pong", "Duo Pong", "HAI NGƯỜI", "#73e2ce", "Hai joystick. Hai phía. Bảy điểm để thắng.", "JOY1 Y vợt trái · JOY2 Y vợt phải"],
      ["arena", "Twin Arena", "BẮN SONG CẦN", "#fb9b72", "Di chuyển giữa các chướng ngại và sống sót.", "JOY1 di chuyển · JOY2 ngắm/bắn"],
      ["vector", "Vector Storm", "BẮN SONG CẦN", "#93efff", "Lướt giữa những hình khối không gian.", "JOY1 đi · JOY2 bắn · R dùng bom"],
      ["racer", "Micro Racer", "ĐUA XE", "#f7bd68", "Giữ làn, tránh xe và chạm vạch đích.", "JOY1 rẽ · R ga · L phanh/lùi"],
      ["snake", "Garden Snake", "CỔ ĐIỂN", "#b8e978", "Tìm trái sáng, đừng chạm vào chính mình.", "JOY1 đổi hướng"],
      ["tanks", "Mini Tanks", "CHIẾN THUẬT", "#a6cbb8", "Phá tường gạch và hạ tám xe đối phương.", "JOY1 bốn hướng · R bắn"]
    ].concat(ContlExtra.defs).map((a, id) => ({ id, players: id === 5 ? 2 : a[6] || 1, webOnly: id >= 11, slug: a[0], name: a[1], genre: a[2], color: a[3], description: a[4], controls: a[5] }));
    const MAZE = [
      "#####################",
      "#.........#.........#",
      "#.###.###.#.###.###.#",
      "#o..#...........#..o#",
      "###.#.#.#####.#.#.###",
      "#.....#...#...#.....#",
      "#.###.###.#.###.###.#",
      "#...#...........#...#",
      "###.#.#.#####.#.#.###",
      "#.....#...#...#.....#",
      "#.###.###.#.###.###.#",
      "#o.................o#",
      "#####################"
    ];
    const DIR = [[1, 0], [0, 1], [-1, 0], [0, -1]];
    const SHAPES = [[[0, 1], [1, 1], [2, 1], [3, 1]], [[1, 0], [2, 0], [1, 1], [2, 1]], [[1, 0], [0, 1], [1, 1], [2, 1]], [[1, 0], [2, 0], [0, 1], [1, 1]], [[0, 0], [1, 0], [1, 1], [2, 1]], [[0, 0], [0, 1], [1, 1], [2, 1]], [[2, 0], [0, 1], [1, 1], [2, 1]]];
    const COLORS = ["#80e5ff", "#ffe485", "#c7a0ff", "#a8ed88", "#ff8ba8", "#88acff", "#ffb881"];
    function rr(c, x, y, w, h, r, fill, stroke) {
      c.beginPath();
      c.roundRect(x, y, w, h, r);
      if (fill) {
        c.fillStyle = fill;
        c.fill();
      }
      if (stroke) {
        c.strokeStyle = stroke;
        c.stroke();
      }
    }
    function circle(c, x, y, r, color) {
      c.beginPath();
      c.arc(x, y, Math.max(0, r), 0, TAU);
      c.fillStyle = color;
      c.fill();
    }
    function line(c, x, y, xx, yy, color, width = 2) {
      c.beginPath();
      c.moveTo(x, y);
      c.lineTo(xx, yy);
      c.strokeStyle = color;
      c.lineWidth = width;
      c.stroke();
    }
    function label(c, s, x, y, size = 16, color = "#c5d0ef", align = "left") {
      c.fillStyle = color;
      c.font = "600 ".concat(size, "px ui-monospace,monospace");
      c.textAlign = align;
      c.fillText(s, x, y);
    }
    function aim(a, old = 0) {
      if (Math.max(Math.abs(a[0]), Math.abs(a[1])) < 0.35) return old;
      return Math.abs(a[0]) > Math.abs(a[1]) ? a[0] > 0 ? 0 : 2 : a[1] > 0 ? 1 : 3;
    }
    class Game {
      constructor(id, seed = 123456, sound = () => {
      }) {
        this.id = clamp(id | 0, 0, DEFS.length - 1);
        this.seed = seed >>> 0;
        this.sound = sound;
        this.score = 0;
        this.lives = 3;
        this.level = 1;
        this.clock = 0;
        this.over = false;
        this.won = false;
        this.result = "";
        this.p = { x: 400, y: 380, vx: 0, vy: 0 };
        this.enemies = [];
        this.shots = [];
        this.particles = [];
        this.cool = 0;
        this.hurt = 0;
        this.timer = 0;
        this.timer2 = 0;
        this.dir = 0;
        this.want = 0;
        this.bombs = 3;
        this.flash = 0;
        if (this.id >= 11) this.extra = new ContlExtra.Extra(this.id, () => this.rand());
        if (this.id === 0) {
          this.grid = MAZE.map((r) => r.split(""));
          this.p.x = 1;
          this.p.y = 1;
          this.left = 0;
          this.power = 0;
          this.grid.forEach((r) => r.forEach((v) => {
            if (v === "." || v === "o") this.left++;
          }));
          this.ghosts();
        }
        if (this.id === 1) {
          this.wave();
          this.drift = 1;
        }
        if (this.id === 2) {
          this.p = { x: 75, y: 290, vx: 0, vy: 0 };
          this.camera = 0;
          this.platforms = [];
          for (let i = 0; i < 24; i++) if (i % 7 !== 4) this.platforms.push({ x: i * 140, y: 388, w: 140, h: 62 });
          for (let i = 0; i < 6; i++) this.platforms.push({ x: 330 + i * 450, y: 265 - i % 2 * 60, w: 130, h: 20 });
          this.coins = [];
          for (let i = 0; i < 40; i++) this.coins.push({ x: 130 + i * 78, y: 310 - (i % 4 === 0 ? 100 : 0), alive: true });
          for (let i = 0; i < 13; i++) {
            let x = 250 + i * 210;
            if (this.groundAt(x, 389)) this.enemies.push({ x, y: 370, vx: -48, alive: true });
          }
        }
        if (this.id === 3) {
          this.board = Array.from({ length: 20 }, () => Array(10).fill(0));
          this.next = this.randomInt(7);
          this.lines = 0;
          this.repeat = 0;
          this.lastMove = 0;
          this.spawnPiece();
        }
        if (this.id === 4) {
          this.p.x = 180;
          this.p.y = 210;
          this.p.vy = 0;
          this.pipes = Array.from({ length: 4 }, (_, i) => ({ x: 700 + i * 280, y: 130 + this.rand() * 180, passed: false }));
        }
        if (this.id === 5) {
          this.p.y = 225;
          this.right = 225;
          this.leftScore = 0;
          this.rightScore = 0;
          this.ball = { x: 400, y: 225, vx: 260, vy: 100 };
        }
        if (this.id === 6 || this.id === 7) {
          this.p.y = 225;
          this.obstacles = this.id === 6 ? [{ x: 190, y: 125, w: 55, h: 90 }, { x: 550, y: 250, w: 55, h: 90 }] : [];
        }
        if (this.id === 8) {
          this.p.x = 400;
          this.p.y = 355;
          this.speed = 0;
          this.distance = 0;
        }
        if (this.id === 9) {
          this.snake = Array.from({ length: 5 }, (_, i) => ({ x: 10 - i, y: 9 }));
          this.food();
        }
        if (this.id === 10) {
          this.p.x = 120;
          this.p.y = 370;
          this.dir = 3;
          this.grid = Array.from({ length: 14 }, (_, y) => Array.from({ length: 25 }, (_2, x) => x % 5 === 3 && y > 2 && y < 11 && y % 4 !== 0 ? 2 : 0));
          for (let i = 0; i < 8; i++) this.enemies.push({ x: 110 + i * 80, y: 65, dir: 1, hp: 2, alive: true });
        }
      }
      rand() {
        this.seed = Math.imul(this.seed, 1664525) + 1013904223 >>> 0;
        return this.seed / 4294967296;
      }
      randomInt(n) {
        return Math.floor(this.rand() * n);
      }
      end(win = false, text = "") {
        this.over = true;
        this.won = win;
        this.result = text || (win ? "HOÀN THÀNH!" : "THỬ THÊM MỘT LẦN?");
        this.sound(win ? "win" : "lose");
      }
      burst(x, y, color, n = 12) {
        for (let i = 0; i < n && this.particles.length < 160; i++) {
          let a = this.rand() * TAU, s = 25 + this.rand() * 140;
          this.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0.35 + this.rand() * 0.45, color });
        }
      }
      hit() {
        if (this.hurt) return;
        this.lives--;
        this.hurt = 1.4;
        this.burst(this.p.x, this.p.y, "#ff8194", 24);
        this.sound("hit");
        if (this.lives <= 0) this.end();
      }
      fire(x, y, vx, vy, enemy = false) {
        if (this.shots.length < 100) this.shots.push({ x, y, vx, vy, enemy, alive: true });
      }
      step(dt, input) {
        if (this.over) return;
        dt = clamp(dt, 0, 0.04);
        this.clock += dt;
        this.cool = Math.max(0, this.cool - dt);
        this.hurt = Math.max(0, this.hurt - dt);
        this.flash = Math.max(0, this.flash - dt);
        const handlers = ["maze", "invaders", "platform", "blocks", "flappy", "pong", "twin", "twin", "racer", "snakeStep", "tanks"];
        this._inputB = input.b;
        if (this.extra) this.extra.step(this, dt, input);
        else this[handlers[this.id]](dt, input);
        for (const e of this.particles) {
          e.x += e.vx * dt;
          e.y += e.vy * dt;
          e.life -= dt;
        }
        this.particles = this.particles.filter((e) => e.life > 0);
        this.shots = this.shots.filter((e) => e.alive !== false);
        this.enemies = this.enemies.filter((e) => e.alive !== false);
      }
      wall(x, y) {
        return !this.grid[y] || this.grid[y][x] === void 0 || this.grid[y][x] === "#";
      }
      ghosts() {
        this.enemies = [{ x: 19, y: 11, color: "#ff809d" }, { x: 19, y: 1, color: "#a698ff" }, { x: 1, y: 11, color: "#73d9e4" }];
      }
      maze(dt, i) {
        this.want = aim(i.a, this.want);
        this.timer += dt;
        this.timer2 += dt;
        this.power = Math.max(0, this.power - dt);
        if (this.timer >= 0.13) {
          this.timer = 0;
          let x = this.p.x, y = this.p.y;
          if (!this.wall(x + DIR[this.want][0], y + DIR[this.want][1])) this.dir = this.want;
          if (!this.wall(x + DIR[this.dir][0], y + DIR[this.dir][1])) {
            this.p.x += DIR[this.dir][0];
            this.p.y += DIR[this.dir][1];
          }
          let v = this.grid[this.p.y][this.p.x];
          if (v === "." || v === "o") {
            this.grid[this.p.y][this.p.x] = " ";
            this.left--;
            this.score += 10;
            if (v === "o") {
              this.power = 5;
              this.sound("bonus");
            }
            if (!this.left) this.end(true);
          }
        }
        if (this.timer2 >= 0.2) {
          this.timer2 = 0;
          for (const e of this.enemies) {
            let choices = [];
            DIR.forEach(([dx, dy], d) => {
              if (!this.wall(e.x + dx, e.y + dy)) {
                let n = Math.abs(e.x + dx - this.p.x) + Math.abs(e.y + dy - this.p.y);
                choices.push({ d, cost: (this.power ? -n : n) + this.rand() * 6 });
              }
            });
            choices.sort((a, b) => a.cost - b.cost);
            if (choices.length) {
              let d = choices[0].d;
              e.x += DIR[d][0];
              e.y += DIR[d][1];
            }
          }
        }
        for (const e of this.enemies) if (e.x === this.p.x && e.y === this.p.y) {
          if (this.power) {
            e.x = this.p.x < 10 ? 19 : 1;
            e.y = this.p.y < 6 ? 11 : 1;
            this.score += 100;
            this.sound("bonus");
          } else if (!this.hurt) {
            this.lives--;
            this.hurt = 2;
            this.p.x = 1;
            this.p.y = 1;
            this.ghosts();
            if (this.lives <= 0) this.end();
            break;
          }
        }
      }
      wave() {
        this.enemies = [];
        for (let r = 0; r < 3; r++) for (let col = 0; col < 7; col++) this.enemies.push({ x: 105 + col * 92, y: 60 + r * 48, alive: true, row: r });
      }
      invaders(dt, i) {
        this.p.x = clamp(this.p.x + i.a[0] * 310 * dt, 35, 765);
        if (i.b & 2 && !this.cool) {
          this.fire(this.p.x, 390, 0, -550);
          this.cool = 0.16;
          this.sound("shot");
        }
        let edge = false;
        for (const e of this.enemies) {
          e.x += this.drift * (27 + this.level * 7) * dt;
          if (e.x < 35 || e.x > 765) edge = true;
          if (e.y > 355) this.end();
        }
        if (edge) {
          this.drift *= -1;
          for (const e of this.enemies) {
            e.y += 19;
            e.x += this.drift * 4;
          }
        }
        this.timer += dt;
        if (this.timer > Math.max(0.2, 0.9 - this.level * 0.06)) {
          this.timer = 0;
          let e = this.enemies[this.randomInt(this.enemies.length)];
          if (e) this.fire(e.x, e.y, 0, 220 + this.level * 12, true);
        }
        for (const s of this.shots) {
          s.x += s.vx * dt;
          s.y += s.vy * dt;
          if (s.y < 0 || s.y > H) {
            s.alive = false;
            continue;
          }
          if (s.enemy) {
            if (hyp(s.x - this.p.x, s.y - 405) < 24 && !this.hurt) {
              s.alive = false;
              this.hit();
            }
          } else for (const e of this.enemies) if (e.alive && Math.abs(s.x - e.x) < 22 && Math.abs(s.y - e.y) < 18) {
            e.alive = s.alive = false;
            this.score += 20;
            this.burst(e.x, e.y, COLORS[e.row], 15);
            break;
          }
        }
        if (!this.enemies.some((e) => e.alive)) {
          this.level++;
          this.wave();
          this.shots = [];
          this.sound("bonus");
        }
      }
      groundAt(x, y) {
        return this.platforms.some((r) => x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h);
      }
      platform(dt, i) {
        const p = this.p;
        let grounded = this.groundAt(p.x - 9, p.y + 20) || this.groundAt(p.x + 9, p.y + 20);
        this.crouch = grounded && i.a[1] > 0.4;
        p.vx = this.crouch ? 0 : i.a[0] * (i.b & 1 ? 265 : 185);
        if (Math.abs(i.a[0]) > 0.3) this.dir = i.a[0] < 0 ? 2 : 0;
        if (i.p & 2 && grounded) {
          p.vy = -700;
          this.sound("jump");
        }
        p.vy = Math.min(600, p.vy + 1250 * dt);
        let nx = clamp(p.x + p.vx * dt, 15, 3330), ny = p.y + p.vy * dt, top = this.crouch ? 5 : 18;
        if (!this.groundAt(nx + (p.vx >= 0 ? 12 : -12), p.y - top) && !this.groundAt(nx + (p.vx >= 0 ? 12 : -12), p.y + 16)) p.x = nx;
        let landed = false;
        for (const r of this.platforms) {
          if (p.x + 10 > r.x && p.x - 10 < r.x + r.w) {
            if (p.vy >= 0 && p.y + 19 <= r.y + 2 && ny + 19 >= r.y) {
              ny = r.y - 19;
              p.vy = 0;
              landed = true;
            } else if (p.vy < 0 && p.y - top >= r.y + r.h && ny - top <= r.y + r.h) {
              ny = r.y + r.h + top;
              p.vy = 0;
            }
          }
        }
        p.y = ny;
        if (i.b & 1 && !this.cool) {
          this.fire(p.x, p.y, this.dir === 2 ? -480 : 480, 0);
          this.cool = 0.24;
        }
        for (const coin of this.coins) if (coin.alive && hyp(coin.x - p.x, coin.y - p.y) < 29) {
          coin.alive = false;
          this.score += 10;
          this.burst(coin.x, coin.y, "#ffdf8d", 7);
          this.sound("coin");
        }
        for (const e of this.enemies) {
          if (this.groundAt(e.x + Math.sign(e.vx) * 21, 390)) e.x += e.vx * dt;
          else e.vx = -e.vx;
          if (Math.abs(e.x - p.x) < 27 && Math.abs(e.y - p.y) < 30) {
            if (p.vy > 60 && p.y < e.y - 14) {
              e.alive = false;
              p.vy = -320;
              this.score += 40;
            } else if (!this.hurt) this.hit();
          }
        }
        for (const s of this.shots) {
          s.x += s.vx * dt;
          if (Math.abs(s.x - p.x) > 850 || this.groundAt(s.x, s.y)) s.alive = false;
          for (const e of this.enemies) if (e.alive && hyp(s.x - e.x, s.y - e.y) < 24) {
            e.alive = s.alive = false;
            this.score += 30;
            this.burst(e.x, e.y, "#ffb083");
          }
        }
        if (p.y > 500) {
          this.lives--;
          if (this.lives <= 0) this.end();
          else {
            p.x = 75;
            p.y = 290;
            p.vy = 0;
            this.hurt = 2;
          }
        }
        this.camera = clamp(p.x - 250, 0, 2560);
        if (p.x > 3290) {
          this.score += 250;
          this.end(true);
        }
      }
      shape(piece = this.piece, rot = this.rotation) {
        return SHAPES[piece].map(([x, y]) => {
          if (piece !== 1) for (let r = 0; r < rot; r++) {
            let t = x;
            x = (piece === 0 ? 3 : 2) - y;
            y = t;
          }
          return [x, y];
        });
      }
      fits(x, y, r) {
        return this.shape(this.piece, r).every(([xx, yy]) => {
          xx += x;
          yy += y;
          return xx >= 0 && xx < 10 && yy < 20 && (yy < 0 || !this.board[yy][xx]);
        });
      }
      spawnPiece() {
        this.piece = this.next;
        this.next = this.randomInt(7);
        this.rotation = 0;
        this.tx = 3;
        this.ty = -1;
        this.timer = 0;
        if (!this.fits(this.tx, this.ty, 0)) this.end();
      }
      lockPiece() {
        for (const [x, y] of this.shape()) {
          if (y + this.ty < 0) {
            this.end();
            return;
          }
          this.board[y + this.ty][x + this.tx] = this.piece + 1;
        }
        let count = 0;
        for (let y = 19; y >= 0; y--) if (this.board[y].every(Boolean)) {
          this.board.splice(y, 1);
          this.board.unshift(Array(10).fill(0));
          count++;
          y++;
        }
        this.lines += count;
        this.score += count * count * 100;
        if (count) {
          this.flash = 0.15;
          this.sound("bonus");
        }
        this.spawnPiece();
      }
      blocks(dt, i) {
        let move = i.a[0] < -0.4 ? -1 : i.a[0] > 0.4 ? 1 : 0;
        this.repeat -= dt;
        if (move && (this.repeat <= 0 || move !== this.lastMove)) {
          if (this.fits(this.tx + move, this.ty, this.rotation)) this.tx += move;
          this.repeat = 0.13;
        }
        if (!move) this.repeat = 0;
        this.lastMove = move;
        let r = this.rotation;
        if (i.p & 1) r = (r + 3) % 4;
        if (i.p & 2) r = (r + 1) % 4;
        if (r !== this.rotation) {
          for (const kick of [0, -1, 1, -2, 2]) if (this.fits(this.tx + kick, this.ty, r)) {
            this.tx += kick;
            this.rotation = r;
            this.sound("tick");
            break;
          }
        }
        if (i.p & 4) {
          while (this.fits(this.tx, this.ty + 1, this.rotation)) this.ty++;
          this.lockPiece();
          return;
        }
        this.timer += dt;
        if (this.timer > (i.a[1] > 0.4 ? 0.045 : Math.max(0.13, 0.65 - this.lines * 0.014))) {
          this.timer = 0;
          if (this.fits(this.tx, this.ty + 1, this.rotation)) this.ty++;
          else this.lockPiece();
        }
      }
      flappy(dt, i) {
        if (i.p & (2 | 4)) {
          this.p.vy = -270;
          this.sound("jump");
        }
        this.p.vy += 730 * dt;
        this.p.y += this.p.vy * dt;
        if (this.p.y < 18 || this.p.y > 430) this.end();
        for (const e of this.pipes) {
          e.x -= (145 + Math.min(25, this.score) * 2) * dt;
          if (e.x < -90) {
            e.x += 1120;
            e.y = 120 + this.rand() * 200;
            e.passed = false;
          }
          if (!e.passed && e.x + 65 < this.p.x) {
            e.passed = true;
            this.score++;
            this.sound("coin");
          }
          if (e.x < this.p.x + 15 && e.x + 65 > this.p.x - 15 && (this.p.y - 13 < e.y - 77 || this.p.y + 13 > e.y + 77)) this.end();
        }
      }
      pong(dt, i) {
        this.p.y = clamp(this.p.y + i.a[1] * 325 * dt, 50, 400);
        this.right = clamp(this.right + i.a[3] * 325 * dt, 50, 400);
        if (this.cool) return;
        let b = this.ball;
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        if (b.y < 12 || b.y > 438) {
          b.vy *= -1;
          b.y = clamp(b.y, 12, 438);
          this.sound("tick");
        }
        if (b.x < 73 && b.x > 40 && b.vx < 0 && Math.abs(b.y - this.p.y) < 60 || b.x > 727 && b.x < 760 && b.vx > 0 && Math.abs(b.y - this.right) < 60) {
          b.vy = (b.y - (b.vx < 0 ? this.p.y : this.right)) * 5;
          b.vx = clamp(-b.vx * 1.065, -570, 570);
          this.burst(b.x, b.y, "#92f1d9", 6);
          this.sound("tick");
        }
        if (b.x < -15 || b.x > 815) {
          if (b.x < 0) this.rightScore++;
          else this.leftScore++;
          this.score = Math.max(this.leftScore, this.rightScore);
          b.x = 400;
          b.y = 225;
          b.vx = b.vx > 0 ? -270 : 270;
          b.vy = 110;
          this.cool = 0.6;
          if (this.score === 7) this.end(true, "".concat(this.leftScore === 7 ? "NGƯỜI 1" : "NGƯỜI 2", " CHIẾN THẮNG"));
        }
      }
      obstruct(x, y, r = 13) {
        return this.obstacles.some((o) => x + r > o.x && x - r < o.x + o.w && y + r > o.y && y - r < o.y + o.h);
      }
      twin(dt, i) {
        let p = this.p, scale = Math.max(1, hyp(i.a[0], i.a[1])), nx = clamp(p.x + i.a[0] / scale * 225 * dt, 20, 780), ny = clamp(p.y + i.a[1] / scale * 225 * dt, 20, 430);
        if (!this.obstruct(nx, p.y)) p.x = nx;
        if (!this.obstruct(p.x, ny)) p.y = ny;
        let m = hyp(i.a[2], i.a[3]);
        if (m > 0.3 && !this.cool) {
          this.fire(p.x, p.y, i.a[2] / m * 600, i.a[3] / m * 600);
          this.cool = this.id === 7 ? 0.085 : 0.125;
          this.aim = Math.atan2(i.a[3], i.a[2]);
          this.sound("shot");
        }
        if (this.id === 7 && i.p & 2 && this.bombs) {
          this.bombs--;
          this.flash = 0.3;
          for (const e of this.enemies) {
            e.alive = false;
            this.score += 20;
            this.burst(e.x, e.y, "#94e5ff", 8);
          }
          this.sound("bonus");
        }
        this.timer += dt;
        if (this.timer > Math.max(0.22, 0.75 - this.score / 5e3)) {
          this.timer = 0;
          let side = this.randomInt(4);
          if (this.enemies.length < 50) this.enemies.push({ x: side < 2 ? side ? 790 : 10 : this.rand() * 800, y: side >= 2 ? side === 2 ? 10 : 440 : this.rand() * 450, alive: true });
        }
        for (const e of this.enemies) {
          if (!e.alive) continue;
          let dx = p.x - e.x, dy = p.y - e.y, d = hyp(dx, dy) || 1, speed = (this.id === 7 ? 90 : 66) + Math.min(this.score / 35, 55);
          let ex = e.x + dx / d * speed * dt, ey = e.y + dy / d * speed * dt;
          if (!this.obstruct(ex, e.y, 10)) e.x = ex;
          else e.y += Math.sign(dy || 1) * speed * dt;
          if (!this.obstruct(e.x, ey, 10)) e.y = ey;
          else e.x += Math.sign(dx || 1) * speed * dt;
          if (d < 25 && !this.hurt) {
            e.alive = false;
            this.hit();
          }
        }
        for (const s of this.shots) {
          s.x += s.vx * dt;
          s.y += s.vy * dt;
          if (s.x < 0 || s.x > 800 || s.y < 0 || s.y > 450 || this.obstruct(s.x, s.y, 1)) {
            s.alive = false;
            continue;
          }
          for (const e of this.enemies) if (e.alive && hyp(e.x - s.x, e.y - s.y) < 17) {
            s.alive = e.alive = false;
            this.score += 20;
            this.burst(e.x, e.y, this.id === 7 ? "#85e7ff" : "#ffbd97");
            break;
          }
        }
      }
      road(y) {
        return 400 + 110 * Math.sin((this.distance + y * 2) * 2e-3);
      }
      racer(dt, i) {
        if (i.b & 2) this.speed = Math.min(340, this.speed + 110 * dt);
        else if (i.b & 1) this.speed = Math.max(-70, this.speed - 210 * dt);
        else this.speed *= Math.pow(0.986, dt * 60);
        this.p.x = clamp(this.p.x + i.a[0] * 245 * dt * (this.speed < 0 ? -1 : 1) * (0.2 + Math.abs(this.speed) / 340), 25, 775);
        this.distance = Math.max(0, this.distance + this.speed * dt);
        this.score = Math.floor(this.distance);
        if (Math.abs(this.p.x - this.road(this.p.y)) > 138 && Math.abs(this.speed) > 15) {
          this.speed *= Math.pow(0.95, dt * 60);
          this.timer2 += dt;
          if (this.timer2 > 1) {
            this.timer2 = 0;
            this.hit();
          }
        } else this.timer2 = Math.max(0, this.timer2 - dt);
        this.timer += dt;
        if (this.timer > 1.1 && this.speed > 35) {
          this.timer = 0;
          this.enemies.push({ y: -55, x: 400, lane: (this.randomInt(3) - 1) * 82, alive: true, color: COLORS[this.randomInt(7)] });
        }
        for (const e of this.enemies) {
          e.y += (this.speed + 35) * dt;
          e.x = this.road(e.y) + e.lane;
          if (e.y > 520 || e.y < -150) e.alive = false;
          if (Math.abs(e.x - this.p.x) < 35 && Math.abs(e.y - this.p.y) < 56 && !this.hurt) {
            e.alive = false;
            this.speed = 40;
            this.hit();
          }
        }
        if (this.distance >= 2500) this.end(true, "VỀ ĐÍCH!");
      }
      food() {
        let free = [];
        for (let y = 0; y < 18; y++) for (let x = 0; x < 32; x++) if (!this.snake.some((e) => e.x === x && e.y === y)) free.push({ x, y });
        if (!free.length) {
          this.end(true);
          return;
        }
        this.fruit = free[this.randomInt(free.length)];
      }
      snakeStep(dt, i) {
        let d = aim(i.a, this.dir);
        if (d !== (this.dir + 2) % 4) this.want = d;
        this.timer += dt;
        if (this.timer < Math.max(0.065, 0.15 - this.score * 2e-3)) return;
        this.timer = 0;
        this.dir = this.want;
        let p = { x: this.snake[0].x + DIR[this.dir][0], y: this.snake[0].y + DIR[this.dir][1] }, eat = p.x === this.fruit.x && p.y === this.fruit.y;
        if (p.x < 0 || p.x >= 32 || p.y < 0 || p.y >= 18 || this.snake.slice(0, this.snake.length - (eat ? 0 : 1)).some((e) => e.x === p.x && e.y === p.y)) {
          this.end();
          return;
        }
        this.snake.unshift(p);
        if (eat) {
          this.score++;
          this.food();
          this.sound("coin");
        } else this.snake.pop();
      }
      tankBlocked(x, y, r = 14) {
        if (x < 65 || x > 735 || y < 43 || y > 408) return true;
        return [[-r, -r], [r, -r], [-r, r], [r, r]].some(([dx, dy]) => {
          var _a;
          let xx = Math.floor((x + dx - 50) / 28), yy = Math.floor((y + dy - 29) / 28);
          return ((_a = this.grid[yy]) == null ? void 0 : _a[xx]) > 0;
        });
      }
      tanks(dt, i) {
        var _a;
        if (Math.max(Math.abs(i.a[0]), Math.abs(i.a[1])) > 0.35) {
          this.dir = aim(i.a, this.dir);
          let [dx, dy] = DIR[this.dir], nx = this.p.x + dx * 155 * dt, ny = this.p.y + dy * 155 * dt;
          if (!this.tankBlocked(nx, ny)) {
            this.p.x = nx;
            this.p.y = ny;
          }
        }
        if (i.b & 2 && !this.cool) {
          let [dx, dy] = DIR[this.dir];
          this.fire(this.p.x + dx * 25, this.p.y + dy * 25, dx * 390, dy * 390);
          this.cool = 0.22;
          this.sound("shot");
        }
        this.timer += dt;
        let act = this.timer > 0.75;
        if (act) this.timer = 0;
        for (const e of this.enemies) {
          if (act) {
            e.dir = aim([this.p.x - e.x, this.p.y - e.y]);
            if (this.rand() < 0.3) e.dir = this.randomInt(4);
            let [dx2, dy2] = DIR[e.dir];
            this.fire(e.x + dx2 * 25, e.y + dy2 * 25, dx2 * 240, dy2 * 240, true);
          }
          let [dx, dy] = DIR[e.dir], nx = e.x + dx * 65 * dt, ny = e.y + dy * 65 * dt;
          if (!this.tankBlocked(nx, ny)) {
            e.x = nx;
            e.y = ny;
          } else if (this.rand() < 0.04) e.dir = this.randomInt(4);
        }
        for (const s of this.shots) {
          s.x += s.vx * dt;
          s.y += s.vy * dt;
          if (s.x < 50 || s.x > 750 || s.y < 29 || s.y > 421) {
            s.alive = false;
            continue;
          }
          let x = Math.floor((s.x - 50) / 28), y = Math.floor((s.y - 29) / 28);
          if ((_a = this.grid[y]) == null ? void 0 : _a[x]) {
            this.grid[y][x]--;
            s.alive = false;
            this.burst(s.x, s.y, "#c19d84", 6);
            continue;
          }
          if (s.enemy) {
            if (hyp(s.x - this.p.x, s.y - this.p.y) < 21 && !this.hurt) {
              s.alive = false;
              this.hit();
            }
          } else for (const e of this.enemies) if (e.alive && hyp(s.x - e.x, s.y - e.y) < 21) {
            e.hp--;
            s.alive = false;
            if (e.hp <= 0) {
              e.alive = false;
              this.score += 100;
              this.burst(e.x, e.y, "#ffba7b", 20);
            }
            break;
          }
        }
        if (!this.enemies.some((e) => e.alive)) this.end(true, "KHU VỰC AN TOÀN");
      }
      // ----- Procedural, colored artwork. No external images or libraries. -----
      background(c) {
        let g = c.createLinearGradient(0, 0, W, H);
        g.addColorStop(0, "#101a32");
        g.addColorStop(1, "#090e20");
        c.fillStyle = g;
        c.fillRect(0, 0, W, H);
        for (let n = 0; n < 65; n++) {
          let x = (n * 173 + 19) % 800, y = (n * 83 + 47) % 450;
          c.globalAlpha = 0.18 + n % 4 * 0.08;
          circle(c, x, y, n % 9 === 0 ? 1.5 : 0.8, "#adc3ec");
        }
        c.globalAlpha = 1;
        if ([6, 7, 8, 10].includes(this.id)) {
          c.strokeStyle = "#283046";
          c.lineWidth = 0.5;
          for (let x = 0; x < 800; x += 40) {
            c.beginPath();
            c.moveTo(x, 0);
            c.lineTo(x, 450);
            c.stroke();
          }
          for (let y = 0; y < 450; y += 40) {
            c.beginPath();
            c.moveTo(0, y);
            c.lineTo(800, y);
            c.stroke();
          }
        }
      }
      ship(c, x, y, color, angle = -Math.PI / 2) {
        c.save();
        c.translate(x, y);
        c.rotate(angle);
        c.shadowColor = color;
        c.shadowBlur = 14;
        c.fillStyle = color;
        c.beginPath();
        c.moveTo(22, 0);
        c.lineTo(-15, -14);
        c.lineTo(-9, 0);
        c.lineTo(-15, 14);
        c.closePath();
        c.fill();
        c.shadowBlur = 0;
        circle(c, 0, 0, 4, "#122139");
        c.restore();
      }
      car(c, x, y, color) {
        c.save();
        c.translate(x, y);
        rr(c, -22, -23, 7, 16, 3, "#090e18");
        rr(c, 15, -23, 7, 16, 3, "#090e18");
        rr(c, -22, 13, 7, 16, 3, "#090e18");
        rr(c, 15, 13, 7, 16, 3, "#090e18");
        rr(c, -16, -34, 32, 66, 10, color);
        rr(c, -12, -18, 24, 14, 4, "#162b40");
        rr(c, -11, 15, 22, 10, 3, "#162b40");
        rr(c, -13, -31, 7, 4, 1, "#ffefb8");
        rr(c, 6, -31, 7, 4, 1, "#ffefb8");
        c.restore();
      }
      tankDraw(c, x, y, dir, color) {
        c.save();
        c.translate(x, y);
        c.rotate(dir * Math.PI / 2 + Math.PI / 2);
        rr(c, -20, -19, 8, 39, 3, "#31434b", "#82949b");
        rr(c, 12, -19, 8, 39, 3, "#31434b", "#82949b");
        rr(c, -12, -17, 24, 34, 4, color);
        circle(c, 0, 0, 10, "#345951");
        rr(c, -3, -30, 6, 29, 2, color);
        c.restore();
      }
      render(c) {
        var _a;
        c.save();
        this.background(c);
        const t = this.clock, p = this.p;
        if (this.extra) this.extra.render(this, c);
        if (this.id === 0) {
          let size = 32, ox = 64, oy = 17;
          for (let y = 0; y < 13; y++) for (let x = 0; x < 21; x++) {
            let v = this.grid[y][x], xx = ox + x * size, yy = oy + y * size;
            if (v === "#") rr(c, xx + 3, yy + 3, 26, 26, 6, "#172952", "#305bbb");
            else if (v === ".") circle(c, xx + 16, yy + 16, 2.3, "#ffe0a0");
            else if (v === "o") {
              c.shadowColor = "#ffdf87";
              c.shadowBlur = 12;
              circle(c, xx + 16, yy + 16, 5 + Math.sin(t * 7), "#ffdf87");
              c.shadowBlur = 0;
            }
          }
          if (!this.hurt || Math.floor(t * 9) % 2) {
            let x = ox + p.x * 32 + 16, y = oy + p.y * 32 + 16, a = this.dir * Math.PI / 2, m = 0.17 + 0.28 * Math.abs(Math.sin(t * 11));
            c.fillStyle = "#ffcc64";
            c.beginPath();
            c.moveTo(x, y);
            c.arc(x, y, 12, a + m, a + TAU - m);
            c.closePath();
            c.fill();
          }
          for (const e of this.enemies) {
            let x = ox + e.x * 32 + 16, y = oy + e.y * 32 + 16;
            rr(c, x - 11, y - 12, 22, 25, [11, 11, 3, 3], this.power ? "#829fff" : e.color);
            circle(c, x - 4, y - 2, 3.8, "#fff");
            circle(c, x + 4, y - 2, 3.8, "#fff");
            circle(c, x - 3, y - 2, 1.7, "#182442");
            circle(c, x + 5, y - 2, 1.7, "#182442");
          }
        }
        if (this.id === 1) {
          for (const e of this.enemies) {
            let co = COLORS[e.row + 2];
            rr(c, e.x - 20, e.y - 13, 40, 23, 6, co);
            rr(c, e.x - 28, e.y - 1, 56, 8, 3, co);
            rr(c, e.x - 11, e.y - 6, 6, 7, 1, "#11233c");
            rr(c, e.x + 5, e.y - 6, 6, 7, 1, "#11233c");
            line(c, e.x - 17, e.y + 11, e.x - 24, e.y + 18, co, 4);
            line(c, e.x + 17, e.y + 11, e.x + 24, e.y + 18, co, 4);
          }
          if (!this.hurt || Math.floor(t * 10) % 2) this.ship(c, p.x, 405, "#83c8ff");
          label(c, "WAVE ".concat(this.level), 30, 30, 13);
        }
        if (this.id === 2) {
          let cam = this.camera;
          c.save();
          c.translate(-cam, 0);
          for (let k = 0; k < 9; k++) {
            let x = k * 450;
            circle(c, x + 200, 390, 170, "#1b2741");
            circle(c, x + 400, 435, 120, "#233650");
          }
          for (const r of this.platforms) {
            rr(c, r.x, r.y, r.w, r.h, 6, "#344648", "#577567");
            rr(c, r.x, r.y, r.w, 7, 3, "#b3d28b");
          }
          for (const co of this.coins) if (co.alive) {
            c.save();
            c.translate(co.x, co.y);
            c.scale(0.6 + 0.4 * Math.abs(Math.cos(t * 3)), 1);
            circle(c, 0, 0, 9, "#ffd374");
            circle(c, 0, 0, 5, "#ffeaaf");
            c.restore();
          }
          for (const e of this.enemies) {
            rr(c, e.x - 16, e.y - 14, 32, 28, 9, "#e18a91");
            circle(c, e.x - 5, e.y - 4, 3, "#1b2037");
            circle(c, e.x + 7, e.y - 4, 3, "#1b2037");
          }
          if (!this.hurt || Math.floor(t * 10) % 2) {
            rr(c, p.x - 12, p.y - (this.crouch ? 2 : 18), 24, this.crouch ? 21 : 37, 7, "#ffb47e");
            rr(c, p.x - 9, p.y - 14, 20, 11, 4, "#fff0cf");
            circle(c, p.x + 5, p.y - 9, 2, "#293143");
          }
          line(c, 3300, 230, 3300, 388, "#adceb5", 5);
          c.fillStyle = "#c7ee94";
          c.beginPath();
          c.moveTo(3300, 230);
          c.lineTo(3350, 248);
          c.lineTo(3300, 267);
          c.fill();
          c.restore();
        }
        if (this.id === 3) {
          let ox = 300, oy = 24, sz = 20;
          rr(c, ox - 8, oy - 8, 216, 416, 10, "#0b1123", "#4e4b77");
          for (let y = 0; y < 20; y++) for (let x = 0; x < 10; x++) {
            rr(c, ox + x * sz + 1, oy + y * sz + 1, 18, 18, 3, this.board[y][x] ? COLORS[this.board[y][x] - 1] : "#161d34");
          }
          let gy = this.ty;
          while (this.fits(this.tx, gy + 1, this.rotation)) gy++;
          for (const [x, y] of this.shape()) {
            if (gy + y >= 0) rr(c, ox + (this.tx + x) * 20 + 2, oy + (gy + y) * 20 + 2, 16, 16, 3, null, "#807497");
            if (this.ty + y >= 0) rr(c, ox + (this.tx + x) * 20 + 1, oy + (this.ty + y) * 20 + 1, 18, 18, 3, COLORS[this.piece]);
          }
          label(c, "NEXT", 565, 66, 14, "#9c9ab8");
          for (const [x, y] of this.shape(this.next, 0)) rr(c, 565 + x * 22, 90 + y * 22, 20, 20, 4, COLORS[this.next]);
          label(c, "LINES", 180, 145, 14, "#9c9ab8", "center");
          label(c, String(this.lines), 180, 183, 34, "#d9bfff", "center");
          label(c, "L / R", 590, 250, 18);
          label(c, "ROTATE", 590, 275, 13);
        }
        if (this.id === 4) {
          circle(c, 655, 90, 43, "#503f70");
          for (let n = 0; n < 8; n++) circle(c, n * 135 - 60, 445, 95 + n % 2 * 25, "#253452");
          for (const e of this.pipes) {
            rr(c, e.x, -20, 65, e.y - 57, 12, "#539f9f", "#8ce0cc");
            rr(c, e.x, e.y + 77, 65, 500, 12, "#539f9f", "#8ce0cc");
            rr(c, e.x - 5, e.y - 93, 75, 16, 5, "#b7edd5");
            rr(c, e.x - 5, e.y + 77, 75, 16, 5, "#b7edd5");
          }
          c.save();
          c.translate(p.x, p.y);
          c.rotate(clamp(p.vy / 650, -0.45, 0.65));
          circle(c, 0, 0, 17, "#ffc085");
          circle(c, 5, -3, 11, "#fff0cb");
          circle(c, 8, -5, 3, "#19233a");
          rr(c, -16, 1, 19, 9, 5, "#e99578");
          c.fillStyle = "#ffe092";
          c.beginPath();
          c.moveTo(16, -2);
          c.lineTo(29, 4);
          c.lineTo(16, 8);
          c.fill();
          c.restore();
        }
        if (this.id === 5) {
          c.setLineDash([7, 15]);
          line(c, 400, 18, 400, 432, "#344b59");
          c.setLineDash([]);
          label(c, String(this.leftScore), 300, 105, 64, "#b0f0d9", "center");
          label(c, String(this.rightScore), 500, 105, 64, "#9bc5ff", "center");
          rr(c, 49, this.p.y - 48, 14, 96, 7, "#9ae5cb");
          rr(c, 737, this.right - 48, 14, 96, 7, "#9ec6ff");
          c.shadowColor = "#b8ffdf";
          c.shadowBlur = 16;
          circle(c, this.ball.x, this.ball.y, 10, "#e6fff5");
          c.shadowBlur = 0;
          label(c, "PLAYER 01", 50, 32, 12);
          label(c, "PLAYER 02", 750, 32, 12, "#c5d0ef", "right");
        }
        if (this.id === 6 || this.id === 7) {
          for (const o of this.obstacles) rr(c, o.x, o.y, o.w, o.h, 8, "#263242", "#716355");
          for (const e of this.enemies) {
            if (this.id === 6) {
              rr(c, e.x - 13, e.y - 13, 26, 26, 5, "#d9877c");
              rr(c, e.x - 8, e.y - 7, 16, 5, 2, "#fff1a9");
            } else {
              c.save();
              c.translate(e.x, e.y);
              c.rotate(t * 0.8);
              c.strokeStyle = "#ed9fec";
              c.lineWidth = 2;
              c.strokeRect(-12, -12, 24, 24);
              c.restore();
            }
          }
          if (!this.hurt || Math.floor(t * 10) % 2) this.ship(c, p.x, p.y, this.id === 7 ? "#8be7ff" : "#ffbe8a", (_a = this.aim) != null ? _a : -Math.PI / 2);
          if (this.id === 7) label(c, "BOMBS ".concat(this.bombs), 25, 30, 13, "#afeef7");
        }
        if (this.id === 8) {
          for (let y = 0; y < 450; y += 4) {
            let mid = this.road(y);
            c.fillStyle = "#202c34";
            c.fillRect(mid - 160, y, 320, 4);
            c.fillStyle = Math.floor((this.distance + y) / 35) % 2 ? "#f4d5a6" : "#855d57";
            c.fillRect(mid - 166, y, 6, 4);
            c.fillRect(mid + 160, y, 6, 4);
            if (Math.floor((this.distance + y) / 35) % 2 === 0) {
              c.fillStyle = "#667482";
              c.fillRect(mid - 54, y, 3, 4);
              c.fillRect(mid + 54, y, 3, 4);
            }
          }
          for (const e of this.enemies) this.car(c, e.x, e.y, e.color);
          if (!this.hurt || Math.floor(t * 10) % 2) this.car(c, p.x, p.y, "#ffc26e");
          label(c, "".concat(Math.round(Math.abs(this.speed) / 2), " km/h"), 30, 35, 20, "#ffd697");
          label(c, "".concat(Math.min(100, Math.floor(this.distance / 25)), "%"), 760, 35, 20, "#ffd697", "right");
        }
        if (this.id === 9) {
          let ox = 48, oy = 27;
          rr(c, ox - 8, oy - 8, 720, 412, 12, "#13241f", "#395c45");
          for (let y = 0; y < 18; y++) for (let x = 0; x < 32; x++) circle(c, ox + x * 22 + 11, oy + y * 22 + 11, 0.7, "#2c4936");
          this.snake.forEach((s, n) => {
            rr(c, ox + s.x * 22 + 1, oy + s.y * 22 + 1, 20, 20, n === 0 ? 7 : 5, n === 0 ? "#d4f7a1" : n % 2 ? "#94c978" : "#acd889");
          });
          let head = this.snake[0];
          circle(c, ox + head.x * 22 + 14, oy + head.y * 22 + 6, 2, "#243f31");
          circle(c, ox + head.x * 22 + 14, oy + head.y * 22 + 15, 2, "#243f31");
          if (this.fruit) {
            c.shadowColor = "#ffc387";
            c.shadowBlur = 14;
            circle(c, ox + this.fruit.x * 22 + 11, oy + this.fruit.y * 22 + 11, 7 + Math.sin(t * 5), "#ffc28c");
            c.shadowBlur = 0;
          }
        }
        if (this.id === 10) {
          rr(c, 48, 27, 704, 396, 5, "#1a292b", "#41534b");
          for (let y = 0; y < 14; y++) for (let x = 0; x < 25; x++) if (this.grid[y][x]) {
            let xx = 50 + x * 28, yy = 29 + y * 28;
            rr(c, xx + 1, yy + 1, 26, 26, 2, this.grid[y][x] === 2 ? "#9c7961" : "#69564b");
            line(c, xx + 2, yy + 14, xx + 26, yy + 14, "#463e3b", 2);
            line(c, xx + 14, yy + 1, xx + 14, yy + 14, "#463e3b", 2);
          }
          for (const e of this.enemies) this.tankDraw(c, e.x, e.y, e.dir, "#d39f82");
          if (!this.hurt || Math.floor(t * 10) % 2) this.tankDraw(c, p.x, p.y, this.dir, "#aad2b0");
        }
        for (const s of this.shots) {
          let offset = this.id === 2 ? this.camera : 0;
          c.shadowColor = s.enemy ? "#ff808f" : "#b7f3ff";
          c.shadowBlur = 8;
          circle(c, s.x - offset, s.y, s.enemy ? 4 : 3, s.enemy ? "#ff8da1" : "#d0f6ff");
        }
        c.shadowBlur = 0;
        for (const e of this.particles) {
          c.globalAlpha = Math.min(1, e.life * 2);
          circle(c, e.x - (this.id === 2 ? this.camera : 0), e.y, 2, e.color);
        }
        c.globalAlpha = 1;
        if (this.flash > 0) {
          c.fillStyle = "rgba(189,222,255,".concat(this.flash * 0.5, ")");
          c.fillRect(0, 0, W, H);
        }
        c.restore();
      }
    }
    globalThis.ContlGame = { Game, DEFS, W, H };
  })();
})();
