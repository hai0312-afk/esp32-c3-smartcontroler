/* Small offline compatibility layer; intentionally ES5 syntax for TV browsers. */
(function(){
 if(typeof window.globalThis==='undefined')window.globalThis=window;
 if(!window.fetch)window.fetch=function(url,opt){return new Promise(function(resolve,reject){var x=new XMLHttpRequest();opt=opt||{};x.open(opt.method||'GET',url,true);var h=opt.headers||{};Object.keys(h).forEach(function(k){x.setRequestHeader(k,h[k]);});x.onload=function(){resolve({ok:x.status>=200&&x.status<300,status:x.status,json:function(){return Promise.resolve().then(function(){
 if(typeof window.globalThis==='undefined')window.globalThis=window;return JSON.parse(x.responseText);});}});};x.onerror=function(){reject(new Error('Network error'));};x.send(opt.body||null);});};
 if(!window.requestAnimationFrame)window.requestAnimationFrame=function(f){return setTimeout(function(){
 if(typeof window.globalThis==='undefined')window.globalThis=window;f(performance.now());},16);};
 if(!String.prototype.padStart)String.prototype.padStart=function(n,s){var v=String(this),p=s||' ';if(v.length>=n)return v;while(v.length<n)v=p+v;return v.slice(v.length-n);};
 if(!Object.entries)Object.entries=function(o){return Object.keys(o).map(function(k){return[k,o[k]];});};
 if(window.NodeList&&!NodeList.prototype.forEach)NodeList.prototype.forEach=Array.prototype.forEach;
 if(!Element.prototype.matches)Element.prototype.matches=Element.prototype.webkitMatchesSelector||Element.prototype.msMatchesSelector;
 if(!Element.prototype.closest)Element.prototype.closest=function(s){var e=this;while(e){if(e.matches(s))return e;e=e.parentElement;}return null;};
 if(!Element.prototype.replaceChildren)Element.prototype.replaceChildren=function(){while(this.firstChild)this.removeChild(this.firstChild);for(var i=0;i<arguments.length;i++)this.appendChild(typeof arguments[i]==='string'?document.createTextNode(arguments[i]):arguments[i]);};
 if(window.CanvasRenderingContext2D&&!CanvasRenderingContext2D.prototype.roundRect)CanvasRenderingContext2D.prototype.roundRect=function(x,y,w,h,r){
  var a=Array.isArray(r)?r:[r||0];var q=[a[0],a[1]===undefined?a[0]:a[1],a[2]===undefined?a[0]:a[2],a[3]===undefined?(a[1]===undefined?a[0]:a[1]):a[3]];
  for(var i=0;i<4;i++)q[i]=Math.max(0,Math.min(Number(q[i])||0,w/2,h/2));
  this.moveTo(x+q[0],y);this.lineTo(x+w-q[1],y);this.quadraticCurveTo(x+w,y,x+w,y+q[1]);this.lineTo(x+w,y+h-q[2]);this.quadraticCurveTo(x+w,y+h,x+w-q[2],y+h);this.lineTo(x+q[3],y+h);this.quadraticCurveTo(x,y+h,x,y+h-q[3]);this.lineTo(x,y+q[0]);this.quadraticCurveTo(x,y,x+q[0],y);this.closePath();return this;
 };
 window.addEventListener('error',function(e){var el=document.getElementById('compatNotice');if(el){el.hidden=false;el.textContent='Trình duyệt gặp lỗi: '+(e.message||'không hỗ trợ tính năng')+'. Thử cập nhật trình duyệt hoặc dùng thiết bị khác. Fullscreen không bắt buộc.';}});
})();
