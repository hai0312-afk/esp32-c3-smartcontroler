/* 15 original web-only games. Loaded before games.js by the build, no external assets. */
'use strict';
(()=>{
const C=['#83cfff','#ffb685'],clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),TAU=Math.PI*2;
const defs=[
['prism','Prism Breaker','PHÁ GẠCH','#84d5fa','Phá ba lớp gạch bằng bóng và vợt năng lượng.','JOY1 X: vợt · R: thả bóng · L: vợt rộng'],
['orbit','Orbital Catch','PHẢN XẠ','#bbadff','Xoay lá chắn để thu 20 tín hiệu từ quỹ đạo.','JOY1 X: xoay · L: xoay chậm · R: khiên rộng'],
['crosswalk','Crosswalk','VƯỢT CHƯỚNG NGẠI','#a5e69e','Vượt sáu làn xe và đến ba điểm an toàn.','JOY1: di chuyển theo ô'],
['colors','Color Dock','PHÂN LOẠI','#ffa2d2','Hứng đúng màu, tránh màu khác. Thu 20 khối.','JOY1 X: di chuyển · L/R: đổi màu'],
['lander','Lunar Lander','ĐÁP TÀU','#bed3ed','Hạ cánh nhẹ lên bệ trước khi hết nhiên liệu.','JOY1 X: lực ngang · R: đẩy lên · L: phanh'],
['mines','Mine Survey','DÒ MÌN','#e4c689','Đánh dấu 12 quả mìn và mở các ô an toàn.','JOY1: chọn ô · R/SW1: mở · L: cắm cờ'],
['memory','Memory Circuit','TRÍ NHỚ','#d0adf4','Tìm tám cặp ký hiệu giống nhau. Có hai lượt xem nhanh.','JOY1: chọn ô · R/SW1: lật · L: xem nhanh'],
['warehouse','Warehouse Grid','ĐẨY THÙNG','#e8b991','Đẩy ba thùng đến các vị trí đánh dấu.','JOY1: đi/đẩy · L: hoàn tác · R: làm lại'],
['bubbles','Bubble Harbor','BẮN BÓNG','#9fe3dd','Nối ba bóng cùng màu, dọn sạch bến cảng.','JOY1 X: ngắm · R/SW1: bắn'],
['courier','Sky Courier','GIAO HÀNG','#efc576','Thả tám kiện hàng vào xe nhận, tránh drone.','JOY1: bay · R/SW1: thả hàng'],
['hockey','Paddle Clash','ĐỐI KHÁNG','#83cfff','Hai nửa sân, hai vợt. Ghi năm bàn để thắng.','P1 JOY1/SW1/L · P2 JOY2/SW2/R',2],
['duel','Arena Duel','ĐẤU TAY ĐÔI','#ffa993','Né đạn và bắn theo hướng di chuyển. Mỗi người có 5 máu.','SW1/SW2: bắn · L/R: khiên · hai JOY: đi',2],
['coins','Coin Sprint','TRANH ĐIỂM','#f2d983','Tranh 20 đồng xu hoặc dẫn điểm sau 60 giây.','SW1/SW2: lướt · L/R: xung đẩy · hai JOY: đi',2],
['trails','Trail Riders','ĐUA VỆT SÁNG','#a5a4ff','Tránh vệt sáng của cả hai xe. Thắng ba vòng.','JOY: rẽ · SW1/SW2: tăng tốc · L/R: nhảy vệt',2],
['rescue','Rescue Partners','PHỐI HỢP','#9ad9b1','Mỗi người đưa ba kiện cứu hộ về bệ của mình. Chung 3 mạng.','SW1/SW2: nhặt/thả · L/R: khiên · hai JOY: đi',2]
];
function box(c,x,y,w,h,color,r=6){c.fillStyle=color;c.beginPath();c.roundRect(x,y,w,h,r);c.fill();}
function dot(c,x,y,r,color){c.fillStyle=color;c.beginPath();c.arc(x,y,Math.max(0,r),0,TAU);c.fill();}
function text(c,s,x,y,n=16,color='#c4d6e8',align='center'){c.fillStyle=color;c.font=`600 ${n}px system-ui,sans-serif`;c.textAlign=align;c.fillText(s,x,y);}
function move(p,ax,ay,s,dt,min=22,max=778){const n=Math.max(1,Math.hypot(ax,ay));p.x=clamp(p.x+ax/n*s*dt,min,max);p.y=clamp(p.y+ay/n*s*dt,48,418);if(Math.hypot(ax,ay)>.25){p.dx=ax/n;p.dy=ay/n;}}
class Extra {
 constructor(id,rand){this.id=id;this.rand=rand;this.t=0;this.nav=0;this.lastDir=-1;this.items=[];this.players=[{x:180,y:225,dx:1,dy:0,hp:5,score:0,cd:0,shield:0,hurt:0,boost:0,carrying:-1},{x:620,y:225,dx:-1,dy:0,hp:5,score:0,cd:0,shield:0,hurt:0,boost:0,carrying:-1}];
  if(id===11){this.paddle=400;this.ball={x:400,y:386,vx:160,vy:-245};this.attached=true;this.stage=1;this.bricks();}
  if(id===12){this.angle=-Math.PI/2;this.spawn=0;this.caught=0;this.wide=0;}
  if(id===13){this.x=6;this.y=9;this.goals=0;for(let lane=2;lane<=7;lane++)for(let k=0;k<3;k++)this.items.push({x:k*300+this.rand()*60,y:lane,speed:(lane%2?1:-1)*(65+lane*12)});}
  if(id===14){this.x=400;this.color=0;this.spawn=0;this.caught=0;}
  if(id===15)this.resetLander();
  if(id===16){this.cx=0;this.cy=0;this.cells=Array.from({length:80},()=>({mine:false,open:false,flag:false,n:0}));this.placed=false;}
  if(id===17){this.cx=0;this.cy=0;this.cards=Array.from({length:16},(_,n)=>({value:n%8,open:false,done:false}));for(let n=15;n>0;n--){const k=Math.floor(this.rand()*(n+1));[this.cards[n],this.cards[k]]=[this.cards[k],this.cards[n]];}this.flips=[];this.hide=0;this.peek=0;this.peeks=2;this.moves=0;}
  if(id===18){this.undo=[];this.resetWarehouse();}
  if(id===19){this.grid=Array.from({length:7},(_,y)=>Array.from({length:12},()=>y<3?1+Math.floor(this.rand()*3):0));this.angle=-Math.PI/2;this.next=1+Math.floor(this.rand()*3);this.bubble=null;this.misses=0;}
  if(id===20){this.x=150;this.y=130;this.parcels=[];this.truck=630;this.delivered=0;this.spawn=0;this.drop=0;}
  if(id===21){this.ball={x:400,y:225,vx:130,vy:65};this.goalPause=0;}
  if(id===22)this.bullets=[];
  if(id===23){this.items=Array.from({length:9},()=>this.coin());}
  if(id===24){this.roundPause=0;this.setupTrails();}
  if(id===25){this.items=Array.from({length:6},(_,j)=>({x:280+j%3*120,y:110+Math.floor(j/3)*200,owner:-1,done:false}));this.hazards=Array.from({length:4},(_,j)=>({x:100+j*200,y:145+(j%2)*160,vx:j%2?100:-100}));}
 }
 coin(){return{x:60+this.rand()*680,y:65+this.rand()*340};}
 direction(i){let x=i.a[0],y=i.a[1];return Math.max(Math.abs(x),Math.abs(y))<.45?-1:Math.abs(x)>Math.abs(y)?(x>0?0:2):(y>0?1:3);}
 navStep(dt,i,fn){const d=this.direction(i);this.nav-=dt;if(d<0){this.lastDir=-1;return;}if(d!==this.lastDir||this.nav<=0){fn(d);this.nav=d!==this.lastDir?.27:.14;this.lastDir=d;}}
 selectGrid(dt,i,w,h){this.navStep(dt,i,d=>{this.cx=clamp(this.cx+[1,0,-1,0][d],0,w-1);this.cy=clamp(this.cy+[0,1,0,-1][d],0,h-1);});}
 bricks(){this.items=[];for(let y=0;y<4;y++)for(let x=0;x<10;x++)this.items.push({x:55+x*70,y:60+y*30,on:true,hp:y===0&&this.stage>1?2:1});}
 resetLander(){this.x=120;this.y=90;this.vx=20;this.vy=0;this.fuel=100;this.pad=470+this.rand()*150;}
 resetWarehouse(){this.x=4;this.y=5;this.crates=[{x:3,y:3},{x:5,y:3},{x:4,y:4}];this.targets=[{x:2,y:1},{x:4,y:1},{x:6,y:1}];this.undo=[];}
 wall(x,y){return x<=0||x>=8||y<=0||y>=6||(y===3&&(x===2||x===6));}
 setupTrails(){this.trails=Array.from({length:18},()=>Array(36).fill(0));this.riders=[{x:6,y:9,dir:0,want:0,jumps:3},{x:29,y:9,dir:2,want:2,jumps:3}];this.trails[9][6]=1;this.trails[9][29]=2;this.tick=[0,0];this.jumpPending=[false,false];}
 winner(g){let [a,b]=this.players;g.score=Math.max(a.score,b.score);g.end(true,a.score===b.score?'HÒA!':a.score>b.score?'PLAYER 1 THẮNG!':'PLAYER 2 THẮNG!');}
 lose(g,x,y){g.lives--;g.burst(x,y,'#ffa7a7');g.sound('hit');if(g.lives<=0)g.end(false,'HẾT LƯỢT!');}
 step(g,dt,i){this.t+=dt;const id=this.id;
  if(id===11){this.paddle=clamp(this.paddle+i.a[0]*420*dt,65,735);const b=this.ball,half=(i.b&1)?65:43;
   if(this.attached){b.x=this.paddle;b.y=385;if(i.p&6)this.attached=false;}
   else{b.x+=b.vx*dt;b.y+=b.vy*dt;if(b.x<12||b.x>788){b.x=clamp(b.x,12,788);b.vx*=-1;}if(b.y<20){b.y=20;b.vy=Math.abs(b.vy);}
    if(b.vy>0&&b.y>=380&&b.y<=408&&Math.abs(b.x-this.paddle)<half+9){b.y=379;b.vx=(b.x-this.paddle)*5;b.vy=-Math.sqrt(Math.max(18000,95000-b.vx*b.vx));g.sound('coin');}
    for(const a of this.items)if(a.on&&b.x>a.x-8&&b.x<a.x+64&&b.y>a.y-8&&b.y<a.y+28){a.hp--;if(!a.hp){a.on=false;g.score+=10;g.burst(b.x,b.y,'#83cfff',6);}b.vy*=-1;b.y+=Math.sign(b.vy)*6;break;}
    if(b.y>460){this.lose(g,b.x,430);this.attached=true;}
    if(!this.items.some(a=>a.on)){if(++this.stage>3)g.end(true);else{this.bricks();this.attached=true;}}
   }
  }
  if(id===12){this.angle+=i.a[0]*((i.b&1)?1.3:3)*dt;this.wide=Math.max(0,this.wide-dt);if((i.p&2)&&g.cool<=0){this.wide=.9;g.cool=3;}
   this.spawn-=dt;if(this.spawn<=0){this.spawn=.95;this.items.push({a:this.rand()*TAU,r:240,dead:false});}
   for(const a of this.items){a.r-=85*dt;if(a.r<=150&&!a.dead){a.dead=true;let delta=Math.atan2(Math.sin(a.a-this.angle),Math.cos(a.a-this.angle));if(Math.abs(delta)<(this.wide? .7:.32)){this.caught++;g.score+=25;g.sound('coin');if(this.caught>=20)g.end(true);}else this.lose(g,400+Math.cos(a.a)*150,225+Math.sin(a.a)*150);}}
   this.items=this.items.filter(a=>!a.dead);
  }
  if(id===13){this.navStep(dt,i,d=>{this.x=clamp(this.x+[1,0,-1,0][d],0,15);this.y=clamp(this.y+[0,1,0,-1][d],0,9);});
   for(const a of this.items){a.x+=a.speed*dt;if(a.x>880)a.x=-100;if(a.x<-110)a.x=880;}
   if(!g.hurt&&this.items.some(a=>a.y===this.y&&Math.abs(a.x-(40+this.x*48))<47)){this.lose(g,40+this.x*48,35+this.y*40);this.x=6;this.y=9;g.hurt=1;}
   if(this.y===0){this.goals++;g.score+=100;this.x=6;this.y=9;g.sound('coin');if(this.goals>=3)g.end(true);}
  }
  if(id===14){this.x=clamp(this.x+i.a[0]*350*dt,35,765);if(i.p&1)this.color=(this.color+2)%3;if(i.p&2)this.color=(this.color+1)%3;
   this.spawn-=dt;if(this.spawn<=0){this.spawn=.62;this.items.push({x:40+this.rand()*720,y:20,color:Math.floor(this.rand()*3),dead:false});}
   for(const a of this.items){a.y+=145*dt;if(a.y>380&&a.y<410&&Math.abs(a.x-this.x)<45&&!a.dead){a.dead=true;if(a.color===this.color){this.caught++;g.score+=20;g.sound('coin');}else this.lose(g,this.x,390);}if(a.y>465)a.dead=true;}
   this.items=this.items.filter(a=>!a.dead);if(this.caught>=20)g.end(true);if(this.t>90)g.end(false,'HẾT GIỜ!');
  }
  if(id===15){if(this.fuel>0){this.vx+=i.a[0]*45*dt;this.fuel=Math.max(0,this.fuel-Math.abs(i.a[0])*2*dt);if(i.b&2){this.vy-=88*dt;this.fuel=Math.max(0,this.fuel-10*dt);}if(i.b&1){this.vx*=Math.pow(.4,dt);this.vy*=Math.pow(.6,dt);this.fuel=Math.max(0,this.fuel-7*dt);}}
   this.vy+=34*dt;this.x+=this.vx*dt;this.y+=this.vy*dt;if(this.x<15||this.x>785){this.x=clamp(this.x,15,785);this.vx*=-.4;}if(this.y<25){this.y=25;this.vy=Math.abs(this.vy);}
   if(this.y>=385){if(Math.abs(this.x-this.pad)<49&&Math.abs(this.vx)<25&&Math.abs(this.vy)<45){g.score=500+Math.round(this.fuel*5);g.end(true,'HẠ CÁNH THÀNH CÔNG!');}else{this.lose(g,this.x,390);this.resetLander();}}
  }
  if(id===16){this.selectGrid(dt,i,10,8);const at=this.cy*10+this.cx,c=this.cells[at];if((i.p&1)&&!c.open)c.flag=!c.flag;
   if((i.p&6)&&!c.flag&&!c.open){if(!this.placed){this.placed=true;let choices=[];for(let n=0;n<80;n++)if(Math.abs(n%10-this.cx)>1||Math.abs(Math.floor(n/10)-this.cy)>1)choices.push(n);for(let k=0;k<12;k++){let j=Math.floor(this.rand()*choices.length);this.cells[choices.splice(j,1)[0]].mine=true;}this.cells.forEach((v,n)=>v.n=this.neighbors(n).filter(k=>this.cells[k].mine).length);}
    if(c.mine){c.open=true;g.lives=0;g.end(false,'CHẠM MÌN!');}else{let queue=[at],seen=new Set();while(queue.length){let n=queue.pop(),v=this.cells[n];if(seen.has(n)||v.flag||v.mine)continue;seen.add(n);v.open=true;if(!v.n)queue.push(...this.neighbors(n));}g.score=this.cells.filter(v=>v.open).length*10;if(this.cells.filter(v=>v.open&&!v.mine).length===68)g.end(true);}}
  }
  if(id===17){this.selectGrid(dt,i,4,4);this.peek=Math.max(0,this.peek-dt);if((i.p&1)&&this.peeks>0){this.peeks--;this.peek=.75;}
   if(this.hide>0){this.hide-=dt;if(this.hide<=0){this.flips.forEach(n=>this.cards[n].open=false);this.flips=[];}}
   if((i.p&6)&&this.hide<=0){const n=this.cy*4+this.cx,a=this.cards[n];if(!a.open&&!a.done){a.open=true;this.flips.push(n);if(this.flips.length===2){this.moves++;let [x,y]=this.flips;if(this.cards[x].value===this.cards[y].value){this.cards[x].done=this.cards[y].done=true;this.flips=[];g.score+=100;g.sound('coin');}else this.hide=.8;}if(this.cards.every(v=>v.done))g.end(true,'ĐÃ TÌM ĐỦ 8 CẶP!');}}
  }
  if(id===18){if(i.p&2)this.resetWarehouse();if((i.p&1)&&this.undo.length){let s=this.undo.pop();this.x=s.x;this.y=s.y;this.crates=s.crates;}
   this.navStep(dt,i,d=>{let dx=[1,0,-1,0][d],dy=[0,1,0,-1][d],x=this.x+dx,y=this.y+dy;if(this.wall(x,y))return;let b=this.crates.find(v=>v.x===x&&v.y===y);if(b&&(this.wall(x+dx,y+dy)||this.crates.some(v=>v.x===x+dx&&v.y===y+dy)))return;
    this.undo.push({x:this.x,y:this.y,crates:this.crates.map(v=>({...v}))});if(this.undo.length>120)this.undo.shift();if(b){b.x+=dx;b.y+=dy;}this.x=x;this.y=y;});
   let placed=this.targets.filter(t=>this.crates.some(v=>v.x===t.x&&v.y===t.y)).length;g.score=placed*100;if(placed===3)g.end(true,'KHO HÀNG HOÀN TẤT!');
  }
  if(id===19){this.angle=clamp(this.angle+i.a[0]*1.6*dt,-Math.PI+.25,-.25);if(!this.bubble&&(i.p&6)){this.bubble={x:400,y:403,vx:Math.cos(this.angle)*430,vy:Math.sin(this.angle)*430,color:this.next};this.next=1+Math.floor(this.rand()*3);}
   const b=this.bubble;if(b){b.x+=b.vx*dt;b.y+=b.vy*dt;if(b.x<151||b.x>649){b.x=clamp(b.x,151,649);b.vx*=-1;}
    let hit=b.y<49;for(let y=0;y<7;y++)for(let x=0;x<12;x++)if(this.grid[y][x]&&Math.hypot(b.x-(158+x*44),b.y-(48+y*44))<41)hit=true;
    if(hit){let best=null;for(let y=0;y<7;y++)for(let x=0;x<12;x++)if(!this.grid[y][x]){let near=y===0||this.bubbleNeighbors(x,y).some(([xx,yy])=>this.grid[yy][xx]);if(!near)continue;let d=Math.hypot(b.x-(158+x*44),b.y-(48+y*44));if(!best||d<best.d)best={x,y,d};}
     if(!best){g.end(false,'BẾN ĐÃ ĐẦY!');this.bubble=null;return;}const {x,y}=best;this.grid[y][x]=b.color;let cluster=[],q=[[x,y]],seen=new Set();while(q.length){let [xx,yy]=q.pop(),key=xx+','+yy;if(seen.has(key)||this.grid[yy][xx]!==b.color)continue;seen.add(key);cluster.push([xx,yy]);q.push(...this.bubbleNeighbors(xx,yy));}
     if(cluster.length>=3){cluster.forEach(([xx,yy])=>this.grid[yy][xx]=0);let attached=new Set(),todo=[];for(let xx=0;xx<12;xx++)if(this.grid[0][xx])todo.push([xx,0]);while(todo.length){let [xx,yy]=todo.pop(),key=xx+','+yy;if(attached.has(key)||!this.grid[yy][xx])continue;attached.add(key);todo.push(...this.bubbleNeighbors(xx,yy));}let popped=cluster.length;for(let yy=0;yy<7;yy++)for(let xx=0;xx<12;xx++)if(this.grid[yy][xx]&&!attached.has(xx+','+yy)){this.grid[yy][xx]=0;popped++;}g.score+=popped*10;g.sound('coin');}
     else if(++this.misses>=5){this.misses=0;if(this.grid[6].some(Boolean))g.end(false,'BẾN ĐÃ ĐẦY!');this.grid.pop();this.grid.unshift(Array.from({length:12},()=>1+Math.floor(this.rand()*3)));}
     this.bubble=null;if(this.grid.every(r=>r.every(v=>!v)))g.end(true);else if(this.grid[6].some(Boolean))g.end(false,'BÓNG CHẠM VẠCH!');
    }
   }
  }
  if(id===20){this.x=clamp(this.x+i.a[0]*240*dt,30,770);this.y=clamp(this.y+i.a[1]*210*dt,55,305);this.drop=Math.max(0,this.drop-dt);if((i.p&6)&&!this.drop){this.parcels.push({x:this.x,y:this.y,vy:80,dead:false});this.drop=.45;}
   this.truck-=85*dt;if(this.truck<-70)this.truck=860;this.spawn-=dt;if(this.spawn<=0){this.spawn=1.35;this.items.push({x:840,y:65+this.rand()*230});}
   for(const a of this.items){a.x-=170*dt;if(Math.hypot(a.x-this.x,a.y-this.y)<28&&!g.hurt){this.lose(g,this.x,this.y);g.hurt=1.4;}}
   this.items=this.items.filter(a=>a.x>-50);for(const a of this.parcels){a.vy+=250*dt;a.y+=a.vy*dt;if(a.y>=390){a.dead=true;if(Math.abs(a.x-this.truck)<48){this.delivered++;g.score+=100;g.sound('coin');}}}this.parcels=this.parcels.filter(a=>!a.dead);if(this.delivered>=8)g.end(true);if(this.t>90)g.end(false,'HẾT GIỜ GIAO HÀNG!');
  }
  if(id>=21)this.multi(g,dt,i);
 }
 neighbors(n){const x=n%10,y=Math.floor(n/10),out=[];for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){let a=x+dx,b=y+dy;if((dx||dy)&&a>=0&&a<10&&b>=0&&b<8)out.push(b*10+a);}return out;}
 bubbleNeighbors(x,y){return [[x-1,y],[x+1,y],[x,y-1],[x,y+1]].filter(([a,b])=>a>=0&&a<12&&b>=0&&b<7);}
 multi(g,dt,i){const id=this.id;
  for(let n=0;n<2;n++){let p=this.players[n],sw=n?8:4,sh=n?2:1;p.cd=Math.max(0,p.cd-dt);p.shield=Math.max(0,p.shield-dt);p.hurt=Math.max(0,p.hurt-dt);p.boost=Math.max(0,p.boost-dt);
   if(id!==24){move(p,i.a[n*2],i.a[n*2+1],p.boost?410:205,dt,id===21?(n?425:24):24,id===21?(n?776:375):776);}
   if((i.p&sh)&&p.cd<=0){p.shield=.8;p.cd=3;if(id===23){let other=this.players[1-n];if(dist(p,other)<100){other.x=clamp(other.x+(other.x-p.x)*.8,25,775);other.y=clamp(other.y+(other.y-p.y)*.8,50,410);}}if(id===24&&this.riders[n].jumps>0)this.jumpPending[n]=true;}
   if(i.p&sw){if(id===21)p.boost=.2;if(id===22&&p.boost<=0){this.bullets.push({x:p.x+p.dx*20,y:p.y+p.dy*20,vx:p.dx*390,vy:p.dy*390,owner:n,life:2});p.boost=.3;g.sound('shot');}if(id===23&&p.boost<=0&&p.hurt<=0){p.boost=.22;p.hurt=1.4;}if(id===25){if(p.carrying>=0){const a=this.items[p.carrying];a.owner=-1;a.x=p.x;a.y=p.y;if((n===0?p.x<95:p.x>705)&&p.score<3){a.done=true;p.score++;g.score+=100;g.sound('coin');}p.carrying=-1;}else{const j=this.items.findIndex(a=>!a.done&&a.owner<0&&dist(a,p)<34);if(j>=0){this.items[j].owner=n;p.carrying=j;}}}}
  }
  if(id===21){let b=this.ball;if(this.goalPause>0){this.goalPause-=dt;return;}b.x+=b.vx*dt;b.y+=b.vy*dt;b.vx*=Math.pow(.96,dt);b.vy*=Math.pow(.96,dt);if(b.y<49||b.y>417){b.y=clamp(b.y,49,417);b.vy*=-1;}
   for(let n=0;n<2;n++){let p=this.players[n],r=p.shield?35:23,d=dist(p,b);if(d<r+10){let dx=(b.x-p.x)/(d||1),dy=(b.y-p.y)/(d||1);if(!d){dx=n?-1:1;dy=0;}let speed=p.boost?540:340;b.x=p.x+dx*(r+11);b.y=p.y+dy*(r+11);b.vx=dx*speed;b.vy=dy*speed;}}
   if(b.x<12||b.x>788){if(b.y>150&&b.y<300){this.players[b.x<12?1:0].score++;g.score=Math.max(...this.players.map(p=>p.score));if(this.players.some(p=>p.score>=5))this.winner(g);this.ball={x:400,y:225,vx:b.x<12?-170:170,vy:65};this.goalPause=.65;}else{b.x=clamp(b.x,12,788);b.vx*=-1;}}
  }
  if(id===22){for(const b of this.bullets){b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt;const p=this.players[1-b.owner];if(b.life>0&&dist(b,p)<23){b.life=0;if(!p.shield&&!p.hurt){p.hp--;p.hurt=.3;g.burst(p.x,p.y,C[1-b.owner],7);}}}this.bullets=this.bullets.filter(b=>b.life>0&&b.x>0&&b.x<800&&b.y>40&&b.y<435);if(this.players.some(p=>p.hp<=0)){this.players.forEach(p=>p.score=Math.max(0,p.hp));this.winner(g);}}
  if(id===23){for(const a of this.items){const first=Math.floor(this.t*60)%2;for(const n of [first,1-first])if(dist(a,this.players[n])<25){this.players[n].score++;Object.assign(a,this.coin());g.sound('coin');break;}}g.score=Math.max(...this.players.map(p=>p.score));if(this.t>=60||this.players.some(p=>p.score>=20))this.winner(g);}
  if(id===24){if(this.roundPause>0){this.roundPause-=dt;if(this.roundPause<=0)this.setupTrails();return;}
   for(let n=0;n<2;n++){let d=this.direction({a:i.a.slice(n*2,n*2+2)}),r=this.riders[n];if(d>=0&&d!==(r.dir+2)%4)r.want=d;}
   const moving=this.riders.map((r,n)=>{this.tick[n]+=dt;const yes=this.tick[n]>=((i.b&(n?8:4))?.075:.13);if(yes)this.tick[n]=0;return yes;});if(moving.some(Boolean)){let next=this.riders.map((r,n)=>{if(!moving[n])return{x:r.x,y:r.y};r.dir=r.want;let jump=this.jumpPending[n]&&r.jumps>0;if(jump)r.jumps--;this.jumpPending[n]=false;let s=jump?3:1;return{x:r.x+[1,0,-1,0][r.dir]*s,y:r.y+[0,1,0,-1][r.dir]*s};});
    let dead=next.map((p,n)=>moving[n]&&(p.x<0||p.x>=36||p.y<0||p.y>=18||!!this.trails[p.y]?.[p.x]));if(next[0].x===next[1].x&&next[0].y===next[1].y)dead=[true,true];
    if(dead.some(Boolean)){if(!dead[0])this.players[0].score++;if(!dead[1])this.players[1].score++;g.score=Math.max(...this.players.map(p=>p.score));if(this.players.some(p=>p.score>=3))this.winner(g);else this.roundPause=1;}
    else next.forEach((p,n)=>{Object.assign(this.riders[n],p);this.trails[p.y][p.x]=n+1;});
   }
  }
  if(id===25){for(const h of this.hazards){h.x+=h.vx*dt;if(h.x<20||h.x>780){h.x=clamp(h.x,20,780);h.vx*=-1;}}
   for(let n=0;n<2;n++){const p=this.players[n];if(p.carrying>=0){this.items[p.carrying].x=p.x;this.items[p.carrying].y=p.y-24;}
    if(!p.shield&&!p.hurt&&this.hazards.some(h=>dist(h,p)<30)){this.lose(g,p.x,p.y);p.hurt=1.5;if(p.carrying>=0){let a=this.items[p.carrying];a.owner=-1;a.x=clamp(p.x,120,680);a.y=clamp(p.y,70,380);p.carrying=-1;}p.x=n?740:60;p.y=225;}}
   if(this.players.every(p=>p.score>=3))g.end(true,'CẢ HAI HOÀN THÀNH CỨU HỘ!');
  }
 }
 render(g,c){const id=this.id,palette=['#85cfff','#ffadbb','#b5e398'];
  if(id===11){text(c,`LỚP ${this.stage}/3`,400,32);for(const a of this.items)if(a.on)box(c,a.x,a.y,62,23,a.hp===2?'#e8d597':palette[Math.floor(a.y/30)%3]);box(c,this.paddle-((g._inputB&1)?65:43),399,(g._inputB&1)?130:86,12,'#d6edff');dot(c,this.ball.x,this.ball.y,9,'#fff3ba');if(this.attached)text(c,'R: THẢ BÓNG',400,290,19);}
  if(id===12){c.strokeStyle='#253c59';c.lineWidth=2;c.beginPath();c.arc(400,225,150,0,TAU);c.stroke();c.strokeStyle='#b4b1ff';c.lineWidth=13;c.beginPath();c.arc(400,225,150,this.angle-(this.wide?.7:.32),this.angle+(this.wide?.7:.32));c.stroke();dot(c,400,225,45,'#263250');text(c,this.caught+'/20',400,232,26);for(const a of this.items)dot(c,400+Math.cos(a.a)*a.r,225+Math.sin(a.a)*a.r,7,'#ffe4a0');}
  if(id===13){for(let y=0;y<10;y++)box(c,16,16+y*40,768,37,y<2||y>7?'#25453b':'#202d40',3);for(const a of this.items)box(c,a.x-38,24+a.y*40,76,24,palette[a.y%3]);box(c,25+this.x*48,19+this.y*40,30,28,'#ecfaba');text(c,'ĐÍCH '+this.goals+'/3',400,438,14);}
  if(id===14){text(c,`ĐÚNG ${this.caught}/20 · ${Math.max(0,90-Math.floor(this.t))}s`,400,30);for(const a of this.items)box(c,a.x-13,a.y-13,26,26,palette[a.color]);box(c,this.x-42,396,84,15,palette[this.color]);text(c,'L / R: ĐỔI MÀU',400,440,14);}
  if(id===15){box(c,0,402,800,48,'#374055',2);box(c,this.pad-58,399,116,8,'#9de5bf',2);text(c,'ĐÁP ÊM',this.pad,435,14);c.save();c.translate(this.x,this.y);c.rotate(this.vx/180);box(c,-15,-17,30,27,'#d2e5f3');box(c,-22,10,44,6,'#8ab9d5');if((g._inputB&2)&&this.fuel>0)dot(c,0,24,7+Math.sin(this.t*35)*3,'#ffb66f');c.restore();text(c,`NHIÊN LIỆU ${Math.ceil(this.fuel)}  VX ${Math.round(this.vx)}  VY ${Math.round(this.vy)}`,400,32,14);}
  if(id===16){for(let y=0;y<8;y++)for(let x=0;x<10;x++){const a=this.cells[y*10+x],xx=170+x*46,yy=39+y*46;box(c,xx,yy,42,42,a.open?'#263e4e':'#3e5266');if(a.flag)text(c,'⚑',xx+21,yy+28,22,'#ffd99c');else if(a.open&&(a.n||a.mine))text(c,a.mine?'×':a.n,xx+21,yy+28,20,a.mine?'#ffaaaa':palette[a.n%3]);}c.strokeStyle='#fff2ba';c.lineWidth=3;c.strokeRect(168+this.cx*46,37+this.cy*46,46,46);text(c,'12 MÌN · L: CỜ · R: MỞ',400,436,14);}
  if(id===17){for(let y=0;y<4;y++)for(let x=0;x<4;x++){let a=this.cards[y*4+x],xx=205+x*100,yy=35+y*93;box(c,xx,yy,89,81,a.done?'#2c574d':'#34415e');text(c,a.done||a.open||this.peek?['●','▲','■','◆','✚','✦','☾','♥'][a.value]:'?',xx+44,yy+52,32,a.done?'#adedd0':palette[a.value%3]);}c.strokeStyle='#e8d7ff';c.lineWidth=3;c.strokeRect(202+this.cx*100,32+this.cy*93,95,87);text(c,`LƯỢT ${this.moves} · XEM NHANH ${this.peeks}`,400,433,14);}
  if(id===18){for(let y=0;y<7;y++)for(let x=0;x<9;x++)box(c,157+x*54,30+y*54,51,51,this.wall(x,y)?'#455568':'#182a38',4);for(const a of this.targets)dot(c,182+a.x*54,55+a.y*54,14,'#739e91');for(const a of this.crates){box(c,163+a.x*54,36+a.y*54,40,40,'#d5a371');text(c,'×',183+a.x*54,64+a.y*54,30,'#5d483e');}dot(c,182+this.x*54,55+this.y*54,17,'#a6d9fa');text(c,'L: HOÀN TÁC · R: LÀM LẠI',400,435,14);}
  if(id===19){for(let y=0;y<7;y++)for(let x=0;x<12;x++)if(this.grid[y][x])dot(c,158+x*44,48+y*44,20,palette[this.grid[y][x]-1]);c.strokeStyle='#8297ac';c.lineWidth=3;c.beginPath();c.moveTo(400,412);c.lineTo(400+Math.cos(this.angle)*65,412+Math.sin(this.angle)*65);c.stroke();dot(c,400,412,18,palette[this.next-1]);if(this.bubble)dot(c,this.bubble.x,this.bubble.y,20,palette[this.bubble.color-1]);text(c,`THÊM HÀNG SAU ${5-this.misses} LẦN TRƯỢT`,400,18,12);}
  if(id===20){box(c,0,418,800,32,'#263c43');box(c,this.truck-46,385,92,29,'#a8d3b8');dot(c,this.truck-28,418,9,'#596779');dot(c,this.truck+28,418,9,'#596779');box(c,this.x-22,this.y-10,44,20,'#efcb7e');box(c,this.x-30,this.y-16,60,4,'#a8d5ed');for(const a of this.items)box(c,a.x-22,a.y-10,44,20,'#d38696');for(const a of this.parcels)box(c,a.x-7,a.y-7,14,14,'#d8ba89',2);text(c,`GIAO ${this.delivered}/8 · ${Math.max(0,90-Math.floor(this.t))}s`,400,30);}
  if(id>=21){const [a,b]=this.players;
   text(c,`P1  ${id===22?'HP '+a.hp:a.score}`,50,27,17,C[0],'left');text(c,id===23?Math.max(0,60-Math.floor(this.t))+'s':id===25?'MỖI NGƯỜI 3 KIỆN':id===24?'THẮNG 3 VÒNG':id===21?'5 BÀN':'ĐẤU TAY ĐÔI',400,27,14);text(c,`P2  ${id===22?'HP '+b.hp:b.score}`,750,27,17,C[1],'right');
   if(id===21){box(c,397,45,6,380,'#29455e',1);box(c,0,150,8,150,C[0],1);box(c,792,150,8,150,C[1],1);dot(c,this.ball.x,this.ball.y,10,'#ecf4dd');}
   if(id===22)for(const s of this.bullets)dot(c,s.x,s.y,5,C[s.owner]);
   if(id===23)for(const a of this.items){dot(c,a.x,a.y,10,'#f4d47e');dot(c,a.x,a.y,5,'#af864c');}
   if(id===24){for(let y=0;y<18;y++)for(let x=0;x<36;x++)if(this.trails[y][x])box(c,40+x*20,49+y*20,18,18,this.trails[y][x]===1?'#437794':'#98684f',2);this.riders.forEach((r,n)=>{box(c,39+r.x*20,48+r.y*20,20,20,C[n],3);text(c,'NHẢY '+r.jumps,n?735:65,437,12,C[n]);});if(this.roundPause>0)text(c,'VÒNG TIẾP THEO…',400,230,26);}
   if(id===25){box(c,20,50,75,368,'#193f58');box(c,705,50,75,368,'#583e2f');for(const a of this.items)if(!a.done)box(c,a.x-11,a.y-11,22,22,'#d3e6a6');for(const h of this.hazards)dot(c,h.x,h.y,16,'#d28094');}
   if(id!==24)this.players.forEach((p,n)=>{if(p.shield)dot(c,p.x,p.y,35,n?'#664b39':'#2b4e68');dot(c,p.x,p.y,21,C[n]);dot(c,p.x+p.dx*13,p.y+p.dy*13,5,'#142637');text(c,n?'2':'1',p.x,p.y+5,13,'#142637');});
  }
 }
}
globalThis.ContlExtra={defs,Extra};
})();
