/* Screen Wake Lock only: no fake key presses, inaudible audio or promises of OS control. */
'use strict';
(()=>{
class ScreenKeeper {
 constructor(onState){this.onState=onState;this.wanted=false;this.lock=null;this.pending=false;this.generation=0;this.state='off';}
 report(s){this.state=s;this.onState(s);}
 update(wanted){
  this.wanted=!!wanted;
  if(!wanted||document.hidden){this.generation++;this.pending=false;const old=this.lock;this.lock=null;if(old)Promise.resolve(old.release()).catch(()=>{});this.report(wanted?'hidden':'off');return;}
  if(this.lock&&!this.lock.released){this.report('active');return;}
  if(this.pending)return;
  if(!window.isSecureContext){this.report('insecure');return;}
  if(!navigator.wakeLock||typeof navigator.wakeLock.request!=='function'){this.report('unsupported');return;}
  const gen=++this.generation;this.pending=true;this.report('requesting');
  Promise.resolve().then(()=>navigator.wakeLock.request('screen')).then(lock=>{
   if(gen!==this.generation||!this.wanted||document.hidden){Promise.resolve(lock.release()).catch(()=>{});return;}
   if(lock.released){this.report('released');return;}
   this.lock=lock;this.report('active');lock.addEventListener('release',()=>{if(this.lock===lock){this.lock=null;this.report(this.wanted?'released':'off');}});
  }).catch(()=>{if(gen===this.generation)this.report('denied');}).then(()=>{if(gen===this.generation)this.pending=false;});
 }
}
globalThis.ContlWake={ScreenKeeper};
})();
