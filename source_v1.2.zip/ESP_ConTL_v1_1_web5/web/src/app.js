'use strict';
(() => {
const {Game,DEFS,W,H}=ContlGame,$=id=>document.getElementById(id);
const demo=/(?:[?&])demo=1(?:&|$)/.test(location.search)||location.protocol==='file:';
const load=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback;}catch{return fallback;}};
const save=(key,value)=>{try{localStorage.setItem(key,JSON.stringify(value));}catch{}};
let scores=load('contl-highscores',{});if(!scores||typeof scores!=='object')scores={};
let token='';try{token=sessionStorage.getItem('contl-token')||'';}catch{}
let socket=null,pairSocket=null,reconnectAt=0,pairReconnectAt=0,lastInputAt=0,lastNavAt=0,authed=false,allowed=false;
let remote={a:[0,0,0,0],b:0,p:true,h:0},pairInput={d:-1,b:0,p:true};
let profile=load('contl-device','desktop');if(!['tv','phone','desktop','tablet'].includes(profile))profile='desktop';
let inputMode=demo?'local':'esp',touchResets=[],touch={a:[0,0,0,0],b:0},touchEdges=0;
let menuEdge=false,duoHoldAt=0;
let releaseInput=false,bootPhase='black',bootAt=0,bootReady=false,introDone=false;
let view='device',selected=0,filter='all',game=null,manualPause=false,announced=false,settings=false,confirmAction=null;
let pin='',authBusy=false,focused=null,focusBeforeSettings=null,focusBeforeConfirm=null;
let keys=new Set(),pendingPress=0,remoteEdges=0,pairEdges=0,keyEdges=0,navDirection=-1,navDue=0;
let lastRaf=performance.now(),accumulator=0,lastUi=0,lastStatusAt=0,pingAt=0,pingId=0,latency=null;
let soundOn=false,audio=null;
const canvas=$('gameCanvas'),ctx=canvas.getContext('2d');
const groups={classic:[0,1,3,5,9,10,11,13,16,18,19],action:[1,2,6,7,8,10,12,15,20,21,22,23,24,25],casual:[3,4,5,9,14,16,17,18,19],duo:DEFS.filter(d=>d.players===2).map(d=>d.id)};
$('demoLabel').hidden=!demo;
let wakeEnabled=load('contl-wake',true)!==false;
const wakeTexts={off:'Giữ màn hình sáng: tắt hoặc không ở chế độ máy tính.',hidden:'Đã nhả khóa khi trang bị ẩn; sẽ thử lại khi quay về.',requesting:'Đang yêu cầu giữ màn hình sáng…',active:'Đang giữ màn hình sáng bằng Screen Wake Lock.',insecure:'HTTP không đủ quyền Wake Lock. Chỉnh Screen/Sleep của máy tính hoặc dùng helper Windows đi kèm ZIP.',unsupported:'Trình duyệt không hỗ trợ Wake Lock. Hãy chỉnh Screen/Sleep của máy tính.',denied:'Trình duyệt/thiết bị từ chối Wake Lock. Kiểm tra quyền, chế độ pin hoặc cài đặt nguồn.',released:'Hệ thống đã nhả Wake Lock. Nhấn Thử lại hoặc trở lại trang để yêu cầu lại.'};
const keeper=new ContlWake.ScreenKeeper(state=>{$('wakeStatus').textContent=wakeTexts[state];$('wakeBadge').textContent=state==='active'?'Wake Lock: đang bật':state==='off'?'Wake Lock: tắt':'Wake Lock: chưa bật';$('wakeBadge').title=wakeTexts[state];});
function updateWake(){keeper.update(wakeEnabled&&profile==='desktop');$('wakeBtn').textContent='Giữ màn hình sáng: '+(wakeEnabled?'bật':'tắt');}
$('wakeBtn').onclick=()=>{wakeEnabled=!wakeEnabled;save('contl-wake',wakeEnabled);updateWake();};$('wakeRetry').onclick=updateWake;
document.addEventListener('visibilitychange',updateWake);window.addEventListener('focus',updateWake);window.addEventListener('pagehide',()=>keeper.update(false));window.addEventListener('pageshow',updateWake);


function toast(text){$('toast').textContent=text;$('toast').classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').classList.remove('show'),3200);}
function clearInputEdges(){menuEdge=false;duoHoldAt=0;pendingPress=0;touchEdges=0;remoteEdges=0;pairEdges=0;keyEdges=0;accumulator=0;navDirection=-1;navDue=0;}
function root(){if(confirmAction)return $('confirmOverlay');if(settings)return $('settingsOverlay');if(view==='play'&&!$('gameOverlay').hidden)return $('gameOverlay');return $(view+'View');}
function buttons(){return [...root().querySelectorAll('[data-pad]')].filter(b=>!b.disabled&&b.getClientRects().length&&!b.closest('[hidden]'));}
function focus(el,scroll=true){if(!el||el.disabled)return;if(focused)focused.classList.remove('pad-focus');focused=el;el.classList.add('pad-focus');try{el.focus({preventScroll:true});}catch{el.focus();}if(scroll){try{el.scrollIntoView({block:'nearest',inline:'center',behavior:profile==='tv'?'auto':'smooth'});}catch{el.scrollIntoView();}}if(el.dataset.id!==undefined){selected=+el.dataset.id;renderHero();}}
function firstFocus(){let list=buttons();if(!list.includes(focused))focus(list[0],false);}
function moveFocus(d){const list=buttons();if(!list.length)return;if(!list.includes(focused)){focus(list[0]);return;}let a=focused.getBoundingClientRect(),ax=a.x+a.width/2,ay=a.y+a.height/2;
 // Shelf is a horizontal controller rail; scroll-to-focus works even off screen.
 if(focused.classList.contains('game-card')&&(d===0||d===2)){let cards=list.filter(e=>e.classList.contains('game-card')),i=cards.indexOf(focused);focus(cards[(i+(d===0?1:cards.length-1))%cards.length]);return;}
 let choices=list.filter(e=>e!==focused).map(e=>{let b=e.getBoundingClientRect(),x=b.x+b.width/2-ax,y=b.y+b.height/2-ay,forward=d===0?x:d===2?-x:d===1?y:-y,cross=(d===0||d===2)?Math.abs(y):Math.abs(x);return{e,forward,cross,score:forward+cross*3};}).filter(v=>v.forward>8).sort((a,b)=>a.score-b.score);
 if(choices.length)focus(choices[0].e);else{let i=list.indexOf(focused);focus(list[(i+((d===0||d===1)?1:list.length-1))%list.length]);}}
function setView(next){view=next;const duo=view==='play'&&twoPlayers();$('footerControls').textContent=duo?'P1: JOY1 / SW1 / L · P2: JOY2 / SW2 / R':'JOY1: điều hướng · J1 SW: chọn · J2 SW: quay lại / menu';$('footerHint').textContent=duo?'Giữ L+R 0,7s: menu · 4 nút 3s trên C3: thoát':'L / R đổi thể loại · Giữ 4 nút 3 giây trên C3: thoát Web Games';document.body.dataset.view=next;fitLayout();releaseInput=true;for(const name of ['device','pair','boot','library','play'])$(name+'View').hidden=name!==next;clearInputEdges();focus(null);if(next==='pair')focus($('pinPad').querySelector('button'),false);else firstFocus();window.scrollTo(0,0);updateTouch();}
function paintCover(c,id){c.width=480;c.height=270;const g=new Game(id,998+id),x=c.getContext('2d');
 if(id===6||id===7)g.enemies=[{x:125,y:130,alive:true},{x:600,y:90,alive:true},{x:650,y:340,alive:true},{x:210,y:340,alive:true}];
 if(id===8){g.speed=160;g.distance=380;g.p.x=g.road(g.p.y);g.enemies=[{x:g.road(125)-70,y:125,color:'#a8bcff',alive:true}];}
 if(id===4){g.pipes[0].x=420;g.pipes[1].x=700;}if(id===3){for(let yy=17;yy<20;yy++)for(let xx=0;xx<10;xx++)if((xx+yy)%4)g.board[yy][xx]=(xx%7)+1;g.ty=6;}
 x.scale(c.width/W,c.height/H);g.render(x);
}
function defs(){return DEFS.filter(d=>filter==='all'||groups[filter].includes(d.id));}
function renderHero(){const d=DEFS[selected];$('heroGenre').textContent=d.genre+' / TRÒ CHƠI';$('heroTitle').textContent=d.name;$('heroDescription').textContent=d.description;$('heroControls').textContent=d.controls;$('heroBest').textContent='Kỷ lục / '+(scores[selected]||0);$('selectedCount').textContent=String(selected+1).padStart(2,'0')+' / '+DEFS.length;paintCover($('heroCanvas'),selected);}
function renderGrid(){let list=defs();if(!list.some(d=>d.id===selected))selected=list[0].id;$('gameGrid').replaceChildren();$('gameCount').textContent=list.length;
 for(const d of list){let b=document.createElement('button');b.className='game-card';b.dataset.id=d.id;b.dataset.pad='';b.style.setProperty('--game',d.color);let c=document.createElement('canvas');c.setAttribute('aria-hidden','true');let body=document.createElement('div');body.className='card-body';let small=document.createElement('small');small.textContent=(d.players===2?'2P · ':d.webOnly?'WEB · ':'')+d.genre;let h=document.createElement('h3');h.textContent=d.name;body.append(small,h);let number=document.createElement('span');number.className='card-number';number.textContent=String(d.id+1).padStart(2,'0');b.append(c,body,number);b.onclick=()=>startGame(d.id);$('gameGrid').append(b);paintCover(c,d.id);}
 document.querySelectorAll('[data-filter]').forEach(b=>b.classList.toggle('active',b.dataset.filter===filter));renderHero();
}
function changeFilter(next){filter=next;renderGrid();focus($('gameGrid').querySelector(`[data-id="${selected}"]`));}
function library(){settings=false;confirmAction=null;$('settingsOverlay').hidden=true;$('confirmOverlay').hidden=true;game=null;manualPause=false;renderGrid();setView('library');focus($('gameGrid').querySelector(`[data-id="${selected}"]`));}
function twoPlayers(){return !!game&&DEFS[game.id].players===2;}
function twoPlayerControls(){return view==='play'&&twoPlayers()&&!overlay(performance.now())&&!settings&&!confirmAction;}
function startGame(id){resetTouch();game=new Game(id,Date.now()>>>0,beep);selected=id;manualPause=false;announced=false;keys.clear();$('gameTitle').textContent=DEFS[id].name;$('gameGenre').textContent=DEFS[id].genre;$('gameControls').textContent=DEFS[id].controls;$('livesBlock').hidden=[3,4,5,9,16,17,18,19,21,22,23,24].includes(id);$('keyboardControls').textContent=inputMode==='local'?(id===5?'W/S vợt trái · ↑/↓ vợt phải · Esc menu':'WASD / mũi tên = JOY1 · IJKL = JOY2 · Shift = L · Space = R · Enter = J1 SW · Esc = menu'):'J2 SW mở menu game · Giữ L + R + J1 SW + J2 SW 3 giây để thoát trên C3';if(inputMode==='local'&&profile==='tv')$('keyboardControls').textContent='Remote: mũi tên = JOY1 · OK = R · Back = Menu. Game cần 2 joystick/Pong nên dùng C3.';if(inputMode==='local'&&(profile==='phone'||profile==='tablet'))$('keyboardControls').textContent='Hai joystick cảm ứng + L/R/J1/J2. Có thể xoay máy ngang; không bắt buộc toàn màn hình.';if(twoPlayers())$('keyboardControls').textContent=inputMode==='esp'?'P1: JOY1 + SW1 + L · P2: JOY2 + SW2 + R · Giữ L+R 0,7s: menu':'P1: WASD + E (SW1) + Q (L) · P2: mũi tên + O (SW2) + U (R) · Esc: menu';
 if(twoPlayers()&&inputMode==='local'&&profile==='tv')$('keyboardControls').textContent='Hai người: nên dùng C3. Remote chỉ điều khiển P1 (mũi tên / OK).';if(twoPlayers()&&inputMode==='local'&&(profile==='phone'||profile==='tablet'))$('keyboardControls').textContent='P1: joystick trái + SW1/L · P2: joystick phải + SW2/R · Giữ L+R 0,7s: menu';
 $('pauseBtn').textContent=twoPlayers()?'Menu game · L+R 0,7s':'J2 SW / Menu game';
 document.querySelector('[data-touch="4"]').textContent=twoPlayers()?'P1 / SW1':'J1 / OK';document.querySelector('[data-touch="8"]').textContent=twoPlayers()?'P2 / SW2':'J2 / Menu';
 $('gameOverlay').hidden=true;setView('play');game.render(ctx);updateGameOverlay(performance.now());}
function confirm(title,text,action){resetTouch();focusBeforeConfirm=focused;confirmAction=action;$('confirmTitle').textContent=title;$('confirmText').textContent=text;$('confirmOverlay').hidden=false;clearInputEdges();focus($('confirmNo'),false);}
function dismissConfirm(){confirmAction=null;$('confirmOverlay').hidden=true;clearInputEdges();focus(focusBeforeConfirm,false);firstFocus();}
function openSettings(){resetTouch();focusBeforeSettings=focused;settings=true;$('settingsOverlay').hidden=false;clearInputEdges();focus($('soundBtn'),false);getStatus();}
function closeSettings(){settings=false;$('settingsOverlay').hidden=true;clearInputEdges();if(view==='play')updateGameOverlay(performance.now());focus(focusBeforeSettings,false);firstFocus();}
function remoteBlocked(now){return (!authed||socket?.readyState!==WebSocket.OPEN||!lastInputAt||now-lastInputAt>400);}
function blocked(now){return inputMode==='esp'&&remoteBlocked(now);}
function overlay(now){if(!game)return null;if(game.over)return{kind:'over',title:game.result,text:'Điểm '+game.score+' · Chọn hành động tiếp theo',icon:game.won?'✦':'↻'};if(blocked(now))return{kind:'offline',title:'Đang chờ tay cầm',text:'Không có dữ liệu mới. Game dừng an toàn, không tự chuyển sang bàn phím.',icon:'⌁'};if(inputMode==='esp'&&remote.p)return{kind:'hold',title:remote.h?'Giữ để thoát · '+Math.max(1,3-Math.floor(remote.h/1000)):'Thả hết các nút',text:'Thả hết trước 3 giây để tiếp tục. Giữ đủ 3 giây: về Home trên C3.',icon:'Ⅱ'};if(manualPause)return{kind:'pause',title:'Menu game',text:'JOY1 chọn · J1 SW xác nhận · J2 SW tiếp tục',icon:'Ⅱ'};return null;}
let lastOverlay='';
function updateGameOverlay(now){let state=overlay(now),kind=state?.kind||'';$('gameOverlay').hidden=!state;
 if(state){$('overlayIcon').textContent=state.icon;$('overlayTitle').textContent=state.title;$('overlayText').textContent=state.text;$('overlayContinue').hidden=kind!=='pause';}
 if(kind!==lastOverlay){clearInputEdges();lastOverlay=kind;if(state&&!settings&&!confirmAction)focus(kind==='pause'?$('overlayContinue'):$('overlayRestart'),false);}
}
function back(){if(confirmAction){dismissConfirm();return;}if(settings){closeSettings();return;}if(view==='pair'){pin=pin.slice(0,-1);renderPin();return;}if(view==='device'){toast('Chọn loại thiết bị để tiếp tục.');return;}if(view==='play'){if(game.over){confirm('Trở về thư viện?','Điểm đã được ghi lại trên trình duyệt.',library);}else{manualPause=!manualPause;clearInputEdges();updateGameOverlay(performance.now());}return;}if(view==='library')openSettings();}
function renderPin(){$('pinDigits').replaceChildren();for(let n=0;n<6;n++){let e=document.createElement('span');e.textContent=pin[n]||'·';if(n===pin.length)e.className='next';$('pinDigits').append(e);}}
function addPin(value){if(authBusy)return;if(value==='del')pin=pin.slice(0,-1);else if(value==='pair'){submitPin();return;}else if(pin.length<6)pin+=value;renderPin();}
for(const value of ['1','2','3','4','5','6','7','8','9','del','0','pair']){let b=document.createElement('button');b.dataset.pad='';b.dataset.pin=value;b.textContent=value==='del'?'⌫':value==='pair'?'Ghép':value;b.className=value==='pair'?'primary':'';b.onclick=()=>addPin(value);$('pinPad').append(b);}
async function submitPin(){if(demo||authBusy)return;if(pin.length!==6){$('pairMessage').textContent='Nhập đủ 6 số đang hiện trên OLED.';return;}authBusy=true;$('pairMessage').textContent='Đang xác nhận…';
 try{let r=await fetch('api/auth',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'code='+encodeURIComponent(pin)});let data=await r.json();if(!r.ok)throw Error(data.error||'Không ghép được.');token=data.token;try{sessionStorage.setItem('contl-token',token);}catch{};closePair();connectSocket();$('pairMessage').textContent='PIN đúng. Đang mở phiên điều khiển…';}
 catch(e){$('pairMessage').textContent=e.message;pin='';renderPin();}finally{authBusy=false;}}
function closePair(){const old=pairSocket;pairSocket=null;old?.close();lastNavAt=0;pairInput={d:-1,b:0,p:true};allowed=false;}
function forgetToken(){token='';authed=false;try{sessionStorage.removeItem('contl-token');}catch{};lastInputAt=0;remote={a:[0,0,0,0],b:0,p:true,h:0};}
function disconnect(){const old=socket;socket=null;old?.close();closePair();forgetToken();settings=false;game=null;confirmAction=null;$('settingsOverlay').hidden=true;$('confirmOverlay').hidden=true;pin='';renderPin();setView('pair');pairReconnectAt=0;}
function socketURL(path){return (location.protocol==='https:'?'wss://'+location.host:'ws://'+location.hostname+':81')+path;}
function connectPair(){if(demo||token||pairSocket)return;pairReconnectAt=performance.now()+2500;
 try{const ws=pairSocket=new WebSocket(socketURL('/pair'));
 ws.onopen=()=>{if(pairSocket===ws)$('pairState').textContent='Trang đã tới C3. Nhấn J2 SW trên OLED để cho phép điều khiển bàn phím PIN.';};
 ws.onmessage=e=>{if(pairSocket!==ws)return;let m;try{m=JSON.parse(e.data);}catch{return;}
  if(m.t==='pair'){allowed=!!m.allowed;$('pairState').textContent=allowed?'Đã cho phép. JOY1 chọn số, J1 SW nhập, J2 SW xóa.':'Nhìn OLED và nhấn J2 SW để cho phép bàn phím PIN.';}
  if(m.t==='nav'&&allowed&&Number.isInteger(m.d)&&m.d>=-1&&m.d<=3&&Number.isInteger(m.b)&&m.b>=0&&m.b<=15){if(!m.p)pairEdges|=m.b&~pairInput.b;pairInput={d:m.d,b:m.b,p:!!m.p};lastNavAt=performance.now();}
  if(m.t==='busy')$('pairState').textContent='C3 đang phục vụ một trang khác. Đóng trang cũ rồi thử lại; nếu cần thoát/vào lại Web Games trên C3.';
 };
 ws.onclose=()=>{if(pairSocket!==ws)return;pairSocket=null;allowed=false;lastNavAt=0;pairReconnectAt=performance.now()+2500;};ws.onerror=()=>{};
 }catch{pairSocket=null;}}
function connectSocket(){if(demo||!token)return;reconnectAt=performance.now()+2500;const old=socket;socket=null;old?.close();authed=false;lastInputAt=0;
 try{const ws=socket=new WebSocket(socketURL('/socket?token='+encodeURIComponent(token)));
 ws.onmessage=e=>{if(socket!==ws)return;if(typeof e.data!=='string')return;if(e.data.startsWith('P:')){let id=Number(e.data.slice(2));if(id===pingId)latency=performance.now()-id;return;}let m;try{m=JSON.parse(e.data);}catch{return;}
  if(m.t==='auth'){if(m.ok){authed=true;closePair();if(view==='pair'){inputMode='esp';beginBoot();}}else{forgetToken();if(view!=='device'&&inputMode==='esp')setView('pair');$('pairMessage').textContent='Phiên đã hết hạn. Nhập PIN mới trên OLED.';}}
  if(m.t==='busy'){toast('C3 đang có một trình duyệt điều khiển. Đóng phiên cũ.');if(view==='pair')$('pairMessage').textContent='PIN đúng nhưng phiên cũ vẫn mở. Đóng trang cũ hoặc vào lại Web Games trên C3.';}
  if(m.t==='input'&&authed&&Array.isArray(m.a)&&m.a.length===4&&m.a.every(Number.isFinite)&&Number.isInteger(m.b)&&m.b>=0&&m.b<=15){if(!m.p)remoteEdges|=m.b&~remote.b;remote={a:m.a.map(v=>Math.max(-1,Math.min(1,v/1000))),b:m.b,p:!!m.p,h:Number(m.h)||0};lastInputAt=performance.now();}
  if(m.t==='closed'){forgetToken();if(inputMode==='local'){toast('C3 đã thoát. Chế độ chơi cục bộ vẫn hoạt động.');return;}setView('pair');game=null;settings=false;confirmAction=null;$('settingsOverlay').hidden=true;$('confirmOverlay').hidden=true;$('pairState').textContent='C3 đã thoát Web Games. Mở lại trên C3, kết nối IP và nhập PIN mới.';}
 };
 ws.onclose=()=>{if(socket!==ws)return;authed=false;lastInputAt=0;latency=null;remote={a:[0,0,0,0],b:0,p:true,h:0};reconnectAt=performance.now()+2500;};ws.onerror=()=>{};
 }catch{socket=null;}}
async function getStatus(){if(demo){$('apAddress').textContent='DEMO / Không có C3';$('lanAddress').textContent='Chỉ bàn phím PC';return;}try{let r=await fetch('api/status',{cache:'no-store'});if(!r.ok)return;let s=await r.json();$('apAddress').textContent='AP '+(s.apIP||'—');$('lanAddress').textContent='LAN '+(s.lanIP||'chưa nối');}catch{}}
function armAudio(){try{audio??=new(window.AudioContext||window.webkitAudioContext)();if(audio.state!=='running')audio.resume().catch(()=>{});}catch{}}
function beep(kind){if(!soundOn||audio?.state!=='running')return;let now=audio.currentTime;if(kind==='shot'&&beep.last&&now-beep.last<.08)return;beep.last=now;let o=audio.createOscillator(),g=audio.createGain(),f={shot:280,jump:470,coin:850,tick:370,bonus:620,hit:110,lose:160,win:960}[kind]||440;o.type='triangle';o.frequency.setValueAtTime(f,now);o.frequency.exponentialRampToValueAtTime(kind==='lose'?50:f*1.3,now+.12);g.gain.setValueAtTime(.04,now);g.gain.exponentialRampToValueAtTime(.001,now+.14);o.connect(g);g.connect(audio.destination);o.start();o.stop(now+.16);}
function fullscreen(){
 const el=document.documentElement,fn=el.requestFullscreen||el.webkitRequestFullscreen||el.mozRequestFullScreen||el.msRequestFullscreen;
 const fallback='Thiết bị không cho bật toàn màn hình. Bạn vẫn chơi bình thường trong cửa sổ.';
 if(!fn){toast(fallback);$('settingsMessage').textContent=fallback;return;}
 let settled=false;const timer=setTimeout(()=>{if(!settled)toast('Chưa bật được fullscreen; giao diện vẫn sẵn sàng để chơi.');},1500);
 try{Promise.resolve(fn.call(el)).then(()=>{settled=true;clearTimeout(timer);toast('Đã gửi yêu cầu toàn màn hình.');},()=>{settled=true;clearTimeout(timer);toast(fallback);$('settingsMessage').textContent=fallback;});}
 catch(e){settled=true;clearTimeout(timer);toast(fallback);$('settingsMessage').textContent=fallback;}
}
function updateTouch(){
 const visible=inputMode==='local'&&(profile==='phone'||profile==='tablet')&&view==='play'&&!settings&&!confirmAction&&!manualPause&&!game?.over;
 $('touchControls').hidden=!visible;
 if(!visible)resetTouch();
}
function resetTouch(){touchResets.forEach(f=>f());touch.a=[0,0,0,0];touch.b=0;touchEdges=0;document.querySelectorAll('.touch-stick span').forEach(e=>e.style.transform='translate(0,0)');document.querySelectorAll('[data-touch]').forEach(e=>e.classList.remove('on'));}
function fitLayout(){
 const fit=(profile==='desktop'||profile==='tv')&&['device','pair','library','play'].includes(view)&&innerWidth>=800&&innerHeight>=560;
 document.documentElement.classList.toggle('console-fit',fit);
 document.documentElement.classList.toggle('compact-console',fit&&innerHeight<700);
 document.documentElement.style.setProperty('--rail-height',Math.round(Math.max(132,Math.min(245,innerHeight*.235)))+'px');
 if(fit)window.scrollTo(0,0);
}
window.addEventListener('resize',fitLayout);
document.addEventListener('fullscreenchange',fitLayout);document.addEventListener('webkitfullscreenchange',fitLayout);
function beginBoot(){
 bootPhase='black';bootReady=false;bootAt=performance.now();$('bootView').dataset.phase='black';
 $('bootPrompt').hidden=true;$('bootLogo').hidden=true;resetTouch();setView('boot');
}
function startIntro(){
 if(view!=='boot'||bootPhase!=='wait')return;
 bootPhase='intro';bootAt=performance.now();$('bootView').dataset.phase='intro';
 $('bootPrompt').hidden=true;$('bootLogo').hidden=false;clearInputEdges();
}
function updateBoot(now,k){
 if(bootPhase==='black'&&now-bootAt>=650){bootPhase='wait';$('bootView').dataset.phase='wait';$('bootPrompt').hidden=false;focus($('bootStart'),false);}
 if(bootPhase==='wait'){
  const fresh=!remoteBlocked(now)&&!remote.p;
  if((inputMode==='local'||fresh)&&!(remote.b&3)&&!k.b)bootReady=true;
  $('bootConnection').textContent=inputMode==='esp'&&!fresh?'Đang chờ tay cầm kết nối lại…':'Nhấn đồng thời L + R trên C3';
  if(bootReady&&((inputMode==='esp'&&fresh&&(remote.b&3)===3)||(inputMode==='local'&&(k.b&3)===3)||keys.has('Enter')))startIntro();
 }else if(bootPhase==='intro'&&now-bootAt>=2700){introDone=true;library();}
}
$('bootStart').onclick=startIntro;
function applyProfile(value){
 profile=value;save('contl-device',value);document.body.className='profile-'+value;fitLayout();
 $('profileLabel').textContent=({tv:'TV · Remote / C3',phone:'Điện thoại · Cảm ứng / C3',tablet:'Tablet · Cảm ứng / C3',desktop:'Máy tính · Bàn phím / C3'}[value])+' — chơi ngay, không bắt buộc toàn màn hình';
 $('localPlay').textContent=profile==='phone'||profile==='tablet'?'Chơi bằng cảm ứng — không dùng C3':profile==='tv'?'Chơi bằng remote — một số game cần C3':'Chơi bằng bàn phím — không dùng C3';
 $('inputSource').textContent='Nguồn điều khiển: '+(inputMode==='esp'?'C3':profile==='tv'?'Remote / bàn phím':profile==='phone'||profile==='tablet'?'Cảm ứng':'Bàn phím');updateTouch();updateWake();
}
function showDevice(){settings=false;confirmAction=null;game=null;$('settingsOverlay').hidden=true;$('confirmOverlay').hidden=true;setView('device');focus(document.querySelector('[data-device="'+profile+'"]'));}
function chooseDevice(value){applyProfile(value);if(inputMode==='local'||authed){if(introDone)library();else beginBoot();}else setView('pair');}
function localPlay(){inputMode='local';closePair();const old=socket;socket=null;old?.close();forgetToken();applyProfile(profile);beginBoot();}
function localInput(k){return{a:k.a.map((v,i)=>touch.a[i]||v),b:k.b|touch.b,p:false,h:0};}
function keyboard(){
 const yes=c=>keys.has(c),duo=twoPlayerControls();
 let a=[(yes('KeyD')?1:0)-(yes('KeyA')?1:0),(yes('KeyS')?1:0)-(yes('KeyW')?1:0),(yes('KeyL')?1:0)-(yes('KeyJ')?1:0),(yes('KeyK')?1:0)-(yes('KeyI')?1:0)];
 let base=duo&&profile!=='tv'?2:0;a[base]+=(yes('ArrowRight')?1:0)-(yes('ArrowLeft')?1:0);a[base+1]+=(yes('ArrowDown')?1:0)-(yes('ArrowUp')?1:0);
 let b=(yes('ShiftLeft')||yes('ShiftRight')?1:0)|(yes('Space')?2:0)|(yes('Enter')?actionBit('Enter'):0);
 if(duo)b|=(yes('KeyQ')?1:0)|(yes('KeyE')?4:0)|(yes('KeyU')?2:0)|(yes('KeyO')?8:0);else if(yes('Escape'))b|=8;
 return{a:a.map(v=>Math.max(-1,Math.min(1,v))),b,p:false,h:0};
}
function direction(a){return Math.max(Math.abs(a[0]),Math.abs(a[1]))<.5?-1:Math.abs(a[0])>Math.abs(a[1])?(a[0]>0?0:2):(a[1]>0?1:3);}
function navInput(now,k){if(inputMode==='local')return k;if(k.b||k.a.some(v=>v!==0))return k;
 if((view==='pair'||view==='device')&&!authed){if(!allowed||now-lastNavAt>400||pairInput.p)return k;let vectors=[[1,0],[0,1],[-1,0],[0,-1]];return{a:[...(vectors[pairInput.d]||[0,0]),0,0],b:pairInput.b,p:false};}
 return remoteBlocked(now)?k:remote;
}
function driveUI(now,input,pressed){if(input.p){navDirection=-1;return;}if(pressed&8){back();return;}if(view==='library'&&!settings&&!confirmAction&&(pressed&3)){let names=['all','classic','action','casual','duo'],at=names.indexOf(filter);changeFilter(names[(at+(pressed&2?1:names.length-1))%names.length]);return;}if(view==='pair'&&(pressed&2)){submitPin();return;}
 let d=direction(input.a);if(d<0)navDirection=-1;else if(d!==navDirection||now>=navDue){moveFocus(d);navDue=now+(d!==navDirection?380:125);navDirection=d;}
 if(pressed&4){firstFocus();if(focused&&buttons().includes(focused))focused.click();}}
function loop(now){let dt=Math.min(.05,(now-lastRaf)/1000);lastRaf=now;const k=localInput(keyboard()),ui=navInput(now,k),playing=!releaseInput&&view==='play'&&game&&!overlay(now)&&!settings&&!confirmAction;let input=playing?(inputMode==='local'?k:remote):ui;
 // Edges belong to the selected gameplay source; keyboard Escape remains a menu shortcut.
 const localEdges=keyEdges|touchEdges,pre=(view==='pair'||view==='device')&&!authed;
 let pressed=playing?(inputMode==='local'?localEdges:remoteEdges):localEdges|((demo||inputMode==='local')?0:pre?pairEdges:remoteEdges);
 const menuPressed=menuEdge;menuEdge=false;remoteEdges=pairEdges=keyEdges=touchEdges=0;
 if(releaseInput){
  const pre=view==='pair'||view==='device';
  if(!input.p&&!input.b&&input.a.every(v=>Math.abs(v)<.25)&&(pre||inputMode==='local'||!remoteBlocked(now)))releaseInput=false;
  pressed=0;pendingPress=0;navDirection=-1;
 }
 pendingPress|=pressed;
 if(view==='boot'){updateBoot(now,k);pendingPress=0;}else if(playing){
  if(twoPlayers()&&input.b===3&&!input.p){if(!duoHoldAt)duoHoldAt=now;}else duoHoldAt=0;
  if(menuPressed||(!twoPlayers()&&(pressed&8))||(duoHoldAt&&now-duoHoldAt>=700)){back();pendingPress=0;}else navDirection=-1;
 }else if(!releaseInput)driveUI(now,input,pressed);
 if(game&&view==='play'){
  if(game.over&&!announced){announced=true;if(game.score>(scores[game.id]||0)){scores[game.id]=game.score;save('contl-highscores',scores);}}
  let frozen=releaseInput||overlay(now)||settings||confirmAction;
  if(!frozen){let playInput=inputMode==='local'?k:remote;accumulator+=dt;let first=true;while(accumulator>=1/60){game.step(1/60,{a:playInput.a,b:playInput.b,p:first?pendingPress&(twoPlayers()?15:7):0});first=false;pendingPress=0;accumulator-=1/60;if(game.over)break;}}
  else {accumulator=0;pendingPress=0;}
  game.render(ctx);updateGameOverlay(now);
 }else pendingPress=0;
 if(now-lastUi>80){lastUi=now;let live=!remoteBlocked(now);updateTouch();$('statusDot').classList.toggle('online',inputMode==='esp'&&live);$('statusText').textContent=inputMode==='local'?(demo?'Demo · ':'')+'Chơi cục bộ':(view==='pair'||view==='device')?(allowed?'Bàn phím PIN đã bật':'Chờ ghép tay cầm'):live?'Tay cầm sẵn sàng':'Mất tín hiệu · đã dừng';$('clock').textContent=new Date().toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'});$('latency').textContent='RTT '+(latency===null?'—':Math.round(latency)+' ms');if(game){$('score').textContent=String(game.score).padStart(4,'0');$('best').textContent=String(scores[game.id]||0).padStart(4,'0');$('lives').textContent='● '.repeat(Math.max(0,game.lives));$('arenaLink').textContent=inputMode==='local'?'LOCAL / '+profile.toUpperCase():live?'C3 / LIVE':'C3 / PAUSED';}}
 if(!demo){if(token&&(!socket||socket.readyState===WebSocket.CLOSED)&&now>=reconnectAt)connectSocket();else if(!token&&(view==='pair'||view==='device')&&inputMode==='esp'&&!pairSocket&&now>=pairReconnectAt)connectPair();if(socket?.readyState===WebSocket.OPEN&&authed&&now-pingAt>=2000){pingAt=now;pingId=Math.round(now);socket.send('P:'+pingId);}if(settings&&now-lastStatusAt>2500){lastStatusAt=now;getStatus();}}
 requestAnimationFrame(loop);
}
$('heroPlay').onclick=()=>startGame(selected);$('settingsOpen').onclick=openSettings;$('closeSettings').onclick=closeSettings;$('pauseBtn').onclick=()=>{manualPause=true;updateGameOverlay(performance.now());};
$('filters').onclick=e=>{let b=e.target.closest('[data-filter]');if(b)changeFilter(b.dataset.filter);};
$('pinFullscreen').onclick=fullscreen;$('optionalFullscreen').onclick=fullscreen;$('settingsFullscreen').onclick=fullscreen;
$('localPlay').onclick=localPlay;$('pairDevice').onclick=showDevice;
document.querySelectorAll('[data-device]').forEach(b=>b.onclick=()=>chooseDevice(b.dataset.device));
$('deviceSettings').onclick=()=>confirm('Đổi loại thiết bị?','Lượt chơi hiện tại sẽ kết thúc; có thể chọn lại TV, điện thoại, tablet hoặc máy tính.',showDevice);
$('inputSource').onclick=()=>{if(inputMode==='local'&&!demo&&!authed){inputMode='esp';settings=false;game=null;$('settingsOverlay').hidden=true;setView('pair');pairReconnectAt=0;}else if(demo){toast('Demo không có ESP. Dùng bàn phím/cảm ứng theo thiết bị đã chọn.');}else{inputMode=inputMode==='esp'?'local':'esp';manualPause=!!game;resetTouch();clearInputEdges();}applyProfile(profile);};
$('overlayContinue').onclick=()=>{manualPause=false;clearInputEdges();updateGameOverlay(performance.now());};
$('overlayRestart').onclick=()=>confirm('Chơi lại từ đầu?','Điểm của lượt đang chơi sẽ không được giữ.',()=>{let id=game.id;dismissConfirm();startGame(id);});
$('overlayLibrary').onclick=()=>confirm('Trở về thư viện?','Lượt chơi hiện tại sẽ kết thúc.',library);$('overlaySettings').onclick=openSettings;
$('confirmNo').onclick=dismissConfirm;$('confirmYes').onclick=()=>{const action=confirmAction;dismissConfirm();action?.();};
$('soundBtn').onclick=()=>{soundOn=!soundOn;if(soundOn){armAudio();if(audio?.state!=='running')toast('Âm thanh chờ một lần nhấp/phím PC để trình duyệt cho phép.');else beep('coin');}$('soundBtn').textContent='Âm thanh: '+(soundOn?'bật':'tắt');};
$('networkInfo').onclick=()=>{getStatus();$('settingsMessage').textContent='HTTP 80 / WebSocket 81 · Một trình duyệt điều khiển · RTT là vòng đi-về, không phải tổng độ trễ joystick.';};
$('changeWifi').onclick=()=>{$('settingsMessage').textContent='Giữ 4 nút 3 giây về Home. Mở Web Games, chọn C3 Wi-Fi hoặc Wi-Fi nhà. JOY1 nhập mật khẩu trên OLED. Mạng nhà không lưu cho lần sau.';};
$('disconnectBtn').onclick=()=>{if(demo){toast('Bản demo không kết nối ESP32.');return;}confirm('Ngắt ghép trang web?','Game dừng. Muốn chơi lại, cho phép bàn phím PIN trên OLED rồi ghép lại.',disconnect);};
window.addEventListener('pointerdown',e=>{if(e.isTrusted)armAudio();},{once:true});
function touchEnabled(){return inputMode==='local'&&view==='play'&&!settings&&!confirmAction&&!manualPause&&!game?.over;}
function bindTouch(el,down,move,up){
 let owner=null;touchResets.push(()=>{owner=null;});
 const begin=(id,x,y,e)=>{if(owner!==null||!touchEnabled())return;e.preventDefault();owner=id;armAudio();down(x,y);};
 const drag=(id,x,y,e)=>{if(owner!==id)return;e.preventDefault();if(!touchEnabled()){owner=null;up();return;}move(x,y);};
 const end=(id,e)=>{if(owner!==id)return;e.preventDefault();owner=null;up();};
 if(window.PointerEvent){el.addEventListener('pointerdown',e=>{begin(e.pointerId,e.clientX,e.clientY,e);if(owner===e.pointerId)try{el.setPointerCapture(e.pointerId);}catch{}});el.addEventListener('pointermove',e=>drag(e.pointerId,e.clientX,e.clientY,e));['pointerup','pointercancel','lostpointercapture'].forEach(name=>el.addEventListener(name,e=>end(e.pointerId,e)));}
 else {el.addEventListener('touchstart',e=>{for(let i=0;i<e.changedTouches.length;i++){let t=e.changedTouches[i];begin(t.identifier,t.clientX,t.clientY,e);}},{passive:false});el.addEventListener('touchmove',e=>{for(let i=0;i<e.changedTouches.length;i++){let t=e.changedTouches[i];drag(t.identifier,t.clientX,t.clientY,e);}},{passive:false});['touchend','touchcancel'].forEach(name=>el.addEventListener(name,e=>{for(let i=0;i<e.changedTouches.length;i++)end(e.changedTouches[i].identifier,e);},{passive:false}));}
}
['touchJoy1','touchJoy2'].forEach((id,i)=>{const el=$(id),dot=el.querySelector('span');const move=(x,y)=>{let r=el.getBoundingClientRect(),radius=r.width*.36,dx=(x-r.left-r.width/2)/radius,dy=(y-r.top-r.height/2)/radius,scale=Math.max(1,Math.hypot(dx,dy));dx/=scale;dy/=scale;if(Math.hypot(dx,dy)<.14)dx=dy=0;touch.a[i*2]=dx;touch.a[i*2+1]=dy;dot.style.transform='translate('+(dx*radius*.65)+'px,'+(dy*radius*.65)+'px)';};bindTouch(el,move,move,()=>{touch.a[i*2]=touch.a[i*2+1]=0;dot.style.transform='translate(0,0)';});});
document.querySelectorAll('[data-touch]').forEach(el=>{let bit=+el.dataset.touch;bindTouch(el,()=>{touchEdges|=bit&~touch.b;touch.b|=bit;el.classList.add('on');},()=>{},()=>{touch.b&=~bit;el.classList.remove('on');});});
function tvPlaying(){return profile==='tv'&&inputMode==='local'&&view==='play'&&!manualPause&&!settings&&!confirmAction&&!game?.over;}
function actionBit(code){if(twoPlayerControls()){if(code==='Escape')return 0;if(['KeyQ','KeyE','KeyU','KeyO'].includes(code))return {KeyQ:1,KeyE:4,KeyU:2,KeyO:8}[code];}return code==='Enter'?(tvPlaying()&&!twoPlayers()?2:4):({ShiftLeft:1,ShiftRight:1,Space:2,Escape:8}[code]||0);}
function keyCode(e){
 if(e.code&&e.code!=='Unidentified')return e.code;
 const map={13:'Enter',37:'ArrowLeft',38:'ArrowUp',39:'ArrowRight',40:'ArrowDown',27:'Escape',8:'Backspace',461:'Escape',10009:'Escape',4:'Escape',32:'Space',9:'Tab',179:'Escape',403:'ShiftLeft',404:'Space'};
 if(map[e.keyCode])return map[e.keyCode];
 if(e.keyCode>=48&&e.keyCode<=57)return 'Digit'+(e.keyCode-48);
 if(['GoBack','Back','BrowserBack'].includes(e.key))return 'Escape';
 return e.key||'';
}
window.addEventListener('keydown',e=>{const code=keyCode(e);if(e.ctrlKey||e.altKey||e.metaKey)return;if(code==='Tab'){e.preventDefault();let list=buttons(),at=list.indexOf(focused);if(list.length)focus(list[(at+(e.shiftKey?list.length-1:1))%list.length]);return;}if(e.isTrusted)armAudio();if(view==='pair'&&!settings&&!confirmAction){if(/^Digit[0-9]$/.test(code)){e.preventDefault();if(!e.repeat)addPin(code.slice(-1));return;}if(code==='Backspace'){e.preventDefault();if(!e.repeat)addPin('del');return;}}
 if(code==='Backspace'){e.preventDefault();if(!e.repeat)back();return;}
 if(['KeyW','KeyA','KeyS','KeyD','KeyI','KeyJ','KeyK','KeyL','KeyQ','KeyE','KeyU','KeyO','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','ShiftLeft','ShiftRight','Space','Enter','Escape'].includes(code)){e.preventDefault();if(!keys.has(code)){if(code==='Escape'&&view==='play')menuEdge=true;keyEdges|=actionBit(code);}keys.add(code);}});
window.addEventListener('keyup',e=>keys.delete(keyCode(e)));
function loseFocus(){keys.clear();resetTouch();if(game&&!game.over)manualPause=true;clearInputEdges();}
window.addEventListener('blur',loseFocus);document.addEventListener('visibilitychange',()=>{if(document.hidden)loseFocus();});
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement&&view==='play')loseFocus();});
document.addEventListener('pointerdown',e=>{let b=e.target.closest('[data-pad]');if(b&&buttons().includes(b))focus(b,false);});
renderPin();renderGrid();applyProfile(profile);setView(view);focus(document.querySelector('[data-device="'+profile+'"]'));if(!demo){getStatus();if(token)connectSocket();else connectPair();}
requestAnimationFrame(loop);
window.contlInspect=()=>({view,demo,profile,inputMode,releaseInput,wakeState:keeper.state,wakeEnabled,bootPhase,bootReady,touch:{a:touch.a.slice(),b:touch.b},settings,confirm:!!confirmAction,focused:focused?.id||focused?.dataset.pin||focused?.dataset.id||focused?.dataset.filter||focused?.dataset.device||'',selected,filter,game:game?{id:game.id,players:DEFS[game.id].players,score:game.score,over:game.over}:null,blocked:blocked(performance.now()),pairAllowed:allowed,pinLength:pin.length,paused:!!(game&&(overlay(performance.now())||settings||confirmAction))});
})();
