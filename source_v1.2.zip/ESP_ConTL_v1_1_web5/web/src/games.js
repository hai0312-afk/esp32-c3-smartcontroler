/* ESP ConTL Web Arcade — original mini-games, HDZ463. No ROMs or external assets. */
'use strict';
(() => {
const W=800,H=450,TAU=Math.PI*2,clamp=(x,a,b)=>Math.max(a,Math.min(b,x)),hyp=Math.hypot;
const DEFS=[
 ['maze','Maze Munch','MÊ CUNG','#ffc861','Ăn chấm sáng, tránh những bóng ma.','JOY1 di chuyển'],
 ['invaders','Star Defenders','KHÔNG GIAN','#7cb6ff','Bảo vệ quỹ đạo qua từng đợt xâm lăng.','JOY1 trái/phải · R bắn'],
 ['platform','Pocket Platform','PHIÊU LƯU','#ff977a','Nhảy qua vực, nhặt xu và tìm lá cờ.','JOY1 đi/cúi · L chạy/bắn · R nhảy'],
 ['blocks','Falling Blocks','XẾP HÌNH','#bc9cff','Xoay, xếp và dọn những hàng khối màu.','JOY1 đi/rơi · L/R xoay · J1 SW thả'],
 ['flappy','Tiny Flap','MỘT NÚT','#ff8ec7','Một nhịp cánh, thêm một khoảng trời.','R hoặc J1 SW vỗ cánh'],
 ['pong','Duo Pong','HAI NGƯỜI','#73e2ce','Hai joystick. Hai phía. Bảy điểm để thắng.','JOY1 Y vợt trái · JOY2 Y vợt phải'],
 ['arena','Twin Arena','BẮN SONG CẦN','#fb9b72','Di chuyển giữa các chướng ngại và sống sót.','JOY1 di chuyển · JOY2 ngắm/bắn'],
 ['vector','Vector Storm','BẮN SONG CẦN','#93efff','Lướt giữa những hình khối không gian.','JOY1 đi · JOY2 bắn · R dùng bom'],
 ['racer','Micro Racer','ĐUA XE','#f7bd68','Giữ làn, tránh xe và chạm vạch đích.','JOY1 rẽ · R ga · L phanh/lùi'],
 ['snake','Garden Snake','CỔ ĐIỂN','#b8e978','Tìm trái sáng, đừng chạm vào chính mình.','JOY1 đổi hướng'],
 ['tanks','Mini Tanks','CHIẾN THUẬT','#a6cbb8','Phá tường gạch và hạ tám xe đối phương.','JOY1 bốn hướng · R bắn']
].concat(ContlExtra.defs).map((a,id)=>({id,players:id===5?2:(a[6]||1),webOnly:id>=11,slug:a[0],name:a[1],genre:a[2],color:a[3],description:a[4],controls:a[5]}));
const MAZE=[
'#####################','#.........#.........#','#.###.###.#.###.###.#','#o..#...........#..o#','###.#.#.#####.#.#.###','#.....#...#...#.....#','#.###.###.#.###.###.#','#...#...........#...#','###.#.#.#####.#.#.###','#.....#...#...#.....#','#.###.###.#.###.###.#','#o.................o#','#####################'];
const DIR=[[1,0],[0,1],[-1,0],[0,-1]];
const SHAPES=[[[0,1],[1,1],[2,1],[3,1]],[[1,0],[2,0],[1,1],[2,1]],[[1,0],[0,1],[1,1],[2,1]],[[1,0],[2,0],[0,1],[1,1]],[[0,0],[1,0],[1,1],[2,1]],[[0,0],[0,1],[1,1],[2,1]],[[2,0],[0,1],[1,1],[2,1]]];
const COLORS=['#80e5ff','#ffe485','#c7a0ff','#a8ed88','#ff8ba8','#88acff','#ffb881'];
function rr(c,x,y,w,h,r,fill,stroke){c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.stroke();}}
function circle(c,x,y,r,color){c.beginPath();c.arc(x,y,Math.max(0,r),0,TAU);c.fillStyle=color;c.fill();}
function line(c,x,y,xx,yy,color,width=2){c.beginPath();c.moveTo(x,y);c.lineTo(xx,yy);c.strokeStyle=color;c.lineWidth=width;c.stroke();}
function label(c,s,x,y,size=16,color='#c5d0ef',align='left'){c.fillStyle=color;c.font=`600 ${size}px ui-monospace,monospace`;c.textAlign=align;c.fillText(s,x,y);}
function aim(a,old=0){if(Math.max(Math.abs(a[0]),Math.abs(a[1]))<.35)return old;return Math.abs(a[0])>Math.abs(a[1])?(a[0]>0?0:2):(a[1]>0?1:3);}
class Game {
 constructor(id,seed=123456,sound=()=>{}){
  this.id=clamp(id|0,0,DEFS.length-1);this.seed=seed>>>0;this.sound=sound;this.score=0;this.lives=3;this.level=1;this.clock=0;this.over=false;this.won=false;this.result='';
  this.p={x:400,y:380,vx:0,vy:0};this.enemies=[];this.shots=[];this.particles=[];this.cool=0;this.hurt=0;this.timer=0;this.timer2=0;this.dir=0;this.want=0;this.bombs=3;this.flash=0;
  if(this.id>=11)this.extra=new ContlExtra.Extra(this.id,()=>this.rand());
  if(this.id===0){this.grid=MAZE.map(r=>r.split(''));this.p.x=1;this.p.y=1;this.left=0;this.power=0;this.grid.forEach(r=>r.forEach(v=>{if(v==='.'||v==='o')this.left++;}));this.ghosts();}
  if(this.id===1){this.wave();this.drift=1;}
  if(this.id===2){this.p={x:75,y:290,vx:0,vy:0};this.camera=0;this.platforms=[];for(let i=0;i<24;i++)if(i%7!==4)this.platforms.push({x:i*140,y:388,w:140,h:62});for(let i=0;i<6;i++)this.platforms.push({x:330+i*450,y:265-(i%2)*60,w:130,h:20});this.coins=[];for(let i=0;i<40;i++)this.coins.push({x:130+i*78,y:310-(i%4===0?100:0),alive:true});for(let i=0;i<13;i++){let x=250+i*210;if(this.groundAt(x,389))this.enemies.push({x,y:370,vx:-48,alive:true});}}
  if(this.id===3){this.board=Array.from({length:20},()=>Array(10).fill(0));this.next=this.randomInt(7);this.lines=0;this.repeat=0;this.lastMove=0;this.spawnPiece();}
  if(this.id===4){this.p.x=180;this.p.y=210;this.p.vy=0;this.pipes=Array.from({length:4},(_,i)=>({x:700+i*280,y:130+this.rand()*180,passed:false}));}
  if(this.id===5){this.p.y=225;this.right=225;this.leftScore=0;this.rightScore=0;this.ball={x:400,y:225,vx:260,vy:100};}
  if(this.id===6||this.id===7){this.p.y=225;this.obstacles=this.id===6?[{x:190,y:125,w:55,h:90},{x:550,y:250,w:55,h:90}]:[];}
  if(this.id===8){this.p.x=400;this.p.y=355;this.speed=0;this.distance=0;}
  if(this.id===9){this.snake=Array.from({length:5},(_,i)=>({x:10-i,y:9}));this.food();}
  if(this.id===10){this.p.x=120;this.p.y=370;this.dir=3;this.grid=Array.from({length:14},(_,y)=>Array.from({length:25},(_,x)=>(x%5===3&&y>2&&y<11&&y%4!==0)?2:0));for(let i=0;i<8;i++)this.enemies.push({x:110+i*80,y:65,dir:1,hp:2,alive:true});}
 }
 rand(){this.seed=(Math.imul(this.seed,1664525)+1013904223)>>>0;return this.seed/4294967296;}
 randomInt(n){return Math.floor(this.rand()*n);}
 end(win=false,text=''){this.over=true;this.won=win;this.result=text|| (win?'HOÀN THÀNH!':'THỬ THÊM MỘT LẦN?');this.sound(win?'win':'lose');}
 burst(x,y,color,n=12){for(let i=0;i<n&&this.particles.length<160;i++){let a=this.rand()*TAU,s=25+this.rand()*140;this.particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:.35+this.rand()*.45,color});}}
 hit(){if(this.hurt)return;this.lives--;this.hurt=1.4;this.burst(this.p.x,this.p.y,'#ff8194',24);this.sound('hit');if(this.lives<=0)this.end();}
 fire(x,y,vx,vy,enemy=false){if(this.shots.length<100)this.shots.push({x,y,vx,vy,enemy,alive:true});}
 step(dt,input){
  if(this.over)return;dt=clamp(dt,0,.04);this.clock+=dt;this.cool=Math.max(0,this.cool-dt);this.hurt=Math.max(0,this.hurt-dt);this.flash=Math.max(0,this.flash-dt);
  const handlers=['maze','invaders','platform','blocks','flappy','pong','twin','twin','racer','snakeStep','tanks'];this._inputB=input.b;if(this.extra)this.extra.step(this,dt,input);else this[handlers[this.id]](dt,input);
  for(const e of this.particles){e.x+=e.vx*dt;e.y+=e.vy*dt;e.life-=dt;}this.particles=this.particles.filter(e=>e.life>0);
  this.shots=this.shots.filter(e=>e.alive!==false);this.enemies=this.enemies.filter(e=>e.alive!==false);
 }
 wall(x,y){return !this.grid[y]||this.grid[y][x]===undefined||this.grid[y][x]==='#';}
 ghosts(){this.enemies=[{x:19,y:11,color:'#ff809d'},{x:19,y:1,color:'#a698ff'},{x:1,y:11,color:'#73d9e4'}];}
 maze(dt,i){
  this.want=aim(i.a,this.want);this.timer+=dt;this.timer2+=dt;this.power=Math.max(0,this.power-dt);
  if(this.timer>=.13){this.timer=0;let x=this.p.x,y=this.p.y;if(!this.wall(x+DIR[this.want][0],y+DIR[this.want][1]))this.dir=this.want;
   if(!this.wall(x+DIR[this.dir][0],y+DIR[this.dir][1])){this.p.x+=DIR[this.dir][0];this.p.y+=DIR[this.dir][1];}
   let v=this.grid[this.p.y][this.p.x];if(v==='.'||v==='o'){this.grid[this.p.y][this.p.x]=' ';this.left--;this.score+=10;if(v==='o'){this.power=5;this.sound('bonus');}if(!this.left)this.end(true);}
  }
  if(this.timer2>=.20){this.timer2=0;for(const e of this.enemies){let choices=[];DIR.forEach(([dx,dy],d)=>{if(!this.wall(e.x+dx,e.y+dy)){let n=Math.abs(e.x+dx-this.p.x)+Math.abs(e.y+dy-this.p.y);choices.push({d,cost:(this.power?-n:n)+this.rand()*6});}});choices.sort((a,b)=>a.cost-b.cost);if(choices.length){let d=choices[0].d;e.x+=DIR[d][0];e.y+=DIR[d][1];}}}
  for(const e of this.enemies)if(e.x===this.p.x&&e.y===this.p.y){if(this.power){e.x=this.p.x<10?19:1;e.y=this.p.y<6?11:1;this.score+=100;this.sound('bonus');}else if(!this.hurt){this.lives--;this.hurt=2;this.p.x=1;this.p.y=1;this.ghosts();if(this.lives<=0)this.end();break;}}
 }
 wave(){this.enemies=[];for(let r=0;r<3;r++)for(let col=0;col<7;col++)this.enemies.push({x:105+col*92,y:60+r*48,alive:true,row:r});}
 invaders(dt,i){
  this.p.x=clamp(this.p.x+i.a[0]*310*dt,35,765);if((i.b&2)&&!this.cool){this.fire(this.p.x,390,0,-550);this.cool=.16;this.sound('shot');}
  let edge=false;for(const e of this.enemies){e.x+=this.drift*(27+this.level*7)*dt;if(e.x<35||e.x>765)edge=true;if(e.y>355)this.end();}
  if(edge){this.drift*=-1;for(const e of this.enemies){e.y+=19;e.x+=this.drift*4;}}
  this.timer+=dt;if(this.timer>Math.max(.2,.9-this.level*.06)){this.timer=0;let e=this.enemies[this.randomInt(this.enemies.length)];if(e)this.fire(e.x,e.y,0,220+this.level*12,true);}
  for(const s of this.shots){s.x+=s.vx*dt;s.y+=s.vy*dt;if(s.y<0||s.y>H){s.alive=false;continue;}
   if(s.enemy){if(hyp(s.x-this.p.x,s.y-405)<24&&!this.hurt){s.alive=false;this.hit();}}
   else for(const e of this.enemies)if(e.alive&&Math.abs(s.x-e.x)<22&&Math.abs(s.y-e.y)<18){e.alive=s.alive=false;this.score+=20;this.burst(e.x,e.y,COLORS[e.row],15);break;}
  }
  if(!this.enemies.some(e=>e.alive)){this.level++;this.wave();this.shots=[];this.sound('bonus');}
 }
 groundAt(x,y){return this.platforms.some(r=>x>=r.x&&x<r.x+r.w&&y>=r.y&&y<r.y+r.h);}
 platform(dt,i){
  const p=this.p;let grounded=this.groundAt(p.x-9,p.y+20)||this.groundAt(p.x+9,p.y+20);this.crouch=grounded&&i.a[1]>.4;
  p.vx=this.crouch?0:i.a[0]*((i.b&1)?265:185);if(Math.abs(i.a[0])>.3)this.dir=i.a[0]<0?2:0;
  if((i.p&2)&&grounded){p.vy=-700;this.sound('jump');}p.vy=Math.min(600,p.vy+1250*dt);
  let nx=clamp(p.x+p.vx*dt,15,3330),ny=p.y+p.vy*dt,top=this.crouch?5:18;
  if(!this.groundAt(nx+(p.vx>=0?12:-12),p.y-top)&&!this.groundAt(nx+(p.vx>=0?12:-12),p.y+16))p.x=nx;
  let landed=false;for(const r of this.platforms){if(p.x+10>r.x&&p.x-10<r.x+r.w){if(p.vy>=0&&p.y+19<=r.y+2&&ny+19>=r.y){ny=r.y-19;p.vy=0;landed=true;}else if(p.vy<0&&p.y-top>=r.y+r.h&&ny-top<=r.y+r.h){ny=r.y+r.h+top;p.vy=0;}}}p.y=ny;
  if((i.b&1)&&!this.cool){this.fire(p.x,p.y,this.dir===2?-480:480,0);this.cool=.24;}
  for(const coin of this.coins)if(coin.alive&&hyp(coin.x-p.x,coin.y-p.y)<29){coin.alive=false;this.score+=10;this.burst(coin.x,coin.y,'#ffdf8d',7);this.sound('coin');}
  for(const e of this.enemies){if(this.groundAt(e.x+Math.sign(e.vx)*21,390))e.x+=e.vx*dt;else e.vx=-e.vx;
   if(Math.abs(e.x-p.x)<27&&Math.abs(e.y-p.y)<30){if(p.vy>60&&p.y<e.y-14){e.alive=false;p.vy=-320;this.score+=40;}else if(!this.hurt)this.hit();}}
  for(const s of this.shots){s.x+=s.vx*dt;if(Math.abs(s.x-p.x)>850||this.groundAt(s.x,s.y))s.alive=false;
   for(const e of this.enemies)if(e.alive&&hyp(s.x-e.x,s.y-e.y)<24){e.alive=s.alive=false;this.score+=30;this.burst(e.x,e.y,'#ffb083');}}
  if(p.y>500){this.lives--;if(this.lives<=0)this.end();else{p.x=75;p.y=290;p.vy=0;this.hurt=2;}}
  this.camera=clamp(p.x-250,0,2560);if(p.x>3290){this.score+=250;this.end(true);}
 }
 shape(piece=this.piece,rot=this.rotation){return SHAPES[piece].map(([x,y])=>{if(piece!==1)for(let r=0;r<rot;r++){let t=x;x=(piece===0?3:2)-y;y=t;}return[x,y];});}
 fits(x,y,r){return this.shape(this.piece,r).every(([xx,yy])=>{xx+=x;yy+=y;return xx>=0&&xx<10&&yy<20&&(yy<0||!this.board[yy][xx]);});}
 spawnPiece(){this.piece=this.next;this.next=this.randomInt(7);this.rotation=0;this.tx=3;this.ty=-1;this.timer=0;if(!this.fits(this.tx,this.ty,0))this.end();}
 lockPiece(){for(const[x,y]of this.shape()){if(y+this.ty<0){this.end();return;}this.board[y+this.ty][x+this.tx]=this.piece+1;}
  let count=0;for(let y=19;y>=0;y--)if(this.board[y].every(Boolean)){this.board.splice(y,1);this.board.unshift(Array(10).fill(0));count++;y++;}this.lines+=count;this.score+=count*count*100;if(count){this.flash=.15;this.sound('bonus');}this.spawnPiece();}
 blocks(dt,i){
  let move=i.a[0]<-.4?-1:i.a[0]>.4?1:0;this.repeat-=dt;
  if(move&&(this.repeat<=0||move!==this.lastMove)){if(this.fits(this.tx+move,this.ty,this.rotation))this.tx+=move;this.repeat=.13;}if(!move)this.repeat=0;this.lastMove=move;
  let r=this.rotation;if(i.p&1)r=(r+3)%4;if(i.p&2)r=(r+1)%4;
  if(r!==this.rotation)for(const kick of [0,-1,1,-2,2])if(this.fits(this.tx+kick,this.ty,r)){this.tx+=kick;this.rotation=r;this.sound('tick');break;}
  if(i.p&4){while(this.fits(this.tx,this.ty+1,this.rotation))this.ty++;this.lockPiece();return;}
  this.timer+=dt;if(this.timer> (i.a[1]>.4?.045:Math.max(.13,.65-this.lines*.014))){this.timer=0;if(this.fits(this.tx,this.ty+1,this.rotation))this.ty++;else this.lockPiece();}
 }
 flappy(dt,i){if(i.p&(2|4)){this.p.vy=-270;this.sound('jump');}this.p.vy+=730*dt;this.p.y+=this.p.vy*dt;if(this.p.y<18||this.p.y>430)this.end();
  for(const e of this.pipes){e.x-=(145+Math.min(25,this.score)*2)*dt;if(e.x< -90){e.x+=1120;e.y=120+this.rand()*200;e.passed=false;}
   if(!e.passed&&e.x+65<this.p.x){e.passed=true;this.score++;this.sound('coin');}
   if(e.x<this.p.x+15&&e.x+65>this.p.x-15&&(this.p.y-13<e.y-77||this.p.y+13>e.y+77))this.end();}}
 pong(dt,i){this.p.y=clamp(this.p.y+i.a[1]*325*dt,50,400);this.right=clamp(this.right+i.a[3]*325*dt,50,400);if(this.cool)return;let b=this.ball;b.x+=b.vx*dt;b.y+=b.vy*dt;
  if(b.y<12||b.y>438){b.vy*=-1;b.y=clamp(b.y,12,438);this.sound('tick');}
  if((b.x<73&&b.x>40&&b.vx<0&&Math.abs(b.y-this.p.y)<60)||(b.x>727&&b.x<760&&b.vx>0&&Math.abs(b.y-this.right)<60)){b.vy=(b.y-(b.vx<0?this.p.y:this.right))*5;b.vx=clamp(-b.vx*1.065,-570,570);this.burst(b.x,b.y,'#92f1d9',6);this.sound('tick');}
  if(b.x< -15||b.x>815){if(b.x<0)this.rightScore++;else this.leftScore++;this.score=Math.max(this.leftScore,this.rightScore);b.x=400;b.y=225;b.vx=b.vx>0?-270:270;b.vy=110;this.cool=.6;if(this.score===7)this.end(true,`${this.leftScore===7?'NGƯỜI 1':'NGƯỜI 2'} CHIẾN THẮNG`);}
 }
 obstruct(x,y,r=13){return this.obstacles.some(o=>x+r>o.x&&x-r<o.x+o.w&&y+r>o.y&&y-r<o.y+o.h);}
 twin(dt,i){let p=this.p,scale=Math.max(1,hyp(i.a[0],i.a[1])),nx=clamp(p.x+i.a[0]/scale*225*dt,20,780),ny=clamp(p.y+i.a[1]/scale*225*dt,20,430);
  if(!this.obstruct(nx,p.y))p.x=nx;if(!this.obstruct(p.x,ny))p.y=ny;
  let m=hyp(i.a[2],i.a[3]);if(m>.3&&!this.cool){this.fire(p.x,p.y,i.a[2]/m*600,i.a[3]/m*600);this.cool=this.id===7?.085:.125;this.aim=Math.atan2(i.a[3],i.a[2]);this.sound('shot');}
  if(this.id===7&&(i.p&2)&&this.bombs){this.bombs--;this.flash=.3;for(const e of this.enemies){e.alive=false;this.score+=20;this.burst(e.x,e.y,'#94e5ff',8);}this.sound('bonus');}
  this.timer+=dt;if(this.timer>Math.max(.22,.75-this.score/5000)){this.timer=0;let side=this.randomInt(4);if(this.enemies.length<50)this.enemies.push({x:side<2?(side?790:10):this.rand()*800,y:side>=2?(side===2?10:440):this.rand()*450,alive:true});}
  for(const e of this.enemies){if(!e.alive)continue;let dx=p.x-e.x,dy=p.y-e.y,d=hyp(dx,dy)||1,speed=(this.id===7?90:66)+Math.min(this.score/35,55);let ex=e.x+dx/d*speed*dt,ey=e.y+dy/d*speed*dt;
   if(!this.obstruct(ex,e.y,10))e.x=ex;else e.y+=Math.sign(dy||1)*speed*dt;
   if(!this.obstruct(e.x,ey,10))e.y=ey;else e.x+=Math.sign(dx||1)*speed*dt;
   if(d<25&&!this.hurt){e.alive=false;this.hit();}}
  for(const s of this.shots){s.x+=s.vx*dt;s.y+=s.vy*dt;if(s.x<0||s.x>800||s.y<0||s.y>450||this.obstruct(s.x,s.y,1)){s.alive=false;continue;}for(const e of this.enemies)if(e.alive&&hyp(e.x-s.x,e.y-s.y)<17){s.alive=e.alive=false;this.score+=20;this.burst(e.x,e.y,this.id===7?'#85e7ff':'#ffbd97');break;}}
 }
 road(y){return 400+110*Math.sin((this.distance+y*2)*.002);}
 racer(dt,i){if(i.b&2)this.speed=Math.min(340,this.speed+110*dt);else if(i.b&1)this.speed=Math.max(-70,this.speed-210*dt);else this.speed*=Math.pow(.986,dt*60);
  this.p.x=clamp(this.p.x+i.a[0]*245*dt*(this.speed<0?-1:1)*(.2+Math.abs(this.speed)/340),25,775);this.distance=Math.max(0,this.distance+this.speed*dt);this.score=Math.floor(this.distance);
  if(Math.abs(this.p.x-this.road(this.p.y))>138&&Math.abs(this.speed)>15){this.speed*=Math.pow(.95,dt*60);this.timer2+=dt;if(this.timer2>1){this.timer2=0;this.hit();}}else this.timer2=Math.max(0,this.timer2-dt);
  this.timer+=dt;if(this.timer>1.1&&this.speed>35){this.timer=0;this.enemies.push({y:-55,x:400,lane:(this.randomInt(3)-1)*82,alive:true,color:COLORS[this.randomInt(7)]});}
  for(const e of this.enemies){e.y+=(this.speed+35)*dt;e.x=this.road(e.y)+e.lane;if(e.y>520||e.y< -150)e.alive=false;if(Math.abs(e.x-this.p.x)<35&&Math.abs(e.y-this.p.y)<56&&!this.hurt){e.alive=false;this.speed=40;this.hit();}}
  if(this.distance>=2500)this.end(true,'VỀ ĐÍCH!');
 }
 food(){let free=[];for(let y=0;y<18;y++)for(let x=0;x<32;x++)if(!this.snake.some(e=>e.x===x&&e.y===y))free.push({x,y});if(!free.length){this.end(true);return;}this.fruit=free[this.randomInt(free.length)];}
 snakeStep(dt,i){let d=aim(i.a,this.dir);if(d!==(this.dir+2)%4)this.want=d;this.timer+=dt;if(this.timer<Math.max(.065,.15-this.score*.002))return;this.timer=0;this.dir=this.want;let p={x:this.snake[0].x+DIR[this.dir][0],y:this.snake[0].y+DIR[this.dir][1]},eat=p.x===this.fruit.x&&p.y===this.fruit.y;
  if(p.x<0||p.x>=32||p.y<0||p.y>=18||this.snake.slice(0,this.snake.length-(eat?0:1)).some(e=>e.x===p.x&&e.y===p.y)){this.end();return;}
  this.snake.unshift(p);if(eat){this.score++;this.food();this.sound('coin');}else this.snake.pop();}
 tankBlocked(x,y,r=14){if(x<65||x>735||y<43||y>408)return true;return [[-r,-r],[r,-r],[-r,r],[r,r]].some(([dx,dy])=>{let xx=Math.floor((x+dx-50)/28),yy=Math.floor((y+dy-29)/28);return this.grid[yy]?.[xx]>0;});}
 tanks(dt,i){if(Math.max(Math.abs(i.a[0]),Math.abs(i.a[1]))>.35){this.dir=aim(i.a,this.dir);let [dx,dy]=DIR[this.dir],nx=this.p.x+dx*155*dt,ny=this.p.y+dy*155*dt;if(!this.tankBlocked(nx,ny)){this.p.x=nx;this.p.y=ny;}}
  if((i.b&2)&&!this.cool){let[dx,dy]=DIR[this.dir];this.fire(this.p.x+dx*25,this.p.y+dy*25,dx*390,dy*390);this.cool=.22;this.sound('shot');}
  this.timer+=dt;let act=this.timer>.75;if(act)this.timer=0;
  for(const e of this.enemies){if(act){e.dir=aim([this.p.x-e.x,this.p.y-e.y]);if(this.rand()<.3)e.dir=this.randomInt(4);let[dx,dy]=DIR[e.dir];this.fire(e.x+dx*25,e.y+dy*25,dx*240,dy*240,true);}let [dx,dy]=DIR[e.dir],nx=e.x+dx*65*dt,ny=e.y+dy*65*dt;if(!this.tankBlocked(nx,ny)){e.x=nx;e.y=ny;}else if(this.rand()<.04)e.dir=this.randomInt(4);}
  for(const s of this.shots){s.x+=s.vx*dt;s.y+=s.vy*dt;if(s.x<50||s.x>750||s.y<29||s.y>421){s.alive=false;continue;}let x=Math.floor((s.x-50)/28),y=Math.floor((s.y-29)/28);
   if(this.grid[y]?.[x]){this.grid[y][x]--;s.alive=false;this.burst(s.x,s.y,'#c19d84',6);continue;}
   if(s.enemy){if(hyp(s.x-this.p.x,s.y-this.p.y)<21&&!this.hurt){s.alive=false;this.hit();}}
   else for(const e of this.enemies)if(e.alive&&hyp(s.x-e.x,s.y-e.y)<21){e.hp--;s.alive=false;if(e.hp<=0){e.alive=false;this.score+=100;this.burst(e.x,e.y,'#ffba7b',20);}break;}
  }
  if(!this.enemies.some(e=>e.alive))this.end(true,'KHU VỰC AN TOÀN');
 }
 // ----- Procedural, colored artwork. No external images or libraries. -----
 background(c){let g=c.createLinearGradient(0,0,W,H);g.addColorStop(0,'#101a32');g.addColorStop(1,'#090e20');c.fillStyle=g;c.fillRect(0,0,W,H);
  for(let n=0;n<65;n++){let x=(n*173+19)%800,y=(n*83+47)%450;c.globalAlpha=.18+(n%4)*.08;circle(c,x,y,n%9===0?1.5:.8,'#adc3ec');}c.globalAlpha=1;
  if([6,7,8,10].includes(this.id)){c.strokeStyle='#283046';c.lineWidth=.5;for(let x=0;x<800;x+=40){c.beginPath();c.moveTo(x,0);c.lineTo(x,450);c.stroke();}for(let y=0;y<450;y+=40){c.beginPath();c.moveTo(0,y);c.lineTo(800,y);c.stroke();}}
 }
 ship(c,x,y,color,angle=-Math.PI/2){c.save();c.translate(x,y);c.rotate(angle);c.shadowColor=color;c.shadowBlur=14;c.fillStyle=color;c.beginPath();c.moveTo(22,0);c.lineTo(-15,-14);c.lineTo(-9,0);c.lineTo(-15,14);c.closePath();c.fill();c.shadowBlur=0;circle(c,0,0,4,'#122139');c.restore();}
 car(c,x,y,color){c.save();c.translate(x,y);rr(c,-22,-23,7,16,3,'#090e18');rr(c,15,-23,7,16,3,'#090e18');rr(c,-22,13,7,16,3,'#090e18');rr(c,15,13,7,16,3,'#090e18');rr(c,-16,-34,32,66,10,color);rr(c,-12,-18,24,14,4,'#162b40');rr(c,-11,15,22,10,3,'#162b40');rr(c,-13,-31,7,4,1,'#ffefb8');rr(c,6,-31,7,4,1,'#ffefb8');c.restore();}
 tankDraw(c,x,y,dir,color){c.save();c.translate(x,y);c.rotate(dir*Math.PI/2+Math.PI/2);rr(c,-20,-19,8,39,3,'#31434b','#82949b');rr(c,12,-19,8,39,3,'#31434b','#82949b');rr(c,-12,-17,24,34,4,color);circle(c,0,0,10,'#345951');rr(c,-3,-30,6,29,2,color);c.restore();}
 render(c){c.save();this.background(c);const t=this.clock,p=this.p;if(this.extra)this.extra.render(this,c);
  if(this.id===0){let size=32,ox=64,oy=17;for(let y=0;y<13;y++)for(let x=0;x<21;x++){let v=this.grid[y][x],xx=ox+x*size,yy=oy+y*size;if(v==='#')rr(c,xx+3,yy+3,26,26,6,'#172952','#305bbb');else if(v==='.')circle(c,xx+16,yy+16,2.3,'#ffe0a0');else if(v==='o'){c.shadowColor='#ffdf87';c.shadowBlur=12;circle(c,xx+16,yy+16,5+Math.sin(t*7),'#ffdf87');c.shadowBlur=0;}}
   if(!this.hurt||Math.floor(t*9)%2){let x=ox+p.x*32+16,y=oy+p.y*32+16,a=this.dir*Math.PI/2,m=.17+.28*Math.abs(Math.sin(t*11));c.fillStyle='#ffcc64';c.beginPath();c.moveTo(x,y);c.arc(x,y,12,a+m,a+TAU-m);c.closePath();c.fill();}
   for(const e of this.enemies){let x=ox+e.x*32+16,y=oy+e.y*32+16;rr(c,x-11,y-12,22,25,[11,11,3,3],this.power?'#829fff':e.color);circle(c,x-4,y-2,3.8,'#fff');circle(c,x+4,y-2,3.8,'#fff');circle(c,x-3,y-2,1.7,'#182442');circle(c,x+5,y-2,1.7,'#182442');}}
  if(this.id===1){for(const e of this.enemies){let co=COLORS[e.row+2];rr(c,e.x-20,e.y-13,40,23,6,co);rr(c,e.x-28,e.y-1,56,8,3,co);rr(c,e.x-11,e.y-6,6,7,1,'#11233c');rr(c,e.x+5,e.y-6,6,7,1,'#11233c');line(c,e.x-17,e.y+11,e.x-24,e.y+18,co,4);line(c,e.x+17,e.y+11,e.x+24,e.y+18,co,4);}if(!this.hurt||Math.floor(t*10)%2)this.ship(c,p.x,405,'#83c8ff');label(c,`WAVE ${this.level}`,30,30,13);}
  if(this.id===2){let cam=this.camera;c.save();c.translate(-cam,0);for(let k=0;k<9;k++){let x=k*450;circle(c,x+200,390,170,'#1b2741');circle(c,x+400,435,120,'#233650');}for(const r of this.platforms){rr(c,r.x,r.y,r.w,r.h,6,'#344648','#577567');rr(c,r.x,r.y,r.w,7,3,'#b3d28b');}for(const co of this.coins)if(co.alive){c.save();c.translate(co.x,co.y);c.scale(.6+.4*Math.abs(Math.cos(t*3)),1);circle(c,0,0,9,'#ffd374');circle(c,0,0,5,'#ffeaaf');c.restore();}for(const e of this.enemies){rr(c,e.x-16,e.y-14,32,28,9,'#e18a91');circle(c,e.x-5,e.y-4,3,'#1b2037');circle(c,e.x+7,e.y-4,3,'#1b2037');}
   if(!this.hurt||Math.floor(t*10)%2){rr(c,p.x-12,p.y-(this.crouch?2:18),24,this.crouch?21:37,7,'#ffb47e');rr(c,p.x-9,p.y-14,20,11,4,'#fff0cf');circle(c,p.x+5,p.y-9,2,'#293143');}line(c,3300,230,3300,388,'#adceb5',5);c.fillStyle='#c7ee94';c.beginPath();c.moveTo(3300,230);c.lineTo(3350,248);c.lineTo(3300,267);c.fill();c.restore();}
  if(this.id===3){let ox=300,oy=24,sz=20;rr(c,ox-8,oy-8,216,416,10,'#0b1123','#4e4b77');for(let y=0;y<20;y++)for(let x=0;x<10;x++){rr(c,ox+x*sz+1,oy+y*sz+1,18,18,3,this.board[y][x]?COLORS[this.board[y][x]-1]:'#161d34');}
   let gy=this.ty;while(this.fits(this.tx,gy+1,this.rotation))gy++;for(const[x,y]of this.shape()){if(gy+y>=0)rr(c,ox+(this.tx+x)*20+2,oy+(gy+y)*20+2,16,16,3,null,'#807497');if(this.ty+y>=0)rr(c,ox+(this.tx+x)*20+1,oy+(this.ty+y)*20+1,18,18,3,COLORS[this.piece]);}
   label(c,'NEXT',565,66,14,'#9c9ab8');for(const[x,y]of this.shape(this.next,0))rr(c,565+x*22,90+y*22,20,20,4,COLORS[this.next]);label(c,'LINES',180,145,14,'#9c9ab8','center');label(c,String(this.lines),180,183,34,'#d9bfff','center');label(c,'L / R',590,250,18);label(c,'ROTATE',590,275,13);}
  if(this.id===4){circle(c,655,90,43,'#503f70');for(let n=0;n<8;n++)circle(c,n*135-60,445,95+n%2*25,'#253452');for(const e of this.pipes){rr(c,e.x,-20,65,e.y-57,12,'#539f9f','#8ce0cc');rr(c,e.x,e.y+77,65,500,12,'#539f9f','#8ce0cc');rr(c,e.x-5,e.y-93,75,16,5,'#b7edd5');rr(c,e.x-5,e.y+77,75,16,5,'#b7edd5');}
   c.save();c.translate(p.x,p.y);c.rotate(clamp(p.vy/650,-.45,.65));circle(c,0,0,17,'#ffc085');circle(c,5,-3,11,'#fff0cb');circle(c,8,-5,3,'#19233a');rr(c,-16,1,19,9,5,'#e99578');c.fillStyle='#ffe092';c.beginPath();c.moveTo(16,-2);c.lineTo(29,4);c.lineTo(16,8);c.fill();c.restore();}
  if(this.id===5){c.setLineDash([7,15]);line(c,400,18,400,432,'#344b59');c.setLineDash([]);label(c,String(this.leftScore),300,105,64,'#b0f0d9','center');label(c,String(this.rightScore),500,105,64,'#9bc5ff','center');rr(c,49,this.p.y-48,14,96,7,'#9ae5cb');rr(c,737,this.right-48,14,96,7,'#9ec6ff');c.shadowColor='#b8ffdf';c.shadowBlur=16;circle(c,this.ball.x,this.ball.y,10,'#e6fff5');c.shadowBlur=0;label(c,'PLAYER 01',50,32,12);label(c,'PLAYER 02',750,32,12,'#c5d0ef','right');}
  if(this.id===6||this.id===7){for(const o of this.obstacles)rr(c,o.x,o.y,o.w,o.h,8,'#263242','#716355');for(const e of this.enemies){if(this.id===6){rr(c,e.x-13,e.y-13,26,26,5,'#d9877c');rr(c,e.x-8,e.y-7,16,5,2,'#fff1a9');}else{c.save();c.translate(e.x,e.y);c.rotate(t*.8);c.strokeStyle='#ed9fec';c.lineWidth=2;c.strokeRect(-12,-12,24,24);c.restore();}}if(!this.hurt||Math.floor(t*10)%2)this.ship(c,p.x,p.y,this.id===7?'#8be7ff':'#ffbe8a',this.aim??-Math.PI/2);if(this.id===7)label(c,`BOMBS ${this.bombs}`,25,30,13,'#afeef7');}
  if(this.id===8){for(let y=0;y<450;y+=4){let mid=this.road(y);c.fillStyle='#202c34';c.fillRect(mid-160,y,320,4);c.fillStyle=(Math.floor((this.distance+y)/35)%2)?'#f4d5a6':'#855d57';c.fillRect(mid-166,y,6,4);c.fillRect(mid+160,y,6,4);if(Math.floor((this.distance+y)/35)%2===0){c.fillStyle='#667482';c.fillRect(mid-54,y,3,4);c.fillRect(mid+54,y,3,4);}}for(const e of this.enemies)this.car(c,e.x,e.y,e.color);if(!this.hurt||Math.floor(t*10)%2)this.car(c,p.x,p.y,'#ffc26e');label(c,`${Math.round(Math.abs(this.speed)/2)} km/h`,30,35,20,'#ffd697');label(c,`${Math.min(100,Math.floor(this.distance/25))}%`,760,35,20,'#ffd697','right');}
  if(this.id===9){let ox=48,oy=27;rr(c,ox-8,oy-8,720,412,12,'#13241f','#395c45');for(let y=0;y<18;y++)for(let x=0;x<32;x++)circle(c,ox+x*22+11,oy+y*22+11,.7,'#2c4936');this.snake.forEach((s,n)=>{rr(c,ox+s.x*22+1,oy+s.y*22+1,20,20,n===0?7:5,n===0?'#d4f7a1':(n%2?'#94c978':'#acd889'));});let head=this.snake[0];circle(c,ox+head.x*22+14,oy+head.y*22+6,2,'#243f31');circle(c,ox+head.x*22+14,oy+head.y*22+15,2,'#243f31');if(this.fruit){c.shadowColor='#ffc387';c.shadowBlur=14;circle(c,ox+this.fruit.x*22+11,oy+this.fruit.y*22+11,7+Math.sin(t*5),'#ffc28c');c.shadowBlur=0;}}
  if(this.id===10){rr(c,48,27,704,396,5,'#1a292b','#41534b');for(let y=0;y<14;y++)for(let x=0;x<25;x++)if(this.grid[y][x]){let xx=50+x*28,yy=29+y*28;rr(c,xx+1,yy+1,26,26,2,this.grid[y][x]===2?'#9c7961':'#69564b');line(c,xx+2,yy+14,xx+26,yy+14,'#463e3b',2);line(c,xx+14,yy+1,xx+14,yy+14,'#463e3b',2);}for(const e of this.enemies)this.tankDraw(c,e.x,e.y,e.dir,'#d39f82');if(!this.hurt||Math.floor(t*10)%2)this.tankDraw(c,p.x,p.y,this.dir,'#aad2b0');}
  for(const s of this.shots){let offset=this.id===2?this.camera:0;c.shadowColor=s.enemy?'#ff808f':'#b7f3ff';c.shadowBlur=8;circle(c,s.x-offset,s.y,s.enemy?4:3,s.enemy?'#ff8da1':'#d0f6ff');}c.shadowBlur=0;
  for(const e of this.particles){c.globalAlpha=Math.min(1,e.life*2);circle(c,e.x-(this.id===2?this.camera:0),e.y,2,e.color);}c.globalAlpha=1;
  if(this.flash>0){c.fillStyle=`rgba(189,222,255,${this.flash*.5})`;c.fillRect(0,0,W,H);}c.restore();
 }
}
globalThis.ContlGame={Game,DEFS,W,H};
})();
