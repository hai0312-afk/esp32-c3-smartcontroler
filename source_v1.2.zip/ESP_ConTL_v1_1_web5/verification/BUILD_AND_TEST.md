# ESP ConTL v1.1 / web5 — build và kiểm thử

Ngày **2026-10-08**. Không có ESP/OLED/TV/Windows thật gắn với môi trường này. Screenshot là Chromium; Wake Lock và controller trong test được mô phỏng, không phải phép đo OS sleep hay RF.

## Build cuối: PASS 4 cấu hình

Core esp32 **3.0.7**, NimBLE **2.3.6**, WebSockets **2.6.1**, SSD1306 **2.5.13**, GFX **1.11.11**, BusIO **1.17.4**. Lệnh/FQBN: `compile_all.sh`.

| Cấu hình | Flash bytes | Static/global RAM bytes |
|---|---:|---:|
| C3 controller + CDC | 1,363,234 | 54,068 |
| S3 USB bridge + TinyUSB/CDC | 933,229 | 61,624 |
| ESP32 Receiver_Test | 915,933 | 45,624 |
| C3 Receiver_Test + CDC | 938,270 | 36,092 |

Log: `compile_web5.txt`. RAM tĩnh không phải heap runtime. Assets cuối được embed và đối chiếu giải nén với nguồn: **48.059 byte gzip** = compat 1.288 + HTML 3.760 + CSS 7.270 + games 21.738 + app 14.003.

Đối chiếu file: `SmartController_C3/Games.cpp` và toàn bộ S3/Receiver_Test giữ nguyên web4. Mã OLED vẫn 11 game; 15 game mới nằm trong `web/src/extra_games.js`, gộp vào `games.js`, chạy trên browser. Wake Lock cũng chạy phía browser. C3 thay assets và tag bản build, không thêm 15 engine vào loop OLED.

## Host logic: PASS

`host_web5.txt`, C++ ASan/UBSan: 11 game OLED × 30.000 tick = 330.000 tick; protocol/HID/debounce/calibration/charge, OLED pump/recovery/wrap, UI/discovery/bàn phím OLED, heartbeat và HomeJoinPolicy web4. Không chạy radio/Wire thực hoặc toàn bộ firmware bằng host stub.

## Game web: PASS

`web_games_web5.txt`: **26 engine × 30.000 tick = 780.000 tick**. Random input/restart, finite numeric state, particle/shot bounds, render mock, invariants cũ.

`extra_games_web5.txt`:
- Đúng 26 metadata; 15 web-only; đúng 5 game hai người mới. Thêm Duo Pong cũ thành 6 mục hai người.
- Điều kiện thắng của cả 10 game solo mới; lander hạ cánh/crash, first-click Mine Survey trên 30 seed, Memory đủ 8 cặp, Bubble ghép 3 và dọn board.
- Warehouse: solver tìm và chạy lại **27 bước đi/đẩy hợp lệ** trên board thật; không đặt thùng thẳng lên đích để giả lập thắng. Kiểm tra undo.
- Năm game 2P: trục riêng, bit SW1/SW2/L/R đúng người, SW1 turbo không tăng tốc xe P2, điểm/thắng/thua và cứu hộ mỗi người 3 kiện.

Các focused win tests phần lớn thiết lập trạng thái gần thắng để kiểm tra luật; không thay thế chơi thử toàn bộ độ khó/cân bằng. Fuzzer không chứng minh mọi trạng thái đều chơi tốt.

## Browser regression: PASS

`browser_web5.txt`, Chromium + browser-side HTTP/WS mock (không nhúng mock vào firmware):
- Physical approval/PIN sai/đúng, held-input gate, black/L+R/intro/library.
- Fullscreen absent/reject/pending đều không chặn.
- globalThis/padStart/roundRect/replaceChildren fallbacks.
- **Cả 26 game**: controller giả lập chọn/chơi/menu/restart/xác nhận/về thư viện. Game 2P dùng L+R cho menu.
- Tách nguồn local/C3, Escape không toggle lặp, stale/freeze/hold, remote keyCode, touch đa điểm/cancel/blur trên phone/tablet viewport.

`features_web5.txt`:
- **Fullscreen API gốc Chromium** bật ở màn PIN bằng click thật, giữ 3 số đang nhập và vẫn ở màn PIN.
- Wake Lock mock: cấp, nhả khi ẩn, xin lại khi hiện, OS release, retry, disable; HTTP insecure, thiếu API, từ chối, Promise trả về sau khi chuyển TV. Không báo active giả.
- WS C3 mock: SW2 bit8 thực sự tới `Game.step`/đạn của P2, SW1 tới P1; hai trục độc lập, SW2 không pause; L+R 0,7s mở menu; bộ lọc 2P có 6 mục.
- Bàn phím local hai người; Esc; arrow navigation ở menu game-over.
- TV có logo assembly/intro/ambient animation; khi `prefers-reduced-motion: reduce` thì không ép animation.

`layout_web5.txt`: chọn thiết bị/PIN/library/game/menu ở 1920×1080, 1366×768, 1280×720, 1024×600, 1280×560. Kiểm tra vị trí phần tử và 26 hero copy trong parent, không chỉ giấu scrollbar. Bật/tắt fullscreen thật trong Chromium, không cần cuộn dọc ở các kích thước test. Canvas contain. Màn nhỏ hơn có thể cuộn theo thiết kế.

`js_compat_web5.txt`: esbuild target Chrome58/Safari11; Acorn parse generated app/games ES2017, compat ES5. Không chứng nhận mọi browser/TV cũ có API/GPU cần thiết.

## Chưa kiểm thử thực tế

- Nạp board/độ ổn định nguồn, RF, OLED, USB/BLE, peak heap và HTTP/WS khi assets lớn hơn.
- Wake Lock có thật sự giữ màn hình của một PC không; hệ điều hành/pin/quyền/iframe có thể thu hồi hoặc từ chối.
- `tools/Keep-Awake-Windows.ps1`: **chỉ rà mã**, không chạy trên Windows và không đo idle/sleep. Không đưa kết quả mock browser làm bằng chứng helper hoạt động.
- HTTPS reverse proxy/WSS chưa được kiểm thử tích hợp; C3 không có TLS native trong bộ này.
- FPS/latency hoặc hạn chế nhiều phím của bàn phím thật; hai người chơi thật; TV engine/GPU/remote thật.
- Cân bằng độ khó và thời gian chơi của 15 game mới cần phản hồi người dùng.

Ảnh `web5_*.png` đều là phần mềm/demo/mock. Đã xem trực quan logo TV, PIN/fullscreen và màn đối kháng. Hướng dẫn nạp/controls/chống sleep: `../WEB5_HUONG_DAN.md`. Checksum: `SHA256SUMS.txt` (không tự liệt kê chính file manifest).
