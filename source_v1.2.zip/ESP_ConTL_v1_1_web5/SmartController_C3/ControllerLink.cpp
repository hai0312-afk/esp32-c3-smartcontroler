#include "ControllerLink.h"
#include <esp_wifi.h>
// Arduino-ESP32 3.0.7 scanDelete() clears DONE, but not SCANNING.
// After an aborted/timed-out scan, a stale SCANNING bit can reject every rescan.
// Only reset it after esp_wifi_scan_stop() and the nonblocking settling interval.
namespace { struct ScanRecovery : WiFiGenericClass {
  static void clearStaleFlag() { clearStatusBits(WIFI_SCANNING_BIT); }
}; }
ControllerLink *ControllerLink::self=nullptr;
void ControllerLink::receive(const esp_now_recv_info_t *info,const uint8_t *data,int len) {
  if(!self || !self->queue_ || !info || len!=(int)sizeof(ctl::Packet)) return;
  Rx rx; memcpy(rx.mac,info->src_addr,6); memcpy(&rx.packet,data,len); rx.atUs=micros();rx.atMs=millis();rx.rssi=info->rx_ctrl?info->rx_ctrl->rssi:-127;
  if(xQueueSend(self->queue_,&rx,0)!=pdTRUE)self->queueDrops++;
}
void ControllerLink::transmitted(const uint8_t*,esp_now_send_status_t status){
  if(!self)return;if(status==ESP_NOW_SEND_SUCCESS)self->txOK++;else self->txFail++;
}
void ControllerLink::clearNow(){
  if(nowOn_){esp_now_unregister_recv_cb();esp_now_unregister_send_cb();esp_now_deinit();nowOn_=false;}
  if(queue_)xQueueReset(queue_);
}
bool ControllerLink::begin(bool usb) {
  stop(); self=this; usb_=usb;
  static bool eventHook=false;
  if(!eventHook){eventHook=true;WiFi.onEvent([](arduino_event_id_t,arduino_event_info_t info){if(self)self->lastStaReason=info.wifi_sta_disconnected.reason;},ARDUINO_EVENT_WIFI_STA_DISCONNECTED);}recovering_=false;recoverAttempt_=0;rearmRequired=true;
  if(!queue_) queue_=xQueueCreate(12,sizeof(Rx));
  if(!queue_) { fail("No RX memory"); return false; }
  xQueueReset(queue_);
  WiFi.persistent(false); WiFi.mode(WIFI_STA); WiFi.setAutoReconnect(false); WiFi.setSleep(false);
  pings=lostPings=sent=sendErrors=0; rttMs=-1; peerFlags=0; misses_=0;
  scan(); return true;
}
void ControllerLink::cancelScan() {
  bool complete=WiFi.scanComplete()>=0;
  esp_wifi_scan_stop();
  // Do not free results concurrently with a pending Arduino scan-done callback.
  if(complete) WiFi.scanDelete();
  scanRunning_=false;
}
void ControllerLink::scan() {
  clearNow(); recovering_=false;recoverAttempt_=0;rearmRequired=true;
  udp_.stop(); cancelScan();
  WiFi.persistent(false); WiFi.mode(WIFI_STA); WiFi.setAutoReconnect(false); WiFi.setSleep(false);
  WiFi.disconnect(false,false);
  count=0; apsSeen=0; scanPass=0; lastScanError=0; pending_=false; peerFlags=0;
  state=SCANNING; stateAt_=millis(); scanDue_=millis()+450;
  strcpy(message,"Radio settling...");
  Serial.println("[SCAN] STA reset; waiting 450ms before scan");
}
void ControllerLink::nextScanPass() {
  cancelScan();
  scanPass++;
  if((scanPass>=2 && count) || scanPass>=3) {
    state=LIST;
    snprintf(message,sizeof(message),"AP:%u espH:%d",apsSeen,count);
    Serial.printf("[SCAN] done max AP=%u espH=%d lastError=%d\n",apsSeen,count,lastScanError);
  } else { scanDue_=millis()+350; strcpy(message,"Retrying scan..."); }
}
void ControllerLink::connectTo(int index) {
  if(index<0 || index>=count) return;
  selected_=devices[index]; cancelScan();recovering_=false;recoverAttempt_=0;rearmRequired=true;
  strlcpy(peerName,selected_.ssid,sizeof(peerName)); channel=selected_.channel;
  joinAttempt_=0; startJoin();
}
void ControllerLink::startJoin() {
  udp_.stop(); WiFi.disconnect(false,false);
  state=CONNECTING; joinPending_=true; joinDue_=millis()+350; stateAt_=millis();
  joinAttempt_++; snprintf(message,sizeof(message),"Join attempt %u/2",joinAttempt_);
}
void ControllerLink::fail(const char *m) {
  bool retry=(state==READY||state==VERIFY_LINK||state==LOCK_CHANNEL||recovering_)&&recoverAttempt_<3;
  Serial.printf("[LINK] %s status=%d ch=%u txErr=%d txFail=%lu qDrop=%lu lastSTAReason=%u\n",m,(int)WiFi.status(),channel,lastSendError,(unsigned long)txFail,(unsigned long)queueDrops,lastStaReason);
  rearmRequired=true;rttMs=-1;peerFlags=0;pending_=false;clearNow();udp_.stop();
  strlcpy(message,m,sizeof(message));
  if(retry){recovering_=true;recoverAttempt_++;recoveries++;state=RECOVER_WAIT;stateAt_=millis();}
  else {recovering_=false;state=ERROR_STATE;}
}
bool ControllerLink::sendPacket(ctl::Packet &p) {
  p.session=session_; p.seq=++seq_;
  esp_err_t e=esp_now_send(peerMac,(uint8_t*)&p,sizeof(p));
  lastSendError=e;
  if(e!=ESP_OK) { sendErrors++; return false; }
  sent++; return true;
}
void ControllerLink::update() {
  uint32_t now=millis();
  if(state==RECOVER_WAIT){
    if(now-stateAt_>=1000){WiFi.mode(WIFI_STA);WiFi.setAutoReconnect(false);WiFi.setSleep(false);joinAttempt_=0;startJoin();}
    return;
  }
  if(state==SCANNING) {
    if(!scanRunning_ && (int32_t)(now-scanDue_)>=0) {
      // First search the receiver's fixed channel; then full active/passive scans.
      bool passive=scanPass==2; uint8_t ch=scanPass==0?ctl::WIFI_CHANNEL:0;
      uint32_t dwell=scanPass==0?450:(passive?500:350);
      snprintf(message,sizeof(message),"Scan %u/3 %s",scanPass+1,ch?"CH6":(passive?"passive":"all CH"));
      if(WiFi.getStatusBits() & WIFI_SCANNING_BIT) {
        ScanRecovery::clearStaleFlag();
        Serial.println("[SCAN] recovered stale Arduino scan flag");
      }
      WiFi.scanDelete();
      int result=WiFi.scanNetworks(true,true,passive,dwell,ch);
      Serial.printf("[SCAN] pass=%u channel=%u dwell=%lu result=%d\n",scanPass+1,ch,(unsigned long)dwell,result);
      scanAt_=now;
      if(result==WIFI_SCAN_FAILED) { lastScanError=result; nextScanPass(); }
      else scanRunning_=true;
    }
    if(scanRunning_) {
      int n=WiFi.scanComplete();
      if(n>=0) {
        if(n>apsSeen) apsSeen=n;
        for(int i=0;i<n;i++) {
          String ssid=WiFi.SSID(i);
          Serial.printf("[SCAN] ssid='%s' ch=%d rssi=%ld\n",ssid.c_str(),WiFi.channel(i),(long)WiFi.RSSI(i));
          mergeDiscovery(devices,count,ssid.c_str(),WiFi.BSSID(i),WiFi.RSSI(i),WiFi.channel(i));
        }
        nextScanPass();
      } else if(n==WIFI_SCAN_FAILED || now-scanAt_>12000) {
        lastScanError=n==WIFI_SCAN_FAILED?n:-100; nextScanPass();
      }
    }
  } else if(state==CONNECTING) {
    if(joinPending_ && (int32_t)(now-joinDue_)>=0) {
      WiFi.begin(selected_.ssid,ctl::WIFI_PASSWORD,selected_.channel,selected_.bssid,true);
      joinPending_=false; stateAt_=now;
    }
    if(!joinPending_ && WiFi.status()==WL_CONNECTED) {
      if(!udp_.begin(ctl::UDP_PORT)) { fail("UDP init failed"); return; }
      session_=esp_random(); if(!session_) session_=1;
      channel=WiFi.channel(); state=HANDSHAKE; stateAt_=now; helloAt_=now-300;
      strcpy(message,"Exchanging MAC...");
    } else if(!joinPending_ && now-stateAt_>10000) {
      if(joinAttempt_<2) startJoin(); else fail("Join failed: AP/PW");
    }
  } else if(state==HANDSHAKE) {
    if(now-helloAt_>=250) {
      helloAt_=now;
      ctl::Hello h; h.session=session_; WiFi.macAddress(h.mac); h.channel=channel;
      udp_.beginPacket(WiFi.gatewayIP(),ctl::UDP_PORT); udp_.write((uint8_t*)&h,sizeof(h)); udp_.endPacket();
    }
    int n=udp_.parsePacket();
    if(n) {
      ctl::Hello h;
      bool source=udp_.remoteIP()==WiFi.gatewayIP() && udp_.remotePort()==ctl::UDP_PORT;
      if(n==(int)sizeof(h) && udp_.read((uint8_t*)&h,sizeof(h))==(int)sizeof(h)
         && source && ctl::valid(h) && h.type==ctl::WELCOME && h.session==session_
         && !(h.mac[0]&1) && h.channel==channel) {
        if(usb_ && h.role!=ctl::ROLE_USB) { fail("Not a USB bridge"); return; }
        memcpy(peerMac,h.mac,6); role=h.role;
        // Association is used ONLY for discovery/MAC exchange. ESP-NOW does not
        // require DHCP/beacons; detach deliberately, then lock the learned channel.
        udp_.stop();WiFi.setAutoReconnect(false);WiFi.disconnect(false,false);
        state=LOCK_CHANNEL;stateAt_=now;strcpy(message,"Locking ESP-NOW CH");
      } else while(udp_.available()) udp_.read();
    }
    if(state==HANDSHAKE && now-stateAt_>6000) {
      if(joinAttempt_<2) startJoin(); else fail("MAC handshake failed");
    }
  }
  if(state==LOCK_CHANNEL){
    if(now-stateAt_<180)return;
    if(WiFi.status()==WL_CONNECTED){if(now-stateAt_>2000)fail("STA detach timeout");return;}
    esp_wifi_set_ps(WIFI_PS_NONE);esp_wifi_set_bandwidth(WIFI_IF_STA,WIFI_BW_HT20);
    if(esp_wifi_set_channel(channel,WIFI_SECOND_CHAN_NONE)!=ESP_OK){fail("Channel lock failed");return;}
    if(esp_now_init()!=ESP_OK){fail("ESP-NOW init failed");return;}
    nowOn_=true;esp_now_register_recv_cb(receive);esp_now_register_send_cb(transmitted);
    esp_now_peer_info_t peer={};memcpy(peer.peer_addr,peerMac,6);peer.ifidx=WIFI_IF_STA;peer.channel=channel;peer.encrypt=false;
    if(esp_now_add_peer(&peer)!=ESP_OK){fail("Peer add failed");return;}
    seq_=0;health_.reset(now);pingAt_=now-250;state=VERIFY_LINK;rearmRequired=true;
    strcpy(message,"Checking ESP-NOW...");
    Serial.printf("[LINK] detached STA; ESP-NOW-only ch=%u peer=%02X:%02X:%02X:%02X:%02X:%02X\n",channel,peerMac[0],peerMac[1],peerMac[2],peerMac[3],peerMac[4],peerMac[5]);
  }
  if(state!=READY&&state!=VERIFY_LINK)return;
  Rx rx;
  while(xQueueReceive(queue_,&rx,0)==pdTRUE){
    const ctl::Packet &p=rx.packet;
    if(memcmp(rx.mac,peerMac,6)||!ctl::valid(p)||p.session!=session_||p.type!=ctl::PONG)continue;
    if(health_.acknowledge(p.seq,p.stampUs,rx.atMs,millis())){
      peerFlags=p.flags;rssi=rx.rssi;rttMs=(uint32_t)(rx.atUs-p.stampUs)/1000.0f;
      if(state==VERIFY_LINK){state=READY;recovering_=false;recoverAttempt_=0;strcpy(message,"Center + J1/J2: arm");Serial.println("[LINK] verified; outputs NEUTRAL until user rearms");}
    }
  }
  now=millis();
  uint32_t beforeLost=health_.lost;health_.expire(now);lostPings+=health_.lost-beforeLost;
  if(!health_.healthy(now)&&state==READY&&!rearmRequired){rearmRequired=true;Serial.println("[LINK] heartbeat stale: neutral; manual rearm required");}
  if(health_.timedOut(now)){fail("No PONG for 2 seconds");return;}
  if(now-pingAt_>=250){
    pingAt_=now;ctl::Packet p;p.type=ctl::PING;p.stampUs=micros();
    if(sendPacket(p))health_.sent(p.seq,p.stampUs,now);else lostPings++;
    pings++;
  }
  if(now-logAt_>=5000){logAt_=now;uint8_t ch=0;wifi_second_chan_t second;esp_wifi_get_channel(&ch,&second);
    Serial.printf("[LINK] ESP-NOW CH=%u RSSI=%d age=%lu ms txOK=%lu txFail=%lu qDrop=%lu retries=%lu arm=%u\n",ch,rssi,(unsigned long)health_.age(now),(unsigned long)txOK,(unsigned long)txFail,(unsigned long)queueDrops,(unsigned long)recoveries,!rearmRequired);
  }
}

void ControllerLink::sendControl(const Input &in,bool neutral) {
  if(state!=READY) return;
  neutral=neutral||rearmRequired||!health_.healthy(millis());
  ctl::Packet p; p.type=neutral?ctl::NEUTRAL:ctl::CONTROL; p.stampUs=micros();
  p.flags=usb_?ctl::FLAG_USB:0;
  if(!neutral) {
    memcpy(p.axis,in.axis,sizeof(p.axis)); p.buttons=in.buttons;
    if(usb_) p.hid=mappedHid(in);
  }
  sendPacket(p);
}
void ControllerLink::stop() {
  if(nowOn_) {
    if(state==READY) {
      ctl::Packet p; p.type=ctl::NEUTRAL; sendPacket(p); delay(20);
    }
    clearNow();
  }
  udp_.stop(); cancelScan(); WiFi.disconnect(true,false); WiFi.mode(WIFI_OFF);
  memset(peerMac,0,6); session_=0; pending_=false; state=OFF;recovering_=false;recoverAttempt_=0;rearmRequired=true;
}
