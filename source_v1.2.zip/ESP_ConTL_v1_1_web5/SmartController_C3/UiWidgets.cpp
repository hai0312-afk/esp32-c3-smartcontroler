#include "UiWidgets.h"
#include "UiMotion.h"
#include <math.h>
namespace ui {
static constexpr uint16_t W=SSD1306_WHITE,B=SSD1306_BLACK;
void clippedText(Adafruit_SSD1306 &d,int x,int y,int width,const String &text,int offset) {
  // Save only the two physical OLED pages that can intersect this 8-pixel text line.
  if(y<0 || y>56 || width<=0) return;
  int first=(63-y-7)/8,last=(63-y)/8;
  uint8_t saved[256]; uint8_t *buffer=d.getBuffer();
  memcpy(saved,buffer+first*128,(last-first+1)*128);
  d.setCursor(x-offset,y); d.print(text);
  for(int xx=0;xx<128;xx++) if(xx<x || xx>=x+width) {
    int physicalX=127-xx;
    for(int page=first;page<=last;page++) buffer[page*128+physicalX]=saved[(page-first)*128+physicalX];
  }
}
int marquee(int textPixels,int available,uint32_t elapsed) {
  int span=textPixels-available;
  if(span<=0) return 0;
  uint32_t travel=span*25U+200,cycle=1800+travel*2;
  uint32_t phase=elapsed%cycle;
  if(phase<900) return 0;
  phase-=900;
  if(phase<travel) return span*easeOut(phase,travel)/1024;
  phase-=travel;
  if(phase<900) return span;
  return span-span*easeOut(phase-900,travel)/1024;
}
void ring(Adafruit_SSD1306 &d,int x,int y,int radius,uint16_t progress) {
  d.drawCircle(x,y,radius,W);
  int count=(min((int)progress,1024)*40)/1024;
  for(int i=0;i<count;i++) {
    float a=-PI/2+i*2*PI/40;
    d.drawLine(x+cosf(a)*(radius-2),y+sinf(a)*(radius-2),x+cosf(a)*(radius+1),y+sinf(a)*(radius+1),W);
  }
}
void spinner(Adafruit_SSD1306 &d,int x,int y,uint32_t now) {
  int head=(now/90)%8;
  for(int i=0;i<4;i++) {
    float a=(head-i)*PI/4;
    d.drawPixel(x+cosf(a)*4,y+sinf(a)*4,W);
    if(i==0) d.drawPixel(x+cosf(a)*3,y+sinf(a)*3,W);
  }
}
void loading(Adafruit_SSD1306 &d,int x,int y,int width,uint32_t now) {
  d.drawRoundRect(x,y,width,6,2,W);
  uint32_t phase=now%1400;
  int at=easeOut(phase<700?phase:phase-700,700)*(width-26)/1024;
  if(phase>=700) at=width-26-at;
  d.fillRoundRect(x+2+at,y+2,22,2,1,W);
}
void icon(Adafruit_SSD1306 &d,int type,int x,int y,uint32_t now,bool animate) {
  uint32_t t=animate?now:0;
  if(type==0) {
    for(int r=4;r<=10;r+=3) {
      if(!animate || ((t/220)%3)>=(unsigned)(r-4)/3) {
        for(int a=215;a<=325;a+=5) {
          float rad=a*PI/180; d.drawPixel(x+12+cosf(rad)*r,y+14+sinf(rad)*r,W);
        }
      }
    }
    d.fillCircle(x+12,y+16,2,W); d.drawLine(x+12,y+18,x+12,y+22,W);
  } else if(type==1) {
    d.drawLine(x+12,y+22,x+12,y+2,W); d.fillTriangle(x+9,y+5,x+15,y+5,x+12,y,W);
    d.drawLine(x+12,y+17,x+4,y+11,W); d.drawLine(x+4,y+11,x+4,y+7,W);
    d.drawCircle(x+4,y+5,2,W); d.drawLine(x+12,y+13,x+20,y+8,W); d.drawRect(x+18,y+4,5,5,W);
    if(animate) d.fillRect(x+11,y+20-(t/65)%14,3,2,W);
  } else if(type==2) {
    d.drawLine(x+11,y,x+11,y+23,W); d.drawLine(x+11,y,x+20,y+7,W);
    d.drawLine(x+20,y+7,x+4,y+19,W); d.drawLine(x+4,y+4,x+20,y+16,W);
    d.drawLine(x+20,y+16,x+11,y+23,W);
    if(animate && t%1400<700) { d.drawPixel(x+1,y+11,W); d.drawPixel(x+24,y+11,W); }
  } else if(type==3) {
    int bob=animate?(int)roundf(sinf(t/330.0f)):0;
    d.drawRoundRect(x,y+4+bob,25,17,5,W);
    d.drawLine(x+4,y+12+bob,x+12,y+12+bob,W); d.drawLine(x+8,y+8+bob,x+8,y+16+bob,W);
    d.fillCircle(x+18,y+9+bob,1,W); d.drawCircle(x+21,y+15+bob,1,W);
  } else if(type==5) {
    d.drawCircle(x+12,y+12,11,W); d.drawCircle(x+12,y+12,6,W);
    d.drawFastHLine(x+1,y+12,23,W); d.drawFastVLine(x+12,y+1,23,W);
    if(animate) { float a=t/550.0f; d.fillCircle(x+12+cosf(a)*10,y+12+sinf(a)*10,2,W); }
  } else {
    d.drawCircle(x+12,y+12,8,W); d.drawCircle(x+12,y+12,3,W);
    float rotate=animate?t/1800.0f:0;
    for(int i=0;i<8;i++) { float a=i*PI/4+rotate;
      d.drawLine(x+12+cosf(a)*8,y+12+sinf(a)*8,x+12+cosf(a)*11,y+12+sinf(a)*11,W);
    }
  }
}
void gameIcon(Adafruit_SSD1306 &d,int game,int x,int y,uint32_t now,bool animate) {
  uint32_t t=animate?now:0;
  switch(game) {
    case 0:
      d.fillCircle(x+10,y+12,9,W);
      d.fillTriangle(x+10,y+12,x+22,y+(t%500<250?3:9),x+22,y+(t%500<250?21:15),B);
      d.drawPixel(x+11,y+7,B); d.fillCircle(x+23,y+12,1,W); break;
    case 1:
      d.fillRect(x+5,y+6,14,10,W); d.fillRect(x+2,y+10,20,4,W);
      d.fillRect(x+8,y+9,2,2,B); d.fillRect(x+14,y+9,2,2,B);
      d.drawLine(x+4,y+5,x+7,y+7,W); d.drawLine(x+20,y+5,x+17,y+7,W);
      d.drawLine(x+6,y+16,x+3,y+19,W); d.drawLine(x+18,y+16,x+21,y+19,W);
      if(animate) d.drawFastVLine(x+12,y+20+(t/100)%3,2,W); break;
    case 2:
      d.drawLine(x+17,y+1,x+17,y+22,W); d.fillTriangle(x+18,y+2,x+25,y+2,x+18,y+8,W);
      d.drawRect(x+1,y+20,8,4,W); d.drawRect(x+9,y+20,8,4,W);
      d.fillCircle(x+6,y+10-(animate?(int)(2+sinf(t/220.0f)*2):0),2,W);
      d.fillRect(x+4,y+12-(animate?(int)(2+sinf(t/220.0f)*2):0),5,5,W); break;
    case 3:
      for(int i=0;i<3;i++) d.drawRoundRect(x+3+i*7,y+12,6,6,1,W);
      d.fillRoundRect(x+10,y+5,6,6,1,W); break;
    case 4:
      d.fillCircle(x+11,y+12,6,W); d.drawPixel(x+13,y+10,B);
      d.fillTriangle(x+16,y+11,x+23,y+13,x+16,y+14,W);
      d.drawLine(x+8,y+12,x+3,y+(t%400<200?7:17),W); break;
    case 5: {
      int by=animate?(int)(sinf(t/280.0f)*5):0;
      d.fillRoundRect(x+1,y+5+by,3,12,1,W); d.fillRoundRect(x+22,y+5-by,3,12,1,W);
      d.fillCircle(x+12+(animate?(int)(sinf(t/340.0f)*7):0),y+12+by,2,W); break;
    }
    case 6: case 7:
      d.drawTriangle(x+12,y+3,x+4,y+20,x+20,y+20,W);
      d.drawCircle(x+12,y+12,3,W);
      if(animate) { int yy=(t/65)%8; d.drawPixel(x+12,y+1+yy,W); }
      if(game==7) { d.drawPixel(x+1,y+3,W); d.drawPixel(x+23,y+21,W); }
      break;
    case 8:
      d.drawLine(x+1,y,x+1,y+23,W); d.drawLine(x+24,y,x+24,y+23,W);
      d.drawRoundRect(x+8,y+4,10,17,3,W); d.fillRect(x+10,y+7,6,4,W);
      for(int yy=(t/120)%6;yy<24;yy+=6) d.drawFastVLine(x+4,y+yy,3,W); break;
    case 9:
      for(int i=0;i<4;i++) d.fillRoundRect(x+2+i*5,y+15,4,4,1,W);
      d.fillRoundRect(x+17,y+10,4,4,1,W); d.drawRoundRect(x+17,y+5,4,4,1,W);
      d.drawCircle(x+7,y+5,(t%700<350)?1:2,W); break;
    default:
      d.drawRoundRect(x+3,y+7,4,15,1,W); d.drawRoundRect(x+19,y+7,4,15,1,W);
      d.fillRect(x+8,y+9,10,11,W); d.drawCircle(x+13,y+14,3,B); d.drawFastVLine(x+13,y+1,10,W); break;
  }
}
}
