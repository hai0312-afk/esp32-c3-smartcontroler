#pragma once
#include <Adafruit_SSD1306.h>
#include "Input.h"
class Games {
 public:
  static constexpr int COUNT=11;
  static const char *const names[COUNT];
  static const char *const hints[COUNT];
  void start(int game);
  void tick(const Input &in); // one fixed 20 ms simulation tick; not called when paused
  void draw(Adafruit_SSD1306 &d);
  int id=0,score=0;
 private:
  struct Body { float x=0,y=0,vx=0,vy=0; bool live=false; uint8_t type=0; };
  Body enemies[24],shots[32];
  bool over=false,won=false;
  uint32_t frame=0;
  int health=3,cool=0,hurt=0,level=1;
  float px=0,py=0,vx=0,vy=0,aux=0,aux2=0;
  int a=0,b=0,c=0,dir=0,want=0;
  uint8_t cells[12][24]={};
  int16_t sx[384],sy[384]; int length=0;
  bool coins[64]={};
  int piece=0,rotation=0,tx=0,ty=0,next=0,fall=0,repeat=0;
  void fire(float x,float y,float dx,float dy,uint8_t type=0);
  void maze(const Input&); void invaders(const Input&); void platform(const Input&);
  void blocks(const Input&); void flappy(const Input&); void pong(const Input&);
  void twin(const Input&); void race(const Input&); void snake(const Input&); void tank(const Input&);
  bool blockFits(int x,int y,int r); void newPiece(); void lockPiece();
  bool solid(float x,float y); void snakeFood();
};
