#pragma once
#include "Input.h"
#include <Adafruit_SSD1306.h>
namespace WebSetup {
 void begin();
 void stop();
 void tick(const Input &input,bool displayIdle);
 void draw(Adafruit_SSD1306 &display);
 bool needsDrain();
 bool online();
}
