#include "Input.h"
Settings cfg;
const char *const CONTROL_NAMES[12]={"J1 Up","J1 Down","J1 Left","J1 Right","J2 Up","J2 Down","J2 Left","J2 Right","BTN L","BTN R","JOY1 SW","JOY2 SW"};
const Action ACTIONS[]={
 {"None",0,0},{"W",1,0x1A},{"A",1,0x04},{"S",1,0x16},{"D",1,0x07},
 {"Up",1,0x52},{"Down",1,0x51},{"Left",1,0x50},{"Right",1,0x4F},
 {"Shift",2,0x02},{"Space",1,0x2C},{"Enter",1,0x28},{"Esc",1,0x29},
 {"Mouse L",3,1},{"Mouse R",3,2},{"Mouse M",3,4},
 {"Ctrl",2,1},{"Alt",2,4},{"Tab",1,0x2B},{"Backspace",1,0x2A},
 {"Q",1,0x14},{"E",1,0x08},{"R",1,0x15},{"F",1,0x09},{"Z",1,0x1D},{"X",1,0x1B},{"C",1,0x06},
 {"I",1,0x0C},{"J",1,0x0D},{"K",1,0x0E},{"L",1,0x0F},
 {"1",1,0x1E},{"2",1,0x1F},{"3",1,0x20},{"4",1,0x21},
 {"U",1,0x18},{"O",1,0x12},{"P",1,0x13},{"B",1,0x05},{"G",1,0x0A},
 {"H",1,0x0B},{"N",1,0x11},{"M",1,0x10},{"T",1,0x17},{"V",1,0x19},{"Y",1,0x1C},
 {"5",1,0x22},{"6",1,0x23},{"7",1,0x24},{"8",1,0x25},{"9",1,0x26},{"0",1,0x27},
 {"F1",1,0x3A},{"F2",1,0x3B},{"F3",1,0x3C},{"F4",1,0x3D},
 {"F5",1,0x3E},{"F6",1,0x3F},{"F7",1,0x40},{"F8",1,0x41},{"F9",1,0x42},{"F10",1,0x43},{"F11",1,0x44},{"F12",1,0x45},
 {"Delete",1,0x4C},{"Home",1,0x4A},{"End",1,0x4D},{"PgUp",1,0x4B},{"PgDn",1,0x4E}
};
const uint8_t ACTION_COUNT=sizeof(ACTIONS)/sizeof(ACTIONS[0]);
void saveSettings() { Preferences p; p.begin("contl",false); p.putBytes("settings",&cfg,sizeof(cfg)); p.end(); }
void loadSettings() {
  Preferences p; p.begin("contl",true); Settings tmp;
  bool good=p.getBytesLength("settings")==sizeof(tmp) && p.getBytes("settings",&tmp,sizeof(tmp))==sizeof(tmp);
  p.end();
  if (!good || tmp.magic!=cfg.magic) return;
  for(int i=0;i<4;i++) if(tmp.center[i]<300 || tmp.center[i]>3795) return;
  for(auto m:tmp.mapping) if(m>=ACTION_COUNT) return;
  if(tmp.mouseSpeed<1 || tmp.mouseSpeed>16 || tmp.deadzone<50 || tmp.deadzone>400) return;
  cfg=tmp;
}
void resetSettings() { cfg=Settings{}; saveSettings(); }
void Input::begin() {
  analogReadResolution(12);
  for(auto p:AXIS_PINS) { pinMode(p,INPUT); analogSetPinAttenuation(p,ADC_11db); }
  for(auto p:BUTTON_PINS) pinMode(p,INPUT_PULLUP);
  pinMode(PIN_CHRG,INPUT_PULLUP); pinMode(PIN_STDBY,INPUT_PULLUP);
}
void Input::update() {
  uint32_t now=millis(); pressed=released=0;
  for(int i=0;i<4;i++) {
    uint16_t v=analogRead(AXIS_PINS[i]); raw[i]=first_?v:(raw[i]*3+v)/4;
    int delta=(int)raw[i]-cfg.center[i];
    int span=delta<0?cfg.center[i]:4095-cfg.center[i];
    int a=constrain(delta*1000/span,-1000,1000);
    int mag=abs(a);
    a=mag<cfg.deadzone?0:(a<0?-1:1)*(mag-cfg.deadzone)*1000/(1000-cfg.deadzone);
    axis[i]=cfg.flip[i]?-a:a;
    uint8_t bit=1<<i;
    bool down=digitalRead(BUTTON_PINS[i])==LOW;
    if(down!=!!(candidate_&bit)) { candidate_^=bit; changed_[i]=now; }
    if(now-changed_[i]>=25 && down!=!!(buttons&bit)) {
      buttons^=bit; if(down) pressed|=bit; else released|=bit;
    }
  }
  first_=false;
}
bool Input::calibrate() {
  // Call only from Settings, not during live remote control.
  uint32_t sum[4]={};
  for(int n=0;n<64;n++) { for(int i=0;i<4;i++) sum[i]+=analogRead(AXIS_PINS[i]); delay(2); }
  for(int i=0;i<4;i++) if(sum[i]/64<300 || sum[i]/64>3795) return false;
  for(int i=0;i<4;i++) cfg.center[i]=sum[i]/64;
  saveSettings(); return true;
}
ctl::HidReport mappedHid(const Input &in) {
  ctl::HidReport h;
  bool active[12]={in.axis[1]<-450,in.axis[1]>450,in.axis[0]<-450,in.axis[0]>450,
    in.axis[3]<-450,in.axis[3]>450,in.axis[2]<-450,in.axis[2]>450,
    in.down(ctl::B_L),in.down(ctl::B_R),in.down(ctl::B_J1),in.down(ctl::B_J2)};
  uint8_t count=0;
  for(int i=0;i<12;i++) {
    if(!active[i] || (cfg.joy2Mouse && i>=4 && i<=7)) continue;
    const Action &a=ACTIONS[cfg.mapping[i]];
    if(a.kind==2) h.modifiers|=a.code;
    else if(a.kind==3) h.mouseButtons|=a.code;
    else if(a.kind==1 && count<6) {
      bool duplicate=false; for(int j=0;j<count;j++) if(h.keys[j]==a.code) duplicate=true;
      if(!duplicate) h.keys[count++]=a.code;
    }
  }
  if(cfg.joy2Mouse) {
    h.dx=in.axis[2]*cfg.mouseSpeed/1000; h.dy=in.axis[3]*cfg.mouseSpeed/1000;
  }
  return h;
}
