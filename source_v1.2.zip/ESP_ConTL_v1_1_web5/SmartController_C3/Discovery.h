#pragma once
#include <stdint.h>
#include <string.h>
struct DiscoveryDevice { char ssid[33]={}; uint8_t bssid[6]={}; int32_t rssi=0; uint8_t channel=0; };
constexpr int DISCOVERY_CAPACITY=24;
inline bool mergeDiscovery(DiscoveryDevice *devices,int &count,const char *ssid,const uint8_t *bssid,int32_t rssi,uint8_t channel) {
  if(!ssid || !bssid || strncmp(ssid,"espH_",5)!=0 || strlen(ssid)<=5 || channel<1 || channel>14) return false;
  int at=-1;
  for(int i=0;i<count;i++) if(!memcmp(devices[i].bssid,bssid,6)) { at=i; break; }
  if(at<0) {
    if(count>=DISCOVERY_CAPACITY) {
      int weakest=0; for(int i=1;i<count;i++) if(devices[i].rssi<devices[weakest].rssi) weakest=i;
      if(rssi<=devices[weakest].rssi) return false;
      at=weakest;
    } else at=count++;
  }
  DiscoveryDevice &d=devices[at]; memset(d.ssid,0,sizeof(d.ssid));
  strncpy(d.ssid,ssid,32); memcpy(d.bssid,bssid,6); d.rssi=rssi; d.channel=channel;
  for(int i=1;i<count;i++) for(int j=i;j>0 && devices[j].rssi>devices[j-1].rssi;j--) {
    DiscoveryDevice tmp=devices[j]; devices[j]=devices[j-1]; devices[j-1]=tmp;
  }
  return true;
}
