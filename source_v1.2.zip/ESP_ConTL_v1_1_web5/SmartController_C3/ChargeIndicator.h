#pragma once
#include <stdint.h>
// Active-low inputs already converted to bool by caller.
// CHRG xor STDBY is only an inference of plugged-in power, NOT a VBUS measurement.
inline bool chargeIconVisible(bool charging,bool standby,uint32_t nowMs) {
  bool hasChargeSignal=charging!=standby;
  return !hasChargeSignal || ((nowMs/500U)&1U)==0;
}
