#pragma once
#include <stdint.h>
// Pure timing policy. Never changes a home-network request into an AP request.
struct HomeJoinPolicy {
  enum Stage { IDLE, JOINING, RETRY_WAIT, ONLINE, FAILED };
  enum Action { NONE, CONNECT, DISCONNECT };
  static constexpr uint32_t attemptMs=25000,retryMs=1000;
  static constexpr uint8_t maxAttempts=2;
  Stage stage=IDLE; uint8_t attempt=0; uint32_t since=0;
  Action begin(uint32_t now){attempt=1;stage=JOINING;since=now;return CONNECT;}
  void stop(){stage=IDLE;attempt=0;since=0;}
  Action tick(uint32_t now,bool hasIP){
    if(stage==JOINING){
      if(hasIP){stage=ONLINE;since=now;return NONE;}
      if(now-since>=attemptMs){stage=attempt<maxAttempts?RETRY_WAIT:FAILED;since=now;return DISCONNECT;}
    }else if(stage==RETRY_WAIT&&now-since>=retryMs){++attempt;stage=JOINING;since=now;return CONNECT;}
    else if(stage==ONLINE&&!hasIP)return begin(now);
    return NONE;
  }
};
