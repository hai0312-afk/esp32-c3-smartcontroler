#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <stdint.h>
#include <string.h>
// Bounded I2C chunks + SSD1306 register refresh. No display-off/sleep on normal refresh.
class OledPump {
 public:
  explicit OledPump(TwoWire &bus):bus_(bus){}
  void begin(uint8_t address=0x3C){address_=address;bus_.setTimeOut(8);configNeeded_=true;lastRecovery_=millis()-2000;}
  bool busy()const{return busy_;}
  uint32_t frames=0,errors=0,recoveries=0,refreshes=0;
  uint32_t clockHz()const{return slow_?100000:400000;}
  void setInvert(bool invert){if(invert_!=invert){invert_=invert;configNeeded_=true;}}
  bool takeBusRecovery(uint32_t now){
    if(!recoverPending_||now-lastRecovery_<2000)return false;
    recoverPending_=false;lastRecovery_=now;busy_=false;addressed_=false;
    configNeeded_=true;slow_=true;failures_=0;retryAt_=now+20;backoff_=true;recoveries++;return true;
  }
  bool submit(const uint8_t *frame){
    if(busy_)return false;
    if(backoff_){if((int32_t)(millis()-retryAt_)<0)return false;backoff_=false;}
    memcpy(staging_,frame,1024);offset_=0;addressed_=false;busy_=true;return true;
  }
  void service(){
    if(!busy_)return;
    bus_.setClock(clockHz());bus_.beginTransmission(address_);
    if(!addressed_&&offset_==0&&(configNeeded_||millis()-lastConfig_>=5000)){
      // Restore charge pump, mux, start line, COM/SEG mapping and display-on even
      // after a panel-only brownout which can ACK I2C but leave the screen black.
      // GFX rotation(2) stays in software; mapping matches Adafruit's 128x64 init.
      const uint8_t commands[]={0x00,0xD5,0x80,0xA8,0x3F,0xD3,0x00,0x40,
        0x8D,0x14,0x20,0x00,0xA1,0xC8,0xDA,0x12,0x81,0xCF,0xD9,0xF1,
        0xDB,0x40,0xA4,(uint8_t)(invert_?0xA7:0xA6),0x2E,0xAF};
      bus_.write(commands,sizeof(commands));if(bus_.endTransmission()!=0){fail();return;}
      configNeeded_=false;lastConfig_=millis();refreshes++;addressed_=false;return;
    }
    if(!addressed_){
      const uint8_t commands[]={0x00,0x20,0x00,0x21,0,127,0x22,0,7};
      bus_.write(commands,sizeof(commands));if(bus_.endTransmission()!=0){fail();return;}
      addressed_=true;return;
    }
    bus_.write((uint8_t)0x40);bus_.write(staging_+offset_,32);
    if(bus_.endTransmission()!=0){fail();return;}
    offset_+=32;if(offset_==1024){busy_=false;frames++;failures_=0;recoverPending_=false;}
  }
 private:
  void fail(){busy_=false;addressed_=false;configNeeded_=true;errors++;retryAt_=millis()+120;backoff_=true;
    if(failures_<255)failures_++;if(failures_>=3){slow_=true;recoverPending_=true;}}
  TwoWire &bus_;uint8_t staging_[1024]={},address_=0x3C,failures_=0;
  uint16_t offset_=0;uint32_t lastConfig_=0,lastRecovery_=0,retryAt_=0;
  bool backoff_=false,busy_=false,addressed_=false,configNeeded_=true,invert_=false,slow_=false,recoverPending_=false;
};
