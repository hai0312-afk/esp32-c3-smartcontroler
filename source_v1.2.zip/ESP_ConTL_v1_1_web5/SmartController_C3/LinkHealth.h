#pragma once
#include <stdint.h>
// Pure, wrap-safe heartbeat tracking. Never infer delivery from esp_now_send() alone.
struct LinkHealth {
 struct Probe {uint32_t seq=0,stamp=0,at=0;bool live=false,expired=false;};
 Probe probes[8];uint8_t cursor=0;uint32_t started=0,lastReply=0,lost=0;bool seen=false;
 void reset(uint32_t now){for(auto &p:probes)p=Probe{};cursor=0;started=now;lastReply=now;lost=0;seen=false;}
 void sent(uint32_t seq,uint32_t stamp,uint32_t now){probes[cursor]={seq,stamp,now,true,false};cursor=(cursor+1)%8;}
 void expire(uint32_t now){for(auto &p:probes)if(p.live&&!p.expired&&now-p.at>=350){p.expired=true;lost++;}}
 bool acknowledge(uint32_t seq,uint32_t stamp,uint32_t received,uint32_t now){
  if(now-received>300)return false;
  for(auto &p:probes)if(p.live&&p.seq==seq&&p.stamp==stamp&&received-p.at<=2000){
   p.live=false;if(!seen||(int32_t)(received-lastReply)>0)lastReply=received;seen=true;return true;
  }return false;
 }
 uint32_t age(uint32_t now)const{return now-(seen?lastReply:started);}
 bool healthy(uint32_t now)const{return seen&&age(now)<600;}
 bool timedOut(uint32_t now)const{return age(now)>=2000;}
};
