#pragma once
#include <stdint.h>
// Pure logic shared by OLED setup and host tests. Directions: right/down/left/up.
inline int consoleDirection(int x,int y,int threshold=550) {
  int ax=x<0?-x:x,ay=y<0?-y:y;
  if(ax<threshold && ay<threshold)return -1;
  return ax>ay?(x>0?0:2):(y>0?1:3);
}
struct ConsoleRepeat {
  int held=-1; uint32_t due=0;
  void reset(){held=-1;due=0;}
  int step(int x,int y,uint32_t now) {
    int d=consoleDirection(x,y,held<0?550:350);
    if(d<0){reset();return -1;}
    if(d!=held){held=d;due=now+380;return d;}
    if((int32_t)(now-due)>=0){due=now+125;return d;}
    return -1;
  }
};
struct OledKeyboard {
  char value[64]={}; uint8_t length=0,page=0,cell=0;
  void clear(){for(char &c:value)c=0;length=0;page=0;cell=0;}
  void move(int d){int x=cell%10,y=cell/10;if(d==0)x=(x+1)%10;if(d==2)x=(x+9)%10;if(d==1)y=(y+1)%4;if(d==3)y=(y+3)%4;cell=y*10+x;}
  void erase(){if(length)value[--length]=0;}
  void next(){page=(page+1)%3;}
  char character(int at) const {
    const char *rows[]={"abcdefghijklmnopqrstuvwxyz0123456789","ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789","!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~     "};
    return rows[page][at];
  }
  bool select(){
    if(cell==36){erase();return false;} if(cell==37){next();return false;}
    if(cell==39)return true;
    if(length<63){value[length++]=cell==38?' ':character(cell);value[length]=0;}
    return false;
  }
};
