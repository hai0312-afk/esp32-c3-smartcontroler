#pragma once
#include <Adafruit_SSD1306.h>
namespace ui {
void icon(Adafruit_SSD1306 &d,int type,int x,int y,uint32_t now,bool animate);
void gameIcon(Adafruit_SSD1306 &d,int game,int x,int y,uint32_t now,bool animate);
void ring(Adafruit_SSD1306 &d,int x,int y,int radius,uint16_t progress);
void spinner(Adafruit_SSD1306 &d,int x,int y,uint32_t now);
void loading(Adafruit_SSD1306 &d,int x,int y,int width,uint32_t now);
void clippedText(Adafruit_SSD1306 &d,int x,int y,int width,const String &text,int offset=0);
int marquee(int textPixels,int available,uint32_t elapsed);
}
