#include "WebGames.h"
#include <WiFi.h>
#include <WebServer.h>
#include <WebSocketsServer.h>
#include <Preferences.h>
#include <esp_mac.h>
#include <esp_wifi.h>
#include "WebAssets.h"
#include "ConsoleInput.h"
#include "HomeJoinPolicy.h"

namespace WebGames {
static WebServer http(80);
static WebSocketsServer ws(81);
static bool active=false,routesReady=false,authorized[WEBSOCKETS_SERVER_CLIENT_MAX]={};
static char apName[25]={},pairPin[7]={},token[33]={};
static String routerSSID,routerPass;
static bool routerWanted=false;
static HomeJoinPolicy homeJoin;
static volatile uint8_t lastReason=0;
static volatile uint32_t disconnectEvents=0;
static uint32_t reportedEvents=0;
static uint32_t sendAt=0,seq=0,authWindow=0;
static uint8_t authFailures=0;
static int pairClient=-1; static bool pairAllowed=false,pairRelease=false; static uint32_t pairAt=0;

static int16_t axes[4]={}; static uint8_t buttons=0;
static bool paused=true; static uint32_t held=0;
static bool validToken(const String &value) {
  if(value.length()!=32) return false;
  uint8_t diff=0; for(int i=0;i<32;i++) diff|=value[i]^token[i]; return diff==0;
}
static String quoted(const String &s) {
  String out="\"";
  for(size_t i=0;i<s.length();i++) { unsigned char c=s[i];
    if(c=='"'||c=='\\') { out+='\\'; out+=(char)c; }
    else if(c<32) { char b[7]; snprintf(b,sizeof(b),"\\u%04x",c); out+=b; }
    else out+=(char)c;
  }
  return out+"\"";
}
static void json(int code,const String &body) { http.sendHeader("Cache-Control","no-store"); http.send(code,"application/json; charset=utf-8",body); }
static bool sameOrigin() {
  String origin=http.header("Origin");
  return !origin.length() || origin==String("http://")+http.hostHeader() || origin==String("https://")+http.hostHeader();
}
void forgetLegacyNetwork() {
  // One-time removal of router credentials saved by web1. No new network credentials in NVS.
  Preferences p;
  if(p.begin("contl_web",true)) {
    bool old=p.isKey("ssid")||p.isKey("pass")||p.isKey("router");p.end();
    if(old && p.begin("contl_web",false)){p.clear();p.end();}
  }
}
uint8_t clients() { uint8_t n=0; for(bool yes:authorized) if(yes)n++; return n; }
static void socketEvent(uint8_t id,WStype_t type,uint8_t *payload,size_t length) {
  if(id>=WEBSOCKETS_SERVER_CLIENT_MAX) return;
  if(type==WStype_DISCONNECTED) { authorized[id]=false; if(pairClient==id){pairClient=-1;pairAllowed=false;} return; }
  if(type==WStype_CONNECTED) {
    String url; for(size_t i=0;i<length && i<180;i++) url+=(char)payload[i];
    if(url=="/pair") {
      if(pairClient>=0 || clients()){ws.sendTXT(id,"{\"t\":\"busy\"}");ws.disconnect(id);return;}
      pairClient=id;pairAllowed=false;pairAt=millis();
      ws.sendTXT(id,"{\"t\":\"pair\",\"allowed\":false}");return;
    }
    int pos=url.indexOf("token="); String supplied=pos>=0?url.substring(pos+6):String();
    if(validToken(supplied) && clients()>=1) { ws.sendTXT(id,"{\"t\":\"busy\"}"); ws.disconnect(id); return; }
    bool ok=validToken(supplied);
    authorized[id]=ok;
    ws.sendTXT(id,ok?"{\"t\":\"auth\",\"ok\":true}":"{\"t\":\"auth\",\"ok\":false}");
    if(!ok) ws.disconnect(id);
    else if(pairClient>=0) ws.disconnect((uint8_t)pairClient);
    return;
  }
  if(type==WStype_TEXT && authorized[id] && length>2 && length<32 && payload[0]=='P' && payload[1]==':') {
    bool digits=true; for(size_t i=2;i<length;i++) if(payload[i]<'0'||payload[i]>'9')digits=false;
    if(digits) ws.sendTXT(id,payload,length); // browser measures its own round-trip clock
  }
}
static void startStation() {
  WiFi.setAutoReconnect(false);WiFi.setSleep(false);
  WiFi.begin(routerSSID.c_str(),routerPass.c_str());
  Serial.printf("[WEB-WIFI] attempt=%u/%u status=%d; STA only, AP disabled\n",homeJoin.attempt,HomeJoinPolicy::maxAttempts,(int)WiFi.status());
}
void retryHomeNetwork(){
  if(!active||!routerWanted)return;
  WiFi.disconnect(false,false);homeJoin.begin(millis());startStation();
}
static void routes() {
  if(routesReady)return; routesReady=true;
  const char *headers[]={"X-ConTL-Token","Origin"}; http.collectHeaders(headers,2);
  http.on("/",HTTP_GET,[]{ http.sendHeader("Content-Encoding","gzip"); http.sendHeader("Cache-Control","no-cache"); http.send_P(200,"text/html; charset=utf-8",(const char*)web_assets::index_html,web_assets::index_html_len); });
  http.on("/style.css",HTTP_GET,[]{ http.sendHeader("Content-Encoding","gzip"); http.sendHeader("Cache-Control","no-cache"); http.send_P(200,"text/css; charset=utf-8",(const char*)web_assets::style_css,web_assets::style_css_len); });
  http.on("/compat.js",HTTP_GET,[]{ http.sendHeader("Content-Encoding","gzip");http.sendHeader("Cache-Control","no-cache");http.send_P(200,"application/javascript; charset=utf-8",(const char*)web_assets::compat_js,web_assets::compat_js_len); });
  http.on("/games.js",HTTP_GET,[]{ http.sendHeader("Content-Encoding","gzip"); http.sendHeader("Cache-Control","no-cache"); http.send_P(200,"application/javascript; charset=utf-8",(const char*)web_assets::games_js,web_assets::games_js_len); });
  http.on("/app.js",HTTP_GET,[]{ http.sendHeader("Content-Encoding","gzip"); http.sendHeader("Cache-Control","no-cache"); http.send_P(200,"application/javascript; charset=utf-8",(const char*)web_assets::app_js,web_assets::app_js_len); });
  http.on("/favicon.ico",HTTP_GET,[]{http.send(204);});
  http.on("/api/status",HTTP_GET,[]{
    json(200,String("{\"apSSID\":")+quoted(apName)+",\"apIP\":"+quoted(apIP())+",\"lanIP\":"+quoted(lanIP())+
      ",\"routerSSID\":"+quoted(routerSSID)+",\"routerWanted\":"+(routerWanted?"true":"false")+",\"state\":"+quoted(networkState())+",\"clients\":"+clients()+"}");
  });
  http.on("/api/auth",HTTP_POST,[]{
    if(!sameOrigin()){json(403,"{\"error\":\"Origin không hợp lệ.\"}");return;}
    uint32_t now=millis(); if(now-authWindow>=30000){authWindow=now;authFailures=0;}
    if(authFailures>=8){json(429,"{\"error\":\"Thử sai nhiều lần; đợi 30 giây.\"}");return;}
    if(http.arg("code")!=pairPin){authFailures++;json(401,"{\"error\":\"Mã không đúng. Xem 6 số trên OLED.\"}");return;}
    authFailures=0; json(200,String("{\"token\":\"")+token+"\"}");
  });
  http.on("/api/wifi",HTTP_POST,[]{json(405,"{\"error\":\"Chọn Wi-Fi và nhập mật khẩu trên OLED. Không lưu router.\"}");});
  http.onNotFound([]{http.send(404,"text/plain","Not found");});
  ws.onEvent(socketEvent);
}
bool begin(const char *homeSSID,const char *homePassword) {
  stop(); forgetLegacyNetwork();
  routerSSID=homeSSID?homeSSID:"";routerPass=homePassword?homePassword:"";
  routerWanted=routerSSID.length()>0;
  uint8_t mac[6]; esp_read_mac(mac,ESP_MAC_WIFI_STA);
  snprintf(apName,sizeof(apName),"ConTL_Play_%02X%02X",mac[4],mac[5]);
  WiFi.persistent(false);WiFi.setAutoReconnect(false);
  WiFi.disconnect(true,false);WiFi.mode(WIFI_OFF);
  static bool eventHook=false;
  if(!eventHook){eventHook=true;WiFi.onEvent([](arduino_event_id_t,arduino_event_info_t info){
    if(active&&routerWanted){lastReason=info.wifi_sta_disconnected.reason;disconnectEvents++;}
  },ARDUINO_EVENT_WIFI_STA_DISCONNECTED);}
  WiFi.mode(routerWanted?WIFI_STA:WIFI_AP);WiFi.setSleep(false);
  esp_wifi_set_storage(WIFI_STORAGE_RAM);
  if(!routerWanted){
    IPAddress ip(192,168,4,1);WiFi.softAPConfig(ip,ip,IPAddress(255,255,255,0));
    if(!WiFi.softAP(apName,ctl::WIFI_PASSWORD,ctl::WIFI_CHANNEL,false,2)){WiFi.mode(WIFI_OFF);return false;}
  }
  snprintf(pairPin,sizeof(pairPin),"%06lu",(unsigned long)(esp_random()%1000000));
  snprintf(token,sizeof(token),"%08lx%08lx%08lx%08lx",(unsigned long)esp_random(),(unsigned long)esp_random(),(unsigned long)esp_random(),(unsigned long)esp_random());
  routes(); http.begin(); ws.begin(); ws.enableHeartbeat(5000,2000,2);
  memset(authorized,0,sizeof(authorized)); active=true; paused=true; held=0; buttons=0;
  memset(axes,0,sizeof(axes)); sendAt=0;seq=0;authWindow=millis();authFailures=0;lastReason=0;disconnectEvents=reportedEvents=0;
  homeJoin.stop();
  if(routerWanted){homeJoin.begin(millis());startStation();}
  else Serial.printf("[WEB] AP=%s IP=%s HTTP=80 WS=81 (PIN shown only on OLED)\n",apName,apIP().c_str());
  return true;
}
void update() {
  if(!active)return;
  http.handleClient(); ws.loop(); uint32_t now=millis();
  if(pairClient>=0 && now-pairAt>120000) ws.disconnect((uint8_t)pairClient);
  if(routerWanted){
    bool hasIP=WiFi.status()==WL_CONNECTED&&(uint32_t)WiFi.localIP()!=0;
    auto previous=homeJoin.stage;auto action=homeJoin.tick(now,hasIP);
    if(action==HomeJoinPolicy::DISCONNECT)WiFi.disconnect(false,false);
    if(action==HomeJoinPolicy::CONNECT)startStation();
    if(previous!=homeJoin.stage&&homeJoin.stage==HomeJoinPolicy::ONLINE)
      Serial.printf("[WEB-WIFI] LAN=%s channel=%u RSSI=%d; AP disabled\n",lanIP().c_str(),WiFi.channel(),WiFi.RSSI());
    if(previous!=homeJoin.stage&&homeJoin.stage==HomeJoinPolicy::FAILED)
      Serial.printf("[WEB-WIFI] failed status=%d reason=%u; OLED: retry/edit/use AP (no auto fallback)\n",(int)WiFi.status(),lastReason);
    if(reportedEvents!=disconnectEvents){reportedEvents=disconnectEvents;
      Serial.printf("[WEB-WIFI] disconnect reason=%u status=%d attempt=%u\n",lastReason,(int)WiFi.status(),homeJoin.attempt);
    }
  }
  if(now-sendAt>=25) {
    sendAt=now;
    char message[192];
    snprintf(message,sizeof(message),"{\"t\":\"input\",\"s\":%lu,\"a\":[%d,%d,%d,%d],\"b\":%u,\"p\":%s,\"h\":%lu}",
      (unsigned long)++seq,axes[0],axes[1],axes[2],axes[3],buttons,paused?"true":"false",(unsigned long)held);
    for(uint8_t id=0;id<WEBSOCKETS_SERVER_CLIENT_MAX;id++)if(authorized[id])ws.sendTXT(id,message);
    // Pre-auth connection receives only UI navigation AFTER physical OLED approval.
    // Never send a PIN, token, raw axes, network password or game controls here.
    if(pairClient>=0 && pairAllowed) {
      bool locked=paused||pairRelease;
      snprintf(message,sizeof(message),"{\"t\":\"nav\",\"d\":%d,\"b\":%u,\"p\":%s}",locked?-1:consoleDirection(axes[0],axes[1]),locked?0:buttons,locked?"true":"false");
      ws.sendTXT((uint8_t)pairClient,message);
    }
  }
}
void input(const Input &in,bool pause,uint32_t heldMs) {
  if(pairRelease && !in.buttons)pairRelease=false;
  paused=pause; held=heldMs; buttons=pause?0:in.buttons;
  for(int i=0;i<4;i++)axes[i]=pause?0:in.axis[i];
}
void stop() {
  if(active) {
    for(uint8_t id=0;id<WEBSOCKETS_SERVER_CLIENT_MAX;id++)if(authorized[id])ws.sendTXT(id,"{\"t\":\"closed\"}");
    ws.close();http.stop();WiFi.softAPdisconnect(true);WiFi.disconnect(true,false);WiFi.mode(WIFI_OFF);
  }
  active=false;homeJoin.stop();memset(authorized,0,sizeof(authorized));token[0]=0;
  pairClient=-1;pairAllowed=false;pairRelease=false;routerSSID="";
  for(size_t i=0;i<routerPass.length();i++)routerPass.setCharAt(i,0);
  routerPass="";routerWanted=false;pairPin[0]=0;
}
bool waitingForApproval(){return pairClient>=0&&!pairAllowed;}
bool pairing(){return pairClient>=0;}
void approvePairing(){if(!waitingForApproval())return;pairAllowed=true;pairRelease=true;pairAt=millis();ws.sendTXT((uint8_t)pairClient,"{\"t\":\"pair\",\"allowed\":true}");}
const char *homeSSID(){return routerSSID.c_str();}
const char *homePassword(){return routerPass.c_str();}
bool running(){return active;}
const char *ssid(){return apName;}
const char *pin(){return pairPin;}
bool networkReady(){return active&&(!routerWanted||(homeJoin.stage==HomeJoinPolicy::ONLINE&&WiFi.status()==WL_CONNECTED&&(uint32_t)WiFi.localIP()!=0));}
bool networkFailed(){return routerWanted&&homeJoin.stage==HomeJoinPolicy::FAILED;}
uint8_t networkAttempt(){return homeJoin.attempt;}
uint8_t networkReason(){return lastReason;}
uint32_t networkSeconds(){return homeJoin.stage==HomeJoinPolicy::JOINING?(millis()-homeJoin.since)/1000:0;}
const char *networkState(){return !routerWanted?"C3 Wi-Fi / AP":networkFailed()?"Home Wi-Fi failed":homeJoin.stage==HomeJoinPolicy::ONLINE?"Home Wi-Fi / LAN":homeJoin.stage==HomeJoinPolicy::RETRY_WAIT?"Retrying home Wi-Fi":"Joining home Wi-Fi";}
String apIP(){return active&&!routerWanted?WiFi.softAPIP().toString():String("");}
String lanIP(){return active&&routerWanted&&WiFi.status()==WL_CONNECTED?WiFi.localIP().toString():String("");}
}
