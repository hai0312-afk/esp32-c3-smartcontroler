#pragma once
#include "Protocol.h"
namespace BleOutput {
  bool begin();
  void stop();
  bool connected();
  void update();
  const char *status();
  void send(const ctl::HidReport &h);
  void release();
}
