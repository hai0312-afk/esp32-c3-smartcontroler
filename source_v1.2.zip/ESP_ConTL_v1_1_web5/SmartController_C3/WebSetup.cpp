#include "WebSetup.h"
#include "WebGames.h"
#include "ConsoleInput.h"
#include <WiFi.h>
#include <esp_wifi.h>
namespace WebSetup {
enum Stage { MODE,SCAN_PREP,SCANNING,NETWORKS,PASSWORD,STARTING,ONLINE,FAILED };
static Stage stage=MODE;
struct Network { char ssid[33];int32_t rssi;bool open; };
static Network nets[24];static int count=0,selected=0,mode=0;
static char chosen[33]={},message[23]={};static bool openNetwork=false,scanStarted=false,ready=false,showPassword=false;
static uint32_t at=0,scanAt=0;static ConsoleRepeat repeat;static OledKeyboard keyboard;
struct ScanFlags:WiFiGenericClass {static void reset(){clearStatusBits(WIFI_SCANNING_BIT);}};
static void go(Stage s){stage=s;at=millis();repeat.reset();}
static void stopScan(){bool done=WiFi.scanComplete()>=0;esp_wifi_scan_stop();if(done)WiFi.scanDelete();scanStarted=false;}
void stop(){stopScan();WebGames::stop();WiFi.disconnect(true,false);WiFi.mode(WIFI_OFF);keyboard.clear();memset(chosen,0,sizeof(chosen));count=0;ready=false;}
void begin(){stop();WebGames::forgetLegacyNetwork();mode=0;selected=0;message[0]=0;go(MODE);}
bool online(){return stage==ONLINE;}
bool needsDrain(){return (stage==SCAN_PREP||stage==STARTING)&&millis()-at>=180;}
static void requestScan(){stopScan();count=0;selected=0;go(SCAN_PREP);}
void tick(const Input &in,bool displayIdle){
  if(!ready){if(in.buttons)return;ready=true;return;}
  int direction=repeat.step(in.axis[0],in.axis[1],millis());
  bool select=in.hit(ctl::B_J1),back=in.hit(ctl::B_J2);
  switch(stage){
    case MODE:
      if(direction>=0 || in.hit(ctl::B_L|ctl::B_R))mode^=1;
      if(select){keyboard.clear();chosen[0]=0;if(mode)requestScan();else go(STARTING);ready=false;}
      break;
    case SCAN_PREP:
      if(back){go(MODE);ready=false;break;}
      if(needsDrain()&&displayIdle){
        WiFi.persistent(false);WiFi.mode(WIFI_STA);WiFi.setAutoReconnect(false);WiFi.setSleep(false);esp_wifi_set_storage(WIFI_STORAGE_RAM);WiFi.disconnect(false,false);
        go(SCANNING);scanStarted=false;
      }break;
    case SCANNING:
      if(back){stopScan();WiFi.mode(WIFI_OFF);go(MODE);ready=false;break;}
      if(!scanStarted&&millis()-at>=450){
        ScanFlags::reset();WiFi.scanDelete();int result=WiFi.scanNetworks(true,false,false,350);
        if(result==WIFI_SCAN_FAILED){strlcpy(message,"Scan failed; retry",sizeof(message));go(NETWORKS);break;}
        scanStarted=true;scanAt=millis();
      }
      if(scanStarted){int n=WiFi.scanComplete();if(n>=0){
        for(int i=0;i<n;i++){
          String name=WiFi.SSID(i);if(!name.length())continue;
          bool found=false;for(int j=0;j<count;j++)if(name==nets[j].ssid)found=true;
          if(found)continue;
          Network v={};strlcpy(v.ssid,name.c_str(),sizeof(v.ssid));v.rssi=WiFi.RSSI(i);v.open=WiFi.encryptionType(i)==WIFI_AUTH_OPEN;
          if(count<24)nets[count++]=v;else if(v.rssi>nets[count-1].rssi)nets[count-1]=v;else continue;
          for(int j=count-1;j>0&&nets[j].rssi>nets[j-1].rssi;j--){Network t=nets[j];nets[j]=nets[j-1];nets[j-1]=t;}
        }
        stopScan();strlcpy(message,count?"JOY1: pick network":"No SSID; scan again",sizeof(message));go(NETWORKS);
      }else if(n==WIFI_SCAN_FAILED||millis()-scanAt>12000){stopScan();strlcpy(message,"Scan timeout; retry",sizeof(message));go(NETWORKS);}}
      break;
    case NETWORKS:
      if(direction==1||direction==0)selected=(selected+1)%(count+1);
      if(direction==3||direction==2)selected=(selected+count)%(count+1);
      if(back){stopScan();WiFi.mode(WIFI_OFF);go(MODE);ready=false;break;}
      if(select){if(selected==count)requestScan();else {strlcpy(chosen,nets[selected].ssid,sizeof(chosen));openNetwork=nets[selected].open;keyboard.clear();message[0]=0;go(PASSWORD);}ready=false;}
      break;
    case PASSWORD:
      if(select||in.hit(ctl::B_L|ctl::B_R))message[0]=0;
      if(direction>=0)keyboard.move(direction);
      if(in.hit(ctl::B_L))keyboard.erase();if(in.hit(ctl::B_R))keyboard.next();
      if(back){keyboard.clear();go(NETWORKS);ready=false;break;}
      if(select&&keyboard.select()){
        if(openNetwork&&keyboard.length)strlcpy(message,"Open net: leave blank",sizeof(message));
        else if(!openNetwork&&keyboard.length<8)strlcpy(message,"Need 8-63 characters",sizeof(message));
        else {stopScan();go(STARTING);ready=false;}
      }break;
    case STARTING:
      if(needsDrain()&&displayIdle){
        bool ok=WebGames::begin(mode?chosen:nullptr,mode?keyboard.value:nullptr);keyboard.clear();
        go(ok?ONLINE:FAILED);ready=false;
      }break;
    case ONLINE:
      if(!WebGames::networkReady()){
        WebGames::input(in,true);
        if(back){
          keyboard.clear();strlcpy(keyboard.value,WebGames::homePassword(),sizeof(keyboard.value));keyboard.length=strlen(keyboard.value);
          WebGames::stop();go(PASSWORD);ready=false;
        }else if(WebGames::networkFailed()&&select){WebGames::retryHomeNetwork();ready=false;}
        else if(WebGames::networkFailed()&&in.hit(ctl::B_R)){mode=0;chosen[0]=0;keyboard.clear();go(STARTING);ready=false;}
        break;
      }
      showPassword=in.down(ctl::B_R);
      if(WebGames::waitingForApproval()&&back){WebGames::approvePairing();ready=false;WebGames::input(in,true);break;}
      WebGames::input(in,false);break;
    case FAILED:
      if(select||back){go(MODE);ready=false;}break;
  }
}
static void text(Adafruit_SSD1306 &d,int x,int y,const String &s){d.setCursor(x,y);d.print(s);}
static String trim(const char *s,int n=20){String v(s);return v.length()>(unsigned)n?v.substring(0,n-1)+"~":v;}
static void row(Adafruit_SSD1306 &d,int y,const String &s,bool focus){if(focus){d.fillRoundRect(1,y-1,126,10,2,SSD1306_WHITE);d.setTextColor(SSD1306_BLACK);}text(d,4,y,s);d.setTextColor(SSD1306_WHITE);}
void draw(Adafruit_SSD1306 &d){
 d.setTextSize(1);d.setTextColor(SSD1306_WHITE);d.setTextWrap(false);
 switch(stage){
  case MODE:
   text(d,5,15,"WEB / CONNECT VIA");row(d,29,"C3 Wi-Fi / direct",mode==0);row(d,42,"Home Wi-Fi / router",mode==1);text(d,3,56,"JOY1 move / SW select");break;
  case SCAN_PREP:case SCANNING:
   text(d,6,20,"Scanning home Wi-Fi");text(d,6,34,"2.4 GHz / visible");text(d,6,50,"J2: back");break;
  case NETWORKS:{
   text(d,3,14,message);int first=selected>1?selected-1:0;
   for(int i=0;i<3;i++){int idx=first+i;if(idx>count)break;String title=idx==count?String("Scan again"):String(nets[idx].open?"o ":"* ")+trim(nets[idx].ssid,18);row(d,26+i*10,title,idx==selected);}
   text(d,3,56,"J1 select / J2 back");break;}
  case PASSWORD:{
   String pass=String(keyboard.value);if(pass.length()>19)pass=pass.substring(pass.length()-19);
   text(d,2,14,message[0]?String(message):String("PW:")+pass.substring(pass.length()>17?pass.length()-17:0));
   for(int i=0;i<40;i++){
    int x=4+(i%10)*12,y=26+(i/10)*9;String key;
    if(i==36)key="<";else if(i==37)key="Aa";else if(i==38)key="SP";else if(i==39)key="OK";else {char c=keyboard.character(i);key=c==' '?String("SP"):String(c);}
    if(i==keyboard.cell){d.fillRect(x-1,y-1,12,9,SSD1306_WHITE);d.setTextColor(SSD1306_BLACK);}
    text(d,x,y,key);d.setTextColor(SSD1306_WHITE);
   }break;}
  case STARTING:text(d,8,23,"Starting Web Games");text(d,8,40,mode?"Joining router...":"Creating C3 AP...");break;
  case ONLINE:{
   if(!WebGames::networkReady()){
    text(d,2,14,WebGames::networkFailed()?"HOME WI-FI FAILED":"JOINING HOME WI-FI");
    text(d,2,25,trim(chosen));
    if(WebGames::networkFailed()){
     text(d,2,36,String("Last reason: ")+WebGames::networkReason());
     text(d,2,46,"J1 retry / J2 edit");text(d,2,56,"R: use C3 Wi-Fi");
    }else{
     text(d,2,36,String("Try ")+WebGames::networkAttempt()+"/2   "+WebGames::networkSeconds()+"s/25s");
     text(d,2,46,WebGames::networkState());text(d,2,56,"J2: edit / cancel");
    }
    break;
   }
   text(d,2,14,String("PIN ")+WebGames::pin()+"  WEB:"+WebGames::clients());
   text(d,2,25,WebGames::waitingForApproval()?"J2: allow PIN keypad":WebGames::pairing()?"Enter PIN on browser":WebGames::networkState());
   bool lan=WebGames::lanIP().length()>0;
   text(d,2,36,trim(lan?WebGames::homeSSID():WebGames::ssid()));
   text(d,2,46,String(lan?"LAN ":"AP  ")+(lan?WebGames::lanIP():WebGames::apIP()));
   if(lan && WebGames::homePassword()[0]){
    if(showPassword){String pass=WebGames::homePassword();int maxOffset=pass.length()>17?pass.length()-17:0;int offset=maxOffset?(millis()/450)%(maxOffset+1):0;text(d,2,56,String("PW:")+pass.substring(offset,offset+17));}
    else text(d,2,56,"Hold R: Wi-Fi pass");
   }else text(d,2,56,lan?String("Open home network"):String("PW:")+ctl::WIFI_PASSWORD);
   break;}
  case FAILED:text(d,6,23,"WEB INIT FAILED");text(d,6,40,"J1/J2: try again");break;
 }
}
}
