#include "BleOutput.h"
#include <NimBLEDevice.h>
#include <NimBLEHIDDevice.h>
#include <esp_heap_caps.h>
#include <atomic>
#include <new>
// NimBLE-Arduino 2.3.6. Do NOT include BLEDevice/BLEHIDDevice (Bluedroid) in this sketch.
namespace BleOutput {
static NimBLEServer *server=nullptr;
static NimBLEHIDDevice *hid=nullptr;
static NimBLECharacteristic *keys=nullptr,*mouse=nullptr;
static std::atomic<bool> online{false},encrypted{false},enabled{false};
static std::atomic<bool> keySubscribed{false},mouseSubscribed{false};
static std::atomic<bool> readvertise{false},secureRequest{false},dropRequest{false},refresh{false};
static std::atomic<uint16_t> connHandle{BLE_HS_CONN_HANDLE_NONE};
static uint8_t lastKeys[8]={},lastButtons=0;
static bool forceKeys=true,forceMouse=true;
static uint32_t refreshAt=0;
static const char *errorText="";
static const uint8_t reportMap[]={
  0x05,0x01,0x09,0x06,0xA1,0x01,0x85,0x01,
  0x05,0x07,0x19,0xE0,0x29,0xE7,0x15,0x00,0x25,0x01,
  0x75,0x01,0x95,0x08,0x81,0x02,
  0x95,0x01,0x75,0x08,0x81,0x01,
  0x95,0x05,0x75,0x01,0x05,0x08,0x19,0x01,0x29,0x05,0x91,0x02,
  0x95,0x01,0x75,0x03,0x91,0x01,
  0x95,0x06,0x75,0x08,0x15,0x00,0x25,0x65,0x05,0x07,0x19,0x00,0x29,0x65,0x81,0x00,0xC0,
  0x05,0x01,0x09,0x02,0xA1,0x01,0x85,0x02,
  0x09,0x01,0xA1,0x00,0x05,0x09,0x19,0x01,0x29,0x05,
  0x15,0x00,0x25,0x01,0x95,0x05,0x75,0x01,0x81,0x02,
  0x95,0x01,0x75,0x03,0x81,0x01,
  0x05,0x01,0x09,0x30,0x09,0x31,0x09,0x38,
  0x15,0x81,0x25,0x7F,0x75,0x08,0x95,0x03,0x81,0x06,0xC0,0xC0
};
class ServerCallbacks:public NimBLEServerCallbacks {
  void onConnect(NimBLEServer*,NimBLEConnInfo &info) override {
    connHandle=info.getConnHandle(); online=true; encrypted=info.isEncrypted();
    refresh=true;
    if(enabled) secureRequest=true; else dropRequest=true;
  }
  void onDisconnect(NimBLEServer*,NimBLEConnInfo&,int) override {
    online=false; encrypted=false; connHandle=BLE_HS_CONN_HANDLE_NONE;
    keySubscribed=false; mouseSubscribed=false; readvertise=true; refresh=true;
  }
  void onAuthenticationComplete(NimBLEConnInfo &info) override {
    encrypted=info.isEncrypted(); refresh=true;
    if(!info.isEncrypted()) dropRequest=true;
  }
};
class ReportCallbacks:public NimBLECharacteristicCallbacks {
  void onSubscribe(NimBLECharacteristic *ch,NimBLEConnInfo&,uint16_t value) override {
    if(ch==keys) keySubscribed=(value&1)!=0;
    if(ch==mouse) mouseSubscribed=(value&1)!=0;
    refresh=true;
  }
};
static ServerCallbacks serverCallbacks;
static ReportCallbacks reportCallbacks;

void update() {
  if(!server) return;
  uint16_t handle=connHandle.load();
  if(dropRequest.exchange(false) && handle!=BLE_HS_CONN_HANDLE_NONE) server->disconnect(handle);
  if(secureRequest.exchange(false) && enabled && handle!=BLE_HS_CONN_HANDLE_NONE) {
    NimBLEDevice::startSecurity(handle);
  }
  if(readvertise.exchange(false) && enabled && !online) NimBLEDevice::startAdvertising();
}
bool begin() {
  if(!server) {
    uint32_t heap=ESP.getFreeHeap();
    uint32_t largest=heap_caps_get_largest_free_block(MALLOC_CAP_8BIT);
    Serial.printf("[BLE] NimBLE init heap=%lu largest=%lu\n",(unsigned long)heap,(unsigned long)largest);
    if(heap<65000 || largest<32000) { errorText="Low heap"; return false; }
    if(!NimBLEDevice::init("ESP ConTL v1.1")) { errorText="Init failed"; return false; }
    NimBLEDevice::setSecurityAuth(true,false,true); // bonding, no MITM, secure connections
    NimBLEDevice::setSecurityIOCap(BLE_HS_IO_NO_INPUT_OUTPUT);
    server=NimBLEDevice::createServer();
    if(!server) { NimBLEDevice::deinit(true); errorText="No server"; return false; }
    server->setCallbacks(&serverCallbacks,false);
    server->advertiseOnDisconnect(false); // main-loop update() owns restart, never a BLE callback
    hid=new(std::nothrow) NimBLEHIDDevice(server);
    if(!hid) { NimBLEDevice::deinit(true); server=nullptr; errorText="No HID heap"; return false; }
    keys=hid->getInputReport(1); mouse=hid->getInputReport(2); hid->getOutputReport(1);
    keys->setCallbacks(&reportCallbacks); mouse->setCallbacks(&reportCallbacks);
    uint8_t k[8]={},m[4]={}; keys->setValue(k,8); mouse->setValue(m,4);
    hid->setManufacturer("HDZ463");
    hid->setPnp(0x02,0x303A,0x4001,0x0111); hid->setHidInfo(0x00,0x01);
    hid->setReportMap((uint8_t*)reportMap,sizeof(reportMap)); hid->startServices();
    server->start();
    NimBLEAdvertising *ad=NimBLEDevice::getAdvertising();
    ad->setAppearance(HID_KEYBOARD); ad->addServiceUUID(hid->getHidService()->getUUID());
    ad->enableScanResponse(true); ad->setName("ESP ConTL v1.1");
    Serial.printf("[BLE] services ready heap=%lu\n",(unsigned long)ESP.getFreeHeap());
  }
  errorText=""; enabled=true; forceKeys=forceMouse=true; refreshAt=0;
  readvertise=false;
  if(!NimBLEDevice::startAdvertising()) {
    enabled=false; errorText="Adv failed"; Serial.println("[BLE] advertising failed"); return false;
  }
  return true;
}
bool connected() { return enabled && online; }
const char *status() {
  if(errorText[0]) return errorText;
  if(!online) return "Pair on host";
  if(!encrypted) return "Pairing...";
  if(!keySubscribed && !mouseSubscribed) return "Host config";
  return "HID ready";
}
void send(const ctl::HidReport &h) {
  if(!enabled || !online || !encrypted) { forceKeys=forceMouse=true; return; }
  if(refresh.exchange(false) || millis()-refreshAt>=250) {
    forceKeys=forceMouse=true; refreshAt=millis();
  }
  uint8_t k[8]={h.modifiers,0}; memcpy(k+2,h.keys,6);
  if(keySubscribed && (forceKeys || memcmp(k,lastKeys,8))) {
    keys->setValue(k,8);
    if(keys->notify()) { memcpy(lastKeys,k,8); forceKeys=false; }
  }
  if(mouseSubscribed && (forceMouse || h.mouseButtons!=lastButtons || h.dx || h.dy || h.wheel)) {
    uint8_t m[4]={h.mouseButtons,(uint8_t)h.dx,(uint8_t)h.dy,(uint8_t)h.wheel};
    mouse->setValue(m,4);
    if(mouse->notify()) { lastButtons=h.mouseButtons; forceMouse=false; }
  }
}
void release() { forceKeys=forceMouse=true; send(ctl::HidReport{}); }
void stop() {
  if(!server) { enabled=false; return; }
  release(); enabled=false; readvertise=false; secureRequest=false;
  NimBLEDevice::getAdvertising()->stop();
  uint16_t handle=connHandle.load();
  if(handle!=BLE_HS_CONN_HANDLE_NONE) server->disconnect(handle);
  // Keep GATT objects alive: no delete/deinit while BLE callbacks may still refer to them.
  // One initialization per boot, reuse these same objects on each menu entry.
}
}
