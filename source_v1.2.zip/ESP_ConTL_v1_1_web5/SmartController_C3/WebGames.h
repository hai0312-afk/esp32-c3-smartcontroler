#pragma once
#include "Input.h"
namespace WebGames {
  bool begin(const char *homeSSID=nullptr,const char *homePassword=nullptr);
  void forgetLegacyNetwork();
  bool waitingForApproval();
  bool pairing();
  void approvePairing();
  const char *homeSSID();
  const char *homePassword();
  void stop();
  void update();
  void input(const Input &in,bool paused,uint32_t heldMs=0);
  bool running();
  bool networkReady();
  bool networkFailed();
  uint8_t networkAttempt();
  uint8_t networkReason();
  uint32_t networkSeconds();
  void retryHomeNetwork();
  const char *ssid();
  const char *pin();
  const char *networkState();
  String apIP();
  String lanIP();
  uint8_t clients();
}
