#pragma once
#include <WiFi.h>
#include <WiFiUdp.h>
#include <esp_now.h>
#include "Input.h"
#include "Discovery.h"
#include "LinkHealth.h"
class ControllerLink {
 public:
  enum State { OFF, SCANNING, LIST, CONNECTING, HANDSHAKE, READY, ERROR_STATE, LOCK_CHANNEL, VERIFY_LINK, RECOVER_WAIT };
  using Device=DiscoveryDevice;
  bool begin(bool usb);
  void scan();
  void connectTo(int index);
  void update();
  void sendControl(const Input &in,bool neutral=false);
  void stop();
  State state=OFF;
  bool rearmRequired=true;
  bool healthy() const { return state==READY && health_.healthy(millis()); }
  void acknowledgeRearm(){if(healthy())rearmRequired=false;}
  uint32_t recoveries=0; int8_t rssi=-127;
  volatile uint32_t txOK=0,txFail=0,queueDrops=0;
  int lastSendError=0; volatile uint8_t lastStaReason=0;
  Device devices[DISCOVERY_CAPACITY]; int count=0;
  uint16_t apsSeen=0; uint8_t scanPass=0; int lastScanError=0;
  char message[32]="";
  char peerName[33]="";
  uint8_t peerMac[6]={};
  float rttMs=-1;
  uint32_t pings=0, lostPings=0, sent=0, sendErrors=0;
  uint8_t channel=0,role=0,peerFlags=0;
 private:
  struct Rx { uint8_t mac[6]; ctl::Packet packet; uint32_t atUs,atMs;int8_t rssi; };
  static ControllerLink *self;
  static void receive(const esp_now_recv_info_t*,const uint8_t*,int);
  static void transmitted(const uint8_t*,esp_now_send_status_t);
  void fail(const char*);
  void clearNow();
  void cancelScan();
  void nextScanPass();
  void startJoin();
  bool sendPacket(ctl::Packet &p);
  bool usb_=false,nowOn_=false,pending_=false;
  QueueHandle_t queue_=nullptr;
  WiFiUDP udp_;
  uint32_t session_=0,seq_=0,stateAt_=0,helloAt_=0,pingAt_=0,pingSeq_=0,pingUs_=0;
  uint8_t misses_=0,joinAttempt_=0;
  bool scanRunning_=false,joinPending_=false;
  uint32_t scanDue_=0,scanAt_=0,joinDue_=0;
  Device selected_;
  LinkHealth health_;
  bool recovering_=false; uint8_t recoverAttempt_=0;
  uint32_t logAt_=0;
};
