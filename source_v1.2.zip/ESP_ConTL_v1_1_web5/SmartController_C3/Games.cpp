#include "Games.h"
#include <math.h>
const char *const Games::names[COUNT]={"Maze Munch","Star Defenders","Pocket Platform","Falling Blocks","Tiny Flap","Duo Pong","Twin Arena","Vector Storm","Micro Racer","Snake","Mini Tanks"};
const char *const Games::hints[COUNT]={"J1: move","J1: move R: fire","J1 move L run R jump","J1 move L/R rotate","R / J1SW: flap","J1 + J2: paddles","J1 move J2 shoot","J1/J2 + R: bomb","J1 steer R gas L stop","J1: turn","J1: move R: fire"};
static const char *MAZE[8]={
 "#####################",
 "#.........#.........#",
 "#.###.###.#.###.###.#",
 "#...#...........#...#",
 "###.#.##.#.#.##.#.###",
 "#.....#..#.#..#.....#",
 "#.......#...#.......#",
 "#####################"
};
static const int DX[4]={1,0,-1,0},DY[4]={0,1,0,-1};
static int joyDir(const Input &in,int old) {
  int x=in.axis[0],y=in.axis[1];
  if(abs(x)<350 && abs(y)<350) return old;
  if(abs(x)>abs(y)) return x>0?0:2;
  return y>0?1:3;
}
static bool wall(int x,int y) { return x<0 || x>=21 || y<0 || y>=8 || MAZE[y][x]=='#'; }
static const int8_t SHAPES[7][4][2]={
 {{0,1},{1,1},{2,1},{3,1}}, {{1,0},{2,0},{1,1},{2,1}},
 {{1,0},{0,1},{1,1},{2,1}}, {{1,0},{2,0},{0,1},{1,1}},
 {{0,0},{1,0},{1,1},{2,1}}, {{0,0},{0,1},{1,1},{2,1}}, {{2,0},{0,1},{1,1},{2,1}}
};
static void blockCell(int piece,int rot,int n,int &x,int &y) {
  x=SHAPES[piece][n][0]; y=SHAPES[piece][n][1];
  if(piece==1) return;
  for(int r=0;r<rot;r++) { int t=x; x=(piece==0?3:2)-y; y=t; }
}
void Games::fire(float x,float y,float dx,float dy,uint8_t type) {
  for(auto &s:shots) if(!s.live) { s={x,y,dx,dy,true,type}; return; }
}
void Games::start(int game) {
  id=constrain(game,0,COUNT-1); score=0; over=won=false; frame=0;
  health=3; cool=hurt=0; level=1; px=64; py=40; vx=vy=aux=aux2=0;
  a=b=c=dir=want=0; repeat=0;
  memset(cells,0,sizeof(cells)); memset(coins,0,sizeof(coins));
  for(auto &e:enemies) e=Body{};
  for(auto &s:shots) s=Body{};
  switch(id) {
    case 0:
      px=1; py=1;
      for(int y=0;y<8;y++) for(int x=0;x<21;x++) if(!wall(x,y)) { cells[y][x]=1; a++; }
      cells[1][1]=0; a--;
      enemies[0]={19,6,0,0,true,0}; enemies[1]={19,1,0,0,true,0}; enemies[2]={1,6,0,0,true,0};
      break;
    case 1:
      aux=1;
      for(int i=0;i<24;i++) enemies[i]={(float)(12+(i%8)*12),(float)(5+(i/8)*7),0,0,true,0};
      break;
    case 2:
      px=10; py=30;
      for(int i=0;i<20;i++) enemies[i]={(float)(48+i*32),35,-0.35f,0,true,0};
      break;
    case 3: next=random(7); newPiece(); break;
    case 4: px=25; py=24; for(int i=0;i<3;i++) enemies[i]={(float)(125+i*47),(float)random(13,34),0,0,true,0}; break;
    case 5: px=py=25; aux=64; aux2=25; vx=random(2)?1.3f:-1.3f; vy=0.7f; break;
    case 6: case 7: px=64; py=25; a=3; break;
    case 8: px=64; py=40; a=0; break;
    case 9:
      length=4; for(int i=0;i<length;i++) { sx[i]=10-i; sy[i]=6; } snakeFood(); break;
    case 10:
      px=12; py=40; dir=3;
      for(int y=1;y<7;y++) for(int x=2;x<19;x++) if(x%4==0 && y%3!=0) cells[y][x]=2;
      for(int i=0;i<5;i++) enemies[i]={(float)(22+i*20),5,0,0,true,1};
      break;
  }
}
void Games::tick(const Input &in) {
  if(over) { if(in.hit(ctl::B_R|ctl::B_J1)) start(id); return; }
  frame++; if(cool>0) cool--; if(hurt>0) hurt--;
  switch(id) {
    case 0: maze(in); break; case 1: invaders(in); break; case 2: platform(in); break;
    case 3: blocks(in); break; case 4: flappy(in); break; case 5: pong(in); break;
    case 6: case 7: twin(in); break; case 8: race(in); break; case 9: snake(in); break; case 10: tank(in); break;
  }
}
void Games::maze(const Input &in) {
  want=joyDir(in,want);
  if(frame%6==0) {
    int x=px,y=py;
    if(!wall(x+DX[want],y+DY[want])) dir=want;
    if(!wall(x+DX[dir],y+DY[dir])) { px+=DX[dir]; py+=DY[dir]; }
    if(cells[(int)py][(int)px]) {
      cells[(int)py][(int)px]=0; score+=10; a--;
      if((px==1 && py==6)||(px==19 && py==1)) b=150;
      if(!a) { over=won=true; }
    }
  }
  if(b>0) b--;
  for(auto &e:enemies) {
    if(!e.live) continue;
    if(frame%11==0) {
      int best=-1; float value=1e9;
      for(int n=0;n<4;n++) if(!wall((int)e.x+DX[n],(int)e.y+DY[n])) {
        float cost=abs(e.x+DX[n]-px)+abs(e.y+DY[n]-py)+random(5);
        if(b) cost=-cost;
        if(cost<value) { value=cost; best=n; }
      }
      if(best>=0) { e.x+=DX[best]; e.y+=DY[best]; }
    }
    if((int)e.x==(int)px && (int)e.y==(int)py) {
      if(b) { e.x=19; e.y=6; score+=100; }
      else over=true;
    }
  }
}
void Games::invaders(const Input &in) {
  px=constrain(px+in.axis[0]*0.002f,4.0f,123.0f);
  if(in.down(ctl::B_R) && !cool) { fire(px,40,0,-2.5f); cool=9; }
  bool edge=false,any=false;
  for(auto &e:enemies) if(e.live) {
    any=true; e.x+=aux*(0.10f+level*0.035f);
    if(e.x<4 || e.x>123) edge=true;
    if(e.y>39) over=true;
  }
  if(edge) { aux=-aux; for(auto &e:enemies) if(e.live) { e.y+=3; e.x+=aux; } }
  if(frame%(max(12,45-level*3))==0) {
    int i=random(24); if(enemies[i].live) fire(enemies[i].x,enemies[i].y,0,1.0f+level*0.08f,1);
  }
  for(auto &s:shots) if(s.live) {
    s.x+=s.vx; s.y+=s.vy;
    if(s.y<1 || s.y>48) { s.live=false; continue; }
    if(!s.type) {
      for(auto &e:enemies) if(e.live && abs(s.x-e.x)<4 && abs(s.y-e.y)<3) {
        s.live=e.live=false; score+=10; break;
      }
    } else if(abs(s.x-px)<4 && s.y>40 && s.y<47 && !hurt) {
      s.live=false; health--; hurt=40; if(!health) over=true;
    }
  }
  if(!any) {
    level++; for(auto &s:shots) s.live=false;
    for(int i=0;i<24;i++) enemies[i]={(float)(12+(i%8)*12),(float)(5+(i/8)*7),0,0,true,0};
  }
}
bool Games::solid(float x,float y) {
  int tx=(int)floorf(x/8),ty=(int)floorf(y/8);
  if(tx<0) return true;
  if(ty<0 || ty>5 || tx>=96) return false;
  if(ty==5) return !(tx>6 && (tx%20==12 || tx%20==13));
  return ty==3 && tx%16>=6 && tx%16<=9;
}
void Games::platform(const Input &in) {
  float speed=in.down(ctl::B_L)?1.9f:1.15f;
  vx=in.axis[0]*speed/1000;
  if(abs(in.axis[0])>300) dir=in.axis[0]>0?0:2;
  bool ground=solid(px-2,py+4)||solid(px+2,py+4);
  bool crouch=in.axis[1]>450 && ground; c=crouch;
  float top=crouch?1.0f:3.0f;
  if(crouch) vx=0;
  if(in.hit(ctl::B_R) && ground) vy=-2.8f;
  vy=min(vy+0.16f,3.5f);
  float nx=constrain(px+vx,3.0f,764.0f);
  if(!solid(nx+(vx>0?2:-2),py-top) && !solid(nx+(vx>0?2:-2),py+2)) px=nx;
  float ny=py+vy;
  if(vy>=0 && (solid(px-2,ny+3)||solid(px+2,ny+3))) { py=floorf((ny+3)/8)*8-3; vy=0; }
  else if(vy<0 && (solid(px-2,ny-top)||solid(px+2,ny-top))) { py=(floorf((ny-top)/8)+1)*8+top; vy=0; }
  else py=ny;
  if(in.down(ctl::B_L) && !cool) { fire(px,py,dir==2?-3:3,0); cool=15; }
  for(int i=0;i<40;i++) if(!coins[i]) {
    float x=22+i*18,y=(i%3==0)?18:33;
    if(abs(px-x)<5 && abs(py-y)<7) { coins[i]=true; score+=5; }
  }
  for(auto &e:enemies) if(e.live) {
    float nx=e.x+e.vx;
    if(solid(nx+(e.vx>0?3:-3),41)) e.x=nx; else e.vx=-e.vx;
    if(abs(e.x-px)<5 && abs(e.y-py)<6) {
      if(vy>0 && py<e.y-2) { e.live=false; vy=-2; score+=20; }
      else if(!hurt) { health--; hurt=60; if(!health) over=true; }
    }
  }
  for(auto &s:shots) if(s.live) {
    s.x+=s.vx;
    if(abs(s.x-px)>130 || solid(s.x,s.y)) { s.live=false; continue; }
    for(auto &e:enemies) if(e.live && abs(s.x-e.x)<4 && abs(s.y-e.y)<5) { e.live=s.live=false; score+=20; break; }
  }
  if(py>54) { health--; if(!health) over=true; else { px=10; py=30; vy=0; hurt=60; } }
  aux=constrain(px-45,0.0f,640.0f);
  if(px>750) { score+=100; over=won=true; }
}
bool Games::blockFits(int x,int y,int r) {
  for(int n=0;n<4;n++) {
    int xx,yy; blockCell(piece,r,n,xx,yy); xx+=x; yy+=y;
    if(xx<0 || xx>=10 || yy>=12 || (yy>=0 && cells[yy][xx])) return false;
  }
  return true;
}
void Games::newPiece() {
  piece=next; next=random(7); rotation=0; tx=3; ty=-1; fall=0;
  if(!blockFits(tx,ty,rotation)) over=true;
}
void Games::lockPiece() {
  for(int n=0;n<4;n++) {
    int x,y; blockCell(piece,rotation,n,x,y); x+=tx; y+=ty;
    if(y<0) { over=true; return; } cells[y][x]=1;
  }
  int cleared=0;
  for(int y=11;y>=0;y--) {
    bool full=true; for(int x=0;x<10;x++) if(!cells[y][x]) full=false;
    if(full) {
      cleared++; for(int yy=y;yy>0;yy--) memcpy(cells[yy],cells[yy-1],24);
      memset(cells[0],0,24); y++;
    }
  }
  score+=cleared*cleared*100; a+=cleared; newPiece();
}
void Games::blocks(const Input &in) {
  int move=in.axis[0]<-450?-1:(in.axis[0]>450?1:0);
  if(move && (!repeat || move!=b)) { if(blockFits(tx+move,ty,rotation)) tx+=move; repeat=7; }
  if(!move) repeat=0; else if(repeat) repeat--; b=move;
  int r=rotation;
  if(in.hit(ctl::B_L)) r=(rotation+3)%4;
  if(in.hit(ctl::B_R)) r=(rotation+1)%4;
  if(r!=rotation) {
    if(blockFits(tx,ty,r)) rotation=r;
    else if(blockFits(tx-1,ty,r)) { tx--; rotation=r; }
    else if(blockFits(tx+1,ty,r)) { tx++; rotation=r; }
  }
  if(in.hit(ctl::B_J1)) { while(blockFits(tx,ty+1,rotation)) ty++; lockPiece(); return; }
  if(++fall>=(in.axis[1]>450?3:max(5,25-a))) {
    fall=0; if(blockFits(tx,ty+1,rotation)) ty++; else lockPiece();
  }
}
void Games::flappy(const Input &in) {
  if(in.hit(ctl::B_R|ctl::B_J1)) vy=-1.65f;
  vy+=0.10f; py+=vy;
  if(py<3 || py>46) over=true;
  for(int i=0;i<3;i++) {
    Body &e=enemies[i]; float old=e.x;
    e.x-=0.8f+min(score,20)*0.015f;
    if(e.x< -8) { e.x+=141; e.y=random(13,35); }
    if(old>=px && e.x<px) score++;
    if(e.x<px+6 && e.x+7>px-2 && (py-2<e.y-10 || py+2>e.y+10)) over=true;
  }
}
void Games::pong(const Input &in) {
  px=constrain(px+in.axis[1]*0.002f,7.0f,42.0f);
  py=constrain(py+in.axis[3]*0.002f,7.0f,42.0f);
  if(cool) return;
  aux+=vx; aux2+=vy;
  if(aux2<2 || aux2>47) { vy=-vy; aux2=constrain(aux2,2.0f,47.0f); }
  if((aux<8 && vx<0 && abs(aux2-px)<8)||(aux>119 && vx>0 && abs(aux2-py)<8)) {
    vy=(aux2-(vx<0?px:py))*0.22f;
    vx=-vx*1.06f; vx=constrain(vx,-3.0f,3.0f);
  }
  if(aux<1 || aux>126) {
    if(aux<1) b++; else a++;
    aux=64; aux2=25; vx=vx>0?-1.3f:1.3f; vy=0.6f; cool=40;
    if(a>=7 || b>=7) { score=max(a,b); over=true; won=true; }
  }
}
void Games::twin(const Input &in) {
  px=constrain(px+in.axis[0]*0.0014f,4.0f,123.0f);
  py=constrain(py+in.axis[1]*0.0014f,4.0f,45.0f);
  float dx=in.axis[2],dy=in.axis[3],mag=sqrtf(dx*dx+dy*dy);
  if(mag>300 && !cool) { fire(px,py,dx*2.8f/mag,dy*2.8f/mag); cool=id==7?5:7; }
  if(id==7 && in.hit(ctl::B_R) && a>0) { a--; for(auto &e:enemies) if(e.live) { e.live=false; score+=10; } b=8; }
  if(b>0) b--;
  if(frame%(max(10,40-score/80))==0) {
    for(auto &e:enemies) if(!e.live) {
      bool side=random(2); e={(float)(side?random(2,126):(random(2)?2:125)),(float)(side?(random(2)?2:47):random(2,47)),0,0,true,(uint8_t)random(2)}; break;
    }
  }
  for(auto &e:enemies) if(e.live) {
    float dx=px-e.x,dy=py-e.y,mag=sqrtf(dx*dx+dy*dy);
    if(mag>0.1f) { float speed=0.25f+(id==7?0.14f:0.05f)+min(score,1500)*0.00008f; e.x+=dx*speed/mag; e.y+=dy*speed/mag; }
    if(mag<4 && !hurt) { e.live=false; health--; hurt=45; if(!health) over=true; }
  }
  for(auto &s:shots) if(s.live) {
    s.x+=s.vx; s.y+=s.vy;
    if(s.x<2 || s.x>126 || s.y<1 || s.y>48) { s.live=false; continue; }
    for(auto &e:enemies) if(e.live && abs(e.x-s.x)<4 && abs(e.y-s.y)<4) { s.live=e.live=false; score+=10; break; }
  }
}
void Games::race(const Input &in) {
  if(in.down(ctl::B_R)) vx=min(vx+0.025f,2.4f);
  else if(in.down(ctl::B_L)) vx=max(vx-0.05f,-0.6f);
  else vx*=0.98f;
  px=constrain(px+in.axis[0]*0.0015f*(vx<0?-1:1)*(0.3f+abs(vx)*0.5f),4.0f,123.0f);
  aux=max(0.0f,aux+vx); score=(int)aux;
  float center=64+18*sinf((aux+120)*0.01f);
  if(abs(px-center)>25 && abs(vx)>0.2f) {
    vx*=0.94f;
    if(++a>35) { a=0; health--; hurt=20; if(!health) over=true; }
  } else a=max(0,a-1);
  if(frame%60==0 && vx>0.4f) for(auto &e:enemies) if(!e.live) {
    e={64+18*sinf(aux*0.01f)+(float)random(-18,19),-5,0,0,true,0}; break;
  }
  for(auto &e:enemies) if(e.live) {
    e.y+=vx*0.75f;
    if(e.y>53 || e.y< -12) e.live=false;
    if(abs(e.x-px)<6 && abs(e.y-py)<7 && !hurt) { e.live=false; health--; hurt=45; vx=0.2f; if(!health) over=true; }
  }
  if(aux>=1200) over=won=true;
}
void Games::snakeFood() {
  if(length>=24*12) { over=won=true; return; }
  bool good=false;
  while(!good) {
    a=random(24); b=random(12); good=true;
    for(int i=0;i<length;i++) if(sx[i]==a && sy[i]==b) good=false;
  }
}
void Games::snake(const Input &in) {
  int d=joyDir(in,dir); if(d!=(dir+2)%4) want=d;
  if(frame%max(3,8-score/5)) return;
  dir=want; int x=sx[0]+DX[dir],y=sy[0]+DY[dir];
  bool eat=x==a && y==b;
  if(x<0 || x>=24 || y<0 || y>=12) { over=true; return; }
  for(int i=0;i<length-(eat?0:1);i++) if(sx[i]==x && sy[i]==y) { over=true; return; }
  if(eat) { length++; score++; }
  for(int i=length-1;i>0;i--) { sx[i]=sx[i-1]; sy[i]=sy[i-1]; }
  sx[0]=x; sy[0]=y; if(eat) snakeFood();
}
void Games::tank(const Input &in) {
  auto blocked=[&](float x,float y) {
    if(x<4 || x>123 || y<4 || y>45) return true;
    int cx=x/6,cy=y/6;
    return cells[cy][cx]!=0;
  };
  if(abs(in.axis[0])>350 || abs(in.axis[1])>350) {
    dir=joyDir(in,dir); float nx=px+DX[dir]*0.8f,ny=py+DY[dir]*0.8f;
    if(!blocked(nx-2,ny-2)&&!blocked(nx+2,ny-2)&&!blocked(nx-2,ny+2)&&!blocked(nx+2,ny+2)) { px=nx; py=ny; }
  }
  if(in.down(ctl::B_R)&&!cool) { fire(px+DX[dir]*4,py+DY[dir]*4,DX[dir]*2.2f,DY[dir]*2.2f); cool=12; }
  bool any=false;
  for(auto &e:enemies) if(e.live) {
    any=true;
    if(frame%40==0) {
      float dx=px-e.x,dy=py-e.y;
      e.type=abs(dx)>abs(dy)?(dx>0?0:2):(dy>0?1:3);
      if(random(3)==0) e.type=random(4);
      fire(e.x+DX[e.type]*4,e.y+DY[e.type]*4,DX[e.type]*1.5f,DY[e.type]*1.5f,1);
    }
    float nx=e.x+DX[e.type]*0.3f,ny=e.y+DY[e.type]*0.3f;
    if(!blocked(nx-2,ny-2)&&!blocked(nx+2,ny+2)) { e.x=nx; e.y=ny; }
  }
  for(auto &s:shots) if(s.live) {
    s.x+=s.vx; s.y+=s.vy;
    if(s.x<1 || s.x>126 || s.y<1 || s.y>48) { s.live=false; continue; }
    int x=s.x/6,y=s.y/6;
    if(cells[y][x]) { cells[y][x]--; s.live=false; continue; }
    if(s.type) {
      if(abs(s.x-px)<4 && abs(s.y-py)<4 && !hurt) { s.live=false; health--; hurt=40; if(!health) over=true; }
    } else for(auto &e:enemies) if(e.live && abs(s.x-e.x)<4 && abs(s.y-e.y)<4) { e.live=s.live=false; score+=100; break; }
  }
  if(!any) over=won=true;
}

void Games::draw(Adafruit_SSD1306 &d) {
  const int Y=13;
  auto rect=[&](int x,int y,int w,int h,bool fill=true) { if(fill) d.fillRect(x,y+Y,w,h,SSD1306_WHITE); else d.drawRect(x,y+Y,w,h,SSD1306_WHITE); };
  auto line=[&](int x,int y,int xx,int yy) { d.drawLine(x,y+Y,xx,yy+Y,SSD1306_WHITE); };
  auto text=[&](int x,int y,const String &s) { d.setCursor(x,y+Y); d.print(s); };
  auto dot=[&](int x,int y) { d.drawPixel(x,y+Y,SSD1306_WHITE); };
  switch(id) {
    case 0:
      for(int y=0;y<8;y++) for(int x=0;x<21;x++) {
        if(wall(x,y)) rect(x*6,y*6,6,6,false);
        else if(cells[y][x]) {
          if((x==1 && y==6)||(x==19 && y==1)) d.drawCircle(x*6+3,y*6+3+Y,2,SSD1306_WHITE);
          else dot(x*6+3,y*6+3);
        }
      }
      d.fillCircle(px*6+3,py*6+3+Y,2,SSD1306_WHITE);
      if(frame%12<6) d.drawPixel(px*6+3+DX[dir]*2,py*6+3+DY[dir]*2+Y,SSD1306_BLACK);
      for(auto &e:enemies) if(e.live) { rect(e.x*6+1,e.y*6+1,4,4,b==0 || frame%10<5); }
      break;
    case 1:
      for(auto &e:enemies) if(e.live) { rect(e.x-3,e.y-2,6,3); dot(e.x-4,e.y+2); dot(e.x+3,e.y+2); }
      if(!hurt || frame%4<2) { rect(px-4,44,9,3); rect(px-1,41,3,3); }
      for(auto &s:shots) if(s.live) rect(s.x,s.y,1,3);
      text(2,0,String(score)); text(106,0,String("L")+health); break;
    case 2: {
      for(int y=0;y<6;y++) for(int x=(int)aux/8;x<(int)aux/8+17;x++) if(solid(x*8+1,y*8+1)) rect(x*8-aux,y*8,8,8,false);
      for(int i=0;i<40;i++) if(!coins[i]) { float x=22+i*18-aux; if(x>0 && x<128) d.drawCircle(x,(i%3==0?18:33)+Y,1,SSD1306_WHITE); }
      for(auto &e:enemies) if(e.live && e.x-aux>-5 && e.x-aux<133) rect(e.x-aux-3,e.y-3,6,6);
      for(auto &s:shots) if(s.live && s.x-aux>0 && s.x-aux<128) rect(s.x-aux,s.y,2,1);
      if(!hurt || frame%4<2) { bool crouch=c; rect(px-aux-2,py-(crouch?1:3),5,crouch?4:6); }
      if(752-aux<128) { line(752-aux,8,752-aux,39); rect(752-aux,8,8,5); }
      text(1,0,String(score)); text(106,0,String("L")+health); break;
    }
    case 3:
      rect(43,0,42,50,false);
      for(int y=0;y<12;y++) for(int x=0;x<10;x++) if(cells[y][x]) rect(44+x*4,1+y*4,3,3);
      for(int n=0;n<4;n++) {
        int x,y; blockCell(piece,rotation,n,x,y); if(y+ty>=0) rect(44+(x+tx)*4,1+(y+ty)*4,3,3);
        blockCell(next,0,n,x,y); rect(93+x*4,16+y*4,3,3);
      }
      text(1,3,"SCORE"); text(1,13,String(score)); text(91,3,"NEXT"); text(1,32,"LINES"); text(1,42,String(a)); break;
    case 4:
      for(int i=0;i<3;i++) {
        auto &e=enemies[i]; if(e.x<128 && e.x> -8) { rect(e.x,0,7,e.y-10); rect(e.x,e.y+10,7,49-e.y-10); }
      }
      rect(px-2,py-2,5,4); dot(px+3,py); text(2,1,String(score)); break;
    case 5:
      for(int y=0;y<49;y+=5) line(64,y,64,y+2);
      rect(3,px-7,3,14); rect(122,py-7,3,14); rect(aux-1,aux2-1,3,3);
      text(43,2,String(a)); text(79,2,String(b)); break;
    case 6: case 7:
      for(int x=8;x<128;x+=12) for(int y=6;y<49;y+=10) dot(x,y);
      for(auto &e:enemies) if(e.live) {
        if(id==6) rect(e.x-2,e.y-2,5,5,false);
        else { line(e.x,e.y-3,e.x+3,e.y); line(e.x+3,e.y,e.x,e.y+3); line(e.x,e.y+3,e.x-3,e.y); line(e.x-3,e.y,e.x,e.y-3); }
      }
      for(auto &s:shots) if(s.live) rect(s.x,s.y,2,2);
      if(!hurt || frame%4<2) d.drawTriangle(px,py-3+Y,px-3,py+3+Y,px+3,py+3+Y,SSD1306_WHITE);
      if(b) d.drawCircle(px,py+Y,b*5,SSD1306_WHITE);
      text(2,0,String(score)); text(93,0,String("L")+health); if(id==7) text(2,40,String("B")+a); break;
    case 8:
      for(int y=0;y<49;y++) {
        int mid=64+18*sinf((aux+y*3)*0.01f); dot(mid-28,y); dot(mid+28,y);
        if(((int)aux+y)%12<5) dot(mid,y);
      }
      for(auto &e:enemies) if(e.live) { rect(e.x-3,e.y-5,7,10,false); }
      if(!hurt || frame%4<2) { rect(px-2,py-4,5,9); rect(px-4,py-3,2,3); rect(px+3,py+1,2,3); }
      text(1,0,String(score)); text(108,0,String(health)); break;
    case 9:
      rect(15,0,98,50,false);
      for(int i=0;i<length;i++) rect(16+sx[i]*4,1+sy[i]*4,3,3,i!=0);
      d.drawCircle(17+a*4,2+b*4+Y,1,SSD1306_WHITE); text(0,1,String(score)); break;
    case 10:
      for(int y=0;y<8;y++) for(int x=0;x<21;x++) if(cells[y][x]) rect(x*6,y*6,5,5,cells[y][x]>1);
      for(auto &e:enemies) if(e.live) { rect(e.x-3,e.y-3,6,6,false); line(e.x,e.y,e.x+DX[e.type]*5,e.y+DY[e.type]*5); }
      if(!hurt || frame%4<2) { rect(px-3,py-3,6,6); line(px,py,px+DX[dir]*5,py+DY[dir]*5); }
      for(auto &s:shots) if(s.live) rect(s.x,s.y,2,2);
      text(1,0,String(score)); break;
  }
  d.drawRect(0,12,128,52,SSD1306_WHITE);
  if(over) {
    d.fillRoundRect(13,22,102,36,4,SSD1306_BLACK); d.drawRoundRect(13,22,102,36,4,SSD1306_WHITE);
    d.setCursor(27,26); d.print(won?"YOU WIN!":"GAME OVER");
    d.setCursor(24,37); if(id==5) { d.print("P1 ");d.print(a);d.print(" : ");d.print(b);d.print(" P2"); }
    else { d.print("Score: ");d.print(score); }
    d.setCursor(24,48); d.print("R: play again");
  }
}
