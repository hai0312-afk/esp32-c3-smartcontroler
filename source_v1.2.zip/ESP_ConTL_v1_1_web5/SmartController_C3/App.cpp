#include "App.h"
#include <Wire.h>
#include <Adafruit_SSD1306.h>
#include <esp_mac.h>
#include <esp_system.h>
#include "ChargeIndicator.h"
#include "UiMotion.h"
#include "UiWidgets.h"
#include "OledPump.h"
#include "Input.h"
#include "ControllerLink.h"
#include "BleOutput.h"
#include "Games.h"
#include "WebGames.h"
#include "WebSetup.h"
#if !CONFIG_IDF_TARGET_ESP32C3
#error "SmartController_C3 requires an ESP32-C3 board"
#endif
static Adafruit_SSD1306 display(128,64,&Wire,-1);
static OledPump oled(Wire);
static ui::Slide slide;
static bool effects=true;
static uint32_t lastRender=0,pageStableAt=0,bootAt=0,toastAt=0,bleStartAt=0,webStartAt=0;
static uint32_t statsAt=0,statsFrames=0;
static uint16_t oledFps=0;
static float homeDotX=41,confirmFocusX=20;
static uint8_t navHeld=0;
static uint32_t navHeldAt=0,navRepeatAt=0;
static bool bootLogPrinted=false;
static Input input;
static ControllerLink radio;
static Games games;
enum Page { BOOT, HOME, DEVICES, REMOTE, BLE_START, BLE_PAGE, WEB_START, WEB_PAGE, GAME_MENU, GAME_RUN, SETTINGS, MAPPING, AXES, TEST_INPUT, CALIBRATE, INFO, CONFIRM };
static Page page=BOOT;
static int homeIndex=0,selection=0,mapIndex=0,axisIndex=0,gameIndex=0,settingIndex=0,infoIndex=0;
static bool usbMode=false,armed=false,mapEdit=false,confirmYes=false;
static int confirmAction=0;
static uint8_t mapOriginal=0;
static uint32_t lastFrame=0,comboAt=0,toastUntil=0;
static bool comboHolding=false,comboLatch=false;
static char toast[24]="",macText[18]="";
static bool bleOK=true,webOK=false;
static const char *const HOME_NAMES[]={"ESP Remote","USB via S3","Bluetooth","Mini Games","Web Games","Settings"};
static const char *const HOME_SUB[]={"Wi-Fi + ESP-NOW","Wireless USB HID","BLE keys + mouse","11 OLED games","Color games / Wi-Fi","Personalize"};
static const char *const SET_NAMES[]={"Key mapping","OLED invert","Input test","Calibrate J1/J2","Axis invert","Deadzone","J2 mode","Mouse speed","System info","UI motion","Reset settings","Restart","Back"};
static const char *const AXIS_NAMES[]={"J1 X","J1 Y","J2 X","J2 Y","Back"};
static void notify(const char *s) { strlcpy(toast,s,sizeof(toast)); toastAt=millis(); toastUntil=toastAt+1800; }
static String shortName(const char *s,int count=18) { String t(s); return t.length()>(unsigned)count?t.substring(0,count-1)+"~":t; }
static void printAt(int x,int y,const String &s) { display.setCursor(x,y); display.print(s); }
static void center(int y,const String &s) { printAt(max(0,(128-(int)s.length()*6)/2),y,s); }
static bool choose() { return input.hit(ctl::B_J1|ctl::B_J2); }
static void nav(int &index,int n) {
  uint32_t now=millis();
  uint8_t held=input.buttons&(ctl::B_L|ctl::B_R);
  if(held!=ctl::B_L && held!=ctl::B_R) { navHeld=0; return; }
  bool edge=input.hit(held);
  if(navHeld!=held) { navHeld=held; navHeldAt=navRepeatAt=now; }
  bool repeat=now-navHeldAt>=450 && now-navRepeatAt>=160;
  if(edge || repeat) { index=(index+n+(held==ctl::B_L?-1:1))%n; navRepeatAt=now; }
}
static void saveEffects() {
  Preferences p; p.begin("contl",false); p.putBool("ui_fx",effects); p.end();
}
static void header() {
  display.setTextColor(SSD1306_WHITE); display.setTextSize(1); display.setTextWrap(false);
  printAt(2,1,"ESP ConTL v1.1");
  bool ch=digitalRead(PIN_CHRG)==LOW,st=digitalRead(PIN_STDBY)==LOW;
  if(chargeIconVisible(ch,st,millis())) {
    display.drawRoundRect(107,1,17,8,2,SSD1306_WHITE); display.fillRect(124,3,2,4,SSD1306_WHITE);
    char mark=ch?(st?'!':'C'):(st?'F':'-');
    printAt(112,1,String(mark));
  }
  display.drawFastHLine(0,11,128,SSD1306_WHITE);
}
static void icon(int type,int x,int y) { ui::icon(display,type,x,y,millis(),effects); }
static void card(const String &title,const String &sub,int index,int total,int symbol) {
  uint32_t age=millis()-pageStableAt;
  int titleShift=effects?ui::marquee(title.length()*6,79,age):0;
  int subShift=effects?ui::marquee(sub.length()*6,79,age+150):0;
  ui::clippedText(display,44,21,79,title,titleShift);
  ui::clippedText(display,44,36,79,sub,subShift);
  display.drawRoundRect(2,15,124,38,6,SSD1306_WHITE);
  display.drawFastVLine(38,22,23,SSD1306_WHITE);
  if(page==GAME_MENU && gameIndex<Games::COUNT) ui::gameIcon(display,gameIndex,8,23,millis(),effects);
  else icon(symbol,8,23);
  int nudge=effects && (millis()/600)%2?1:0;
  display.drawLine(16+nudge,56,13+nudge,59,SSD1306_WHITE);
  display.drawLine(13+nudge,59,16+nudge,62,SSD1306_WHITE);
  display.drawLine(111-nudge,56,114-nudge,59,SSD1306_WHITE);
  display.drawLine(114-nudge,59,111-nudge,62,SSD1306_WHITE);
  printAt(3,56,"L"); printAt(120,56,"R");
  if(page==HOME) {
    float target=41+homeIndex*9;
    homeDotX=effects?homeDotX+(target-homeDotX)*0.42f:target;
    for(int i=0;i<6;i++) display.drawCircle(41+i*9,59,1,SSD1306_WHITE);
    display.fillRoundRect((int)roundf(homeDotX)-3,57,7,5,2,SSD1306_WHITE);
  } else center(56,String(index+1)+" / "+total);
}
static void neutral() {
  if(page==REMOTE) radio.sendControl(input,true);
  if(page==BLE_PAGE) BleOutput::release();
  if(page==WEB_PAGE) WebGames::input(input,true,comboHolding?millis()-comboAt:0);
}
static void home() {
  if(mapEdit) { cfg.mapping[mapIndex]=mapOriginal; mapEdit=false; }
  neutral(); radio.stop(); BleOutput::stop(); WebSetup::stop();
  page=HOME; armed=false; selection=0;
}
static void enterHome() {
  armed=false; selection=0;
  switch(homeIndex) {
    case 0: case 1:
      usbMode=homeIndex==1; BleOutput::stop(); radio.begin(usbMode); page=DEVICES; break;
    case 2:
      radio.stop(); // stop Wi-Fi before allocating Bluetooth resources
      bleStartAt=millis(); bleOK=false; page=BLE_START; break;
    case 3: page=GAME_MENU; break;
    case 4:
      radio.stop(); BleOutput::stop(); WebSetup::begin(); page=WEB_PAGE; break;
    case 5: page=SETTINGS; break;
  }
}
static void handleSettings() {
  nav(settingIndex,13);
  if(!choose()) return;
  switch(settingIndex) {
    case 0: mapIndex=0; mapEdit=false; page=MAPPING; break;
    case 1: cfg.invert=!cfg.invert; saveSettings(); oled.setInvert(cfg.invert); break;
    case 2: page=TEST_INPUT; break;
    case 3: page=CALIBRATE; break;
    case 4: axisIndex=0; page=AXES; break;
    case 5: cfg.deadzone=cfg.deadzone>=400?50:cfg.deadzone+50; saveSettings(); break;
    case 6: cfg.joy2Mouse=!cfg.joy2Mouse; saveSettings(); break;
    case 7: cfg.mouseSpeed=cfg.mouseSpeed>=16?1:cfg.mouseSpeed+1; saveSettings(); break;
    case 8: infoIndex=0; page=INFO; break;
    case 9: effects=!effects; saveEffects(); slide.cancel(); notify(effects?"Motion enabled":"Motion disabled"); break;
    case 10: case 11: confirmAction=settingIndex; confirmYes=false; confirmFocusX=20; page=CONFIRM; break;
    case 12: page=HOME; break;
  }
}
static void handlePage() {
  switch(page) {
    case BOOT:
      if(millis()-bootAt>=1000 || choose()) page=HOME;
      break;
    case HOME: nav(homeIndex,6); if(choose()) enterHome(); break;
    case DEVICES: {
      if(radio.state==ControllerLink::READY) { page=REMOTE; armed=false; break; }
      if(radio.state==ControllerLink::LIST) {
        nav(selection,radio.count+2);
        if(choose()) {
          if(selection<radio.count) radio.connectTo(selection);
          else if(selection==radio.count) { selection=0; radio.scan(); }
          else home();
        }
      } else if(radio.state==ControllerLink::ERROR_STATE && choose()) { selection=0; radio.scan(); }
      break;
    }
    case REMOTE:
      if(radio.state!=ControllerLink::READY) { armed=false; page=DEVICES; break; }
      if(radio.rearmRequired){
        armed=false;bool centered=true;for(int i=0;i<4;i++)if(abs(input.axis[i])>250)centered=false;
        if(centered&&choose()&&(input.buttons==ctl::B_J1||input.buttons==ctl::B_J2))radio.acknowledgeRearm();
      }else if(!armed && !input.buttons)armed=true;
      radio.sendControl(input,!armed); break;
    case BLE_START:
      // Paint the starting screen first. NimBLE init itself remains synchronous.
      if(millis()-bleStartAt>=180 && !oled.busy()) {
        bleOK=BleOutput::begin(); page=BLE_PAGE;
      }
      break;
    case BLE_PAGE:
      if(!armed && !input.buttons) armed=true;
      if(bleOK) BleOutput::send(armed?mappedHid(input):ctl::HidReport{}); break;
    case WEB_START: break; // reserved old page id
    case WEB_PAGE:
      WebSetup::tick(input,!oled.busy()); break;
    case GAME_MENU:
      nav(gameIndex,Games::COUNT+1);
      if(choose()) {
        if(gameIndex==Games::COUNT) page=HOME;
        else { games.start(gameIndex); page=GAME_RUN; armed=false; }
      }
      break;
    case GAME_RUN:
      if(!armed) { if(!input.buttons) armed=true; }
      else games.tick(input);
      break;
    case SETTINGS: handleSettings(); break;
    case MAPPING:
      if(mapEdit) {
        int m=cfg.mapping[mapIndex]; nav(m,ACTION_COUNT); cfg.mapping[mapIndex]=m;
        if(input.hit(ctl::B_J1)) { saveSettings(); mapEdit=false; notify("Mapping saved"); }
        else if(input.hit(ctl::B_J2)) { cfg.mapping[mapIndex]=mapOriginal; mapEdit=false; }
      } else {
        nav(mapIndex,13);
        if(choose()) {
          if(mapIndex==12) page=SETTINGS;
          else { mapOriginal=cfg.mapping[mapIndex]; mapEdit=true; }
        }
      }
      break;
    case AXES:
      nav(axisIndex,5);
      if(choose()) { if(axisIndex==4) page=SETTINGS; else { cfg.flip[axisIndex]=!cfg.flip[axisIndex]; saveSettings(); } }
      break;
    case TEST_INPUT: break; // All buttons are under test. Exit ONLY with the 4-button chord.
    case CALIBRATE:
      if(input.hit(ctl::B_J2)) page=SETTINGS;
      else if(input.hit(ctl::B_J1)) { bool ok=input.calibrate(); notify(ok?"Centers saved":"Center out of range"); page=SETTINGS; }
      break;
    case INFO: nav(infoIndex,5); if(choose()) page=SETTINGS; break;
    case CONFIRM:
      if(input.hit(ctl::B_L|ctl::B_R)) confirmYes=!confirmYes;
      if(choose()) {
        if(confirmYes) {
          if(confirmAction==11) { neutral(); ESP.restart(); }
          else { resetSettings(); effects=true; saveEffects(); oled.setInvert(cfg.invert); notify("Defaults restored"); }
        }
        page=SETTINGS;
      }
      break;
  }
}
static void drawInput() {
  display.drawRoundRect(1,14,126,49,4,SSD1306_WHITE);
  for(int j=0;j<2;j++) {
    int x=j?101:27,y=34;
    display.drawCircle(x,y,13,SSD1306_WHITE);
    int xx=x+input.axis[j*2]*10/1000,yy=y+input.axis[j*2+1]*10/1000;
    if(input.down(j?ctl::B_J2:ctl::B_J1)) display.fillCircle(xx,yy,3,SSD1306_WHITE);
    else display.drawCircle(xx,yy,3,SSD1306_WHITE);
    printAt(x-6,16,j?"J2":"J1");
  }
  for(int i=0;i<2;i++) {
    int y=21+i*15;
    if(input.down(1<<i)) { display.fillRoundRect(54,y,20,12,3,SSD1306_WHITE); display.setTextColor(SSD1306_BLACK); }
    else display.drawRoundRect(54,y,20,12,3,SSD1306_WHITE);
    printAt(61,y+2,i?"R":"L"); display.setTextColor(SSD1306_WHITE);
  }
  center(53,"Hold 4 keys: exit");
}
static String settingValue() {
  switch(settingIndex) {
    case 0:return "12 controls"; case 1:return cfg.invert?"Inverted":"Normal";
    case 2:return "Sticks + buttons"; case 3:return "Release sticks";
    case 4:return "Flip each axis"; case 5:return String(cfg.deadzone/10)+" percent";
    case 6:return cfg.joy2Mouse?"Mouse pointer":"Mapped keys";
    case 7:return String(cfg.mouseSpeed)+" px/tick";
    case 8:return "HDZ463"; case 9:return effects?"Animated":"Minimal"; case 10:return "Confirm first"; case 11:return "Reboot chip"; default:return "Home menu";
  }
}
static void drawPage() {
  display.clearDisplay(); header();
  switch(page) {
    case BOOT: {
      uint32_t elapsed=millis()-bootAt;
      int rise=effects?6-6*ui::easeOut(elapsed,400)/1024:0;
      display.drawRoundRect(3,15,122,48,6,SSD1306_WHITE);
      icon(3,12,22+rise); printAt(48,25+rise,"ESP ConTL"); printAt(48,37+rise,"HDZ463");
      display.drawRoundRect(12,54,104,4,1,SSD1306_WHITE);
      display.fillRect(14,55,min((uint32_t)100,elapsed/10),2,SSD1306_WHITE); break;
    }
    case HOME: card(HOME_NAMES[homeIndex],HOME_SUB[homeIndex],homeIndex,6,homeIndex==4?5:homeIndex==5?4:homeIndex); break;
    case DEVICES:
      if(radio.state==ControllerLink::LIST) {
        if(selection<radio.count) {
          auto &dev=radio.devices[selection];
          card(shortName(dev.ssid+5,14),String(dev.rssi)+"dBm ch"+dev.channel,selection,radio.count+2,usbMode?1:0);
        } else card(selection==radio.count?"Scan again":"Back",radio.count?String("J1/J2: select"):String("AP ")+radio.apsSeen+" / espH 0",selection,radio.count+2,0);
      } else {
        display.drawRoundRect(2,15,124,48,6,SSD1306_WHITE);
        if(radio.state==ControllerLink::ERROR_STATE) {
          center(20,"LINK NOT READY"); center(34,shortName(radio.message,19)); center(52,"J1/J2: rescan");
        } else {
          int step=radio.state==ControllerLink::SCANNING?0:radio.state==ControllerLink::CONNECTING?1:2;
          const char *labels[]={"SCAN","JOIN","LINK"};
          for(int i=0;i<3;i++) {
            int x=8+i*40;
            if(i==step) { display.fillRoundRect(x-2,20,30,11,3,SSD1306_WHITE); display.setTextColor(SSD1306_BLACK); }
            printAt(x+1,22,labels[i]); display.setTextColor(SSD1306_WHITE);
          }
          center(37,shortName(radio.message,19));
          if(effects) ui::loading(display,11,51,106,millis());
          else { display.drawRect(11,52,106,4,SSD1306_WHITE); display.fillRect(13+step*34,53,32,2,SSD1306_WHITE); }
        }
      }
      break;
    case REMOTE: {
      display.drawRoundRect(1,14,126,49,4,SSD1306_WHITE);
      printAt(5,18,shortName(radio.peerName+5,19));
      printAt(5,29,usbMode?"USB HID":"ESP-NOW");
      printAt(69,29,radio.rttMs<0?"RTT --":String(radio.rttMs,1)+"ms");
      if(usbMode) {
        uint8_t f=radio.peerFlags;
        String status=!(f&ctl::PONG_USB_STATUS)?"USB: status pending":
          !(f&ctl::PONG_USB_MOUNTED)?"USB: WAIT PC":
          (f&ctl::PONG_USB_SUSPENDED)?"USB: SUSPENDED":
          !(f&ctl::PONG_USB_CONTROL)?"USB: NO CONTROL":
          ((f&ctl::PONG_USB_KEY_TX)&&(f&ctl::PONG_USB_MOUSE_TX))?"USB: HID OK":"USB: HID RETRY";
        printAt(5,40,status);
        if(!armed) printAt(5,51,radio.rearmRequired?"Center + J1/J2: arm":"Release all keys");
        else printAt(5,51,String("RX:")+!!(f&ctl::PONG_USB_CONTROL)+" K:"+!!(f&ctl::PONG_USB_KEY_TX)+" M:"+!!(f&ctl::PONG_USB_MOUSE_TX));
      } else {
        printAt(5,40,String("J1 ")+input.axis[0]+","+input.axis[1]);
        if(!armed)printAt(5,51,radio.rearmRequired?"Center + J1/J2: arm":"Release all keys");
        else printAt(5,51,String("Loss ")+radio.lostPings+"/"+radio.pings+" R:"+radio.rssi);
      }
      break;
    }
    case BLE_START:
      display.drawRoundRect(2,15,124,39,6,SSD1306_WHITE); icon(2,8,23);
      printAt(41,23,"Starting BLE"); printAt(41,37,"NimBLE HID");
      if(effects) ui::loading(display,12,56,104,millis()); break;
    case BLE_PAGE:
      display.drawRoundRect(2,15,124,39,6,SSD1306_WHITE); icon(2,8,23);
      printAt(41,22,BleOutput::status()); printAt(41,36,"Keys + mouse");
      if(!BleOutput::connected() && effects) ui::spinner(display,118,47,millis());
      center(56,"Hold 4 keys: exit"); break;
    case WEB_START: break;
    case WEB_PAGE: WebSetup::draw(display); break;
    case GAME_MENU:
      card(gameIndex==Games::COUNT?"Back":Games::names[gameIndex],gameIndex==Games::COUNT?"Home menu":Games::hints[gameIndex],gameIndex,Games::COUNT+1,3); break;
    case GAME_RUN:
      games.draw(display);
      // Sprites near the top may extend out of the playfield: keep the OS bar intact.
      display.fillRect(0,0,128,12,SSD1306_BLACK); header(); break;
    case SETTINGS: card(SET_NAMES[settingIndex],settingValue(),settingIndex,13,4); break;
    case MAPPING:
      display.drawRoundRect(1,14,126,49,4,SSD1306_WHITE);
      center(18,mapIndex==12?"Back":CONTROL_NAMES[mapIndex]);
      if(mapIndex<12) {
        if(mapEdit) { display.fillRect(13,30,102,12,SSD1306_WHITE); display.setTextColor(SSD1306_BLACK); }
        center(32,ACTIONS[cfg.mapping[mapIndex]].name); display.setTextColor(SSD1306_WHITE);
      }
      center(45,mapEdit?"L/R: change key":"L/R: input  J: edit");
      center(55,mapEdit?"J1 save J2 cancel":String(mapIndex+1)+"/13"); break;
    case AXES: card(AXIS_NAMES[axisIndex],axisIndex==4?"Settings":(cfg.flip[axisIndex]?"Inverted":"Normal"),axisIndex,5,4); break;
    case TEST_INPUT: drawInput(); break;
    case CALIBRATE:
      display.drawRoundRect(1,14,126,49,4,SSD1306_WHITE);
      center(18,"CENTER CALIBRATION"); center(29,"Release BOTH sticks"); center(42,"J1: sample + save"); center(53,"J2: cancel"); break;
    case INFO:
      display.drawRoundRect(1,14,126,49,4,SSD1306_WHITE);
      if(infoIndex==0) { center(18,"ESP ConTL v1.1"); center(30,"Created by HDZ463"); center(42,"Build: v1.1-web5"); }
      if(infoIndex==1) { center(18,ESP.getChipModel()+String(" rev ")+ESP.getChipRevision()); center(30,String(ESP.getCpuFreqMHz())+" MHz"); center(42,String("Heap ")+ESP.getFreeHeap()/1024+" KB"); }
      if(infoIndex==2) { center(18,"C3 STA MAC (RAM)"); center(30,macText); center(42,String("Flash ")+ESP.getFlashChipSize()/1048576+" MB"); }
      if(infoIndex==3) {
        bool ch=digitalRead(PIN_CHRG)==LOW,st=digitalRead(PIN_STDBY)==LOW;
        center(18,"POWER STATUS"); center(30,ch?(st?"Invalid CHRG/STDBY":"Charging (C)"):(st?"Charge done (F)":"No charge signal"));
        center(42,"Battery %: unknown");
      }
      if(infoIndex==4) {
        center(18,"OLED / UI STATUS"); center(30,String("OLED ")+oledFps+" frames/s");
        center(42,String("E:")+oled.errors+" R:"+oled.recoveries+" "+(oled.clockHz()/1000)+"k");
      }
      center(54,"L/R page J: back"); break;
    case CONFIRM:
      display.drawRoundRect(1,14,126,49,4,SSD1306_WHITE);
      center(21,confirmAction==11?"RESTART DEVICE?":"RESET SETTINGS?");
      {
        float target=confirmYes?75:20;
        confirmFocusX=effects?confirmFocusX+(target-confirmFocusX)*0.4f:target;
        display.drawRoundRect((int)roundf(confirmFocusX),33,34,15,4,SSD1306_WHITE);
        printAt(31,37,"NO"); printAt(84,37,"YES");
      }
      center(53,"L/R choose J: OK"); break;
  }
  // Toast and pause overlay are composed after the slide, so they stay pinned.
}
static uint32_t screenKey() {
  uint32_t key=(uint32_t)page<<16;
  switch(page) {
    case HOME:return key+homeIndex;
    case DEVICES:return key+radio.state*32+selection;
    case GAME_MENU:return key+gameIndex;
    case SETTINGS:return key+settingIndex;
    case MAPPING:return key+mapIndex*2+mapEdit;
    case AXES:return key+axisIndex;
    case INFO:return key+infoIndex;
    default:return key;
  }
}
static bool livePage(Page p) { return p==REMOTE || p==BLE_PAGE || p==WEB_PAGE || p==GAME_RUN || p==TEST_INPUT; }
static void overlays() {
  uint32_t now=millis();
  if(comboHolding) {
    uint32_t elapsed=min((uint32_t)3000,now-comboAt);
    display.fillRoundRect(5,18,118,43,6,SSD1306_BLACK);
    display.drawRoundRect(5,18,118,43,6,SSD1306_WHITE);
    ui::ring(display,26,39,14,elapsed*1024U/3000U);
    printAt(24,36,String(max(1,3-(int)(elapsed/1000))));
    printAt(48,25,"PAUSED"); printAt(48,37,"Hold: exit"); printAt(48,49,"Let go: run");
  } else if(comboLatch) {
    display.fillRoundRect(5,25,118,29,5,SSD1306_BLACK);
    display.drawRoundRect(5,25,118,29,5,SSD1306_WHITE);
    center(30,"Release all keys"); center(43,page==HOME?"Back to home":"Resume on release");
  } else if((int32_t)(toastUntil-now)>0) {
    int y=44;
    if(effects) {
      uint32_t age=now-toastAt,remaining=toastUntil-now;
      if(age<220) y=64-ui::easeOut(age,220)*20/1024;
      else if(remaining<220) y=44+ui::easeOut(220-remaining,220)*20/1024;
    }
    display.fillRoundRect(3,y,122,18,4,SSD1306_BLACK);
    display.drawRoundRect(3,y,122,18,4,SSD1306_WHITE); center(y+5,shortName(toast,19));
  }
}
static void logicTick() {
  uint32_t beforeKey=screenKey(); Page beforePage=page;
  bool all=input.buttons==15;
  if(comboLatch) {
    neutral();
    if(!input.buttons) { comboLatch=false; input.pressed=0; navHeld=0; }
    return;
  }
  if(all) {
    if(!comboHolding) { comboHolding=true; comboAt=millis(); slide.cancel(); }
    neutral();
    if(millis()-comboAt>=3000) { home(); comboHolding=false; comboLatch=true; navHeld=0; pageStableAt=millis(); }
    return;
  }
  if(comboHolding) {
    comboHolding=false; comboLatch=input.buttons!=0; navHeld=0; input.pressed=0;
    if(comboLatch) { neutral(); return; }
  }
  handlePage();
  uint32_t afterKey=screenKey();
  if(afterKey!=beforeKey) {
    pageStableAt=millis();
    if(beforePage!=page) navHeld=0;
    if(effects && !livePage(beforePage) && !livePage(page)) {
      int direction=(input.down(ctl::B_L) || page==HOME || (page==SETTINGS && beforePage!=HOME))?-1:1;
      slide.begin(display.getBuffer(),direction,millis());
    } else slide.cancel();
  }
}
void appSetup() {
  Serial.begin(115200);
  loadSettings(); input.begin();
  { Preferences p; p.begin("contl",true); effects=p.getBool("ui_fx",true); p.end(); }
  uint8_t mac[6]; esp_read_mac(mac,ESP_MAC_WIFI_STA);
  snprintf(macText,sizeof(macText),"%02X:%02X:%02X:%02X:%02X:%02X",mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
  Wire.begin(8,9); Wire.setClock(400000);
  if(!display.begin(SSD1306_SWITCHCAPVCC,0x3C)) {
    Serial.println("OLED missing (0x3C SDA8 SCL9)"); while(true) delay(1000);
  }
  display.setRotation(2); oled.setInvert(cfg.invert); display.clearDisplay();
  display.setTextSize(1); display.setTextColor(SSD1306_WHITE); display.setTextWrap(false);
  oled.begin(0x3C);
  randomSeed(esp_random());
  bootAt=pageStableAt=lastFrame=statsAt=millis();
}
static void recoverOledBus(){
  Wire.end();
  // Open-drain bus clear; never drive SDA/SCL high against a stuck peripheral.
  pinMode(8,OUTPUT_OPEN_DRAIN);pinMode(9,OUTPUT_OPEN_DRAIN);
  digitalWrite(8,HIGH);digitalWrite(9,HIGH);delayMicroseconds(5);
  for(int i=0;i<9;i++){digitalWrite(9,LOW);delayMicroseconds(5);digitalWrite(9,HIGH);delayMicroseconds(5);}
  digitalWrite(9,LOW);digitalWrite(8,LOW);delayMicroseconds(5);
  digitalWrite(9,HIGH);delayMicroseconds(5);digitalWrite(8,HIGH);delayMicroseconds(5);
  bool ok=Wire.begin(8,9);Wire.setClock(100000);Wire.setTimeOut(8);
  Serial.printf("[OLED] bus recovery=%lu errors=%lu clock=100k begin=%u SDA=%d SCL=%d\n",(unsigned long)oled.recoveries,(unsigned long)oled.errors,ok,digitalRead(8),digitalRead(9));
}
void appLoop() {
  static uint32_t previousLoop=0,maxLoopGap=0,lastSystemLog=0;
  uint32_t loopNow=millis();
  if(previousLoop&&loopNow-previousLoop>maxLoopGap)maxLoopGap=loopNow-previousLoop;
  previousLoop=loopNow;
  if(Serial&&loopNow-lastSystemLog>=10000){
    lastSystemLog=loopNow;
    Serial.printf("[SYS] heap=%lu maxLoopGap=%lu OLED frames=%lu errors=%lu recover=%lu refresh=%lu clock=%luk\n",(unsigned long)ESP.getFreeHeap(),(unsigned long)maxLoopGap,(unsigned long)oled.frames,(unsigned long)oled.errors,(unsigned long)oled.recoveries,(unsigned long)oled.refreshes,(unsigned long)(oled.clockHz()/1000));
    maxLoopGap=0;
  }
  // Service radio/BLE between short I2C bursts, not just once per full OLED frame.
  radio.update(); BleOutput::update(); WebGames::update();
  uint32_t now=millis();
  if(!bootLogPrinted && Serial) {
    bootLogPrinted=true;
    esp_reset_reason_t reason=esp_reset_reason();
    const char *resetName=reason==ESP_RST_POWERON?"POWERON":reason==ESP_RST_SW?"SOFTWARE":
      reason==ESP_RST_PANIC?"PANIC":reason==ESP_RST_INT_WDT?"INT_WDT":
      reason==ESP_RST_TASK_WDT?"TASK_WDT":reason==ESP_RST_WDT?"WDT":
      reason==ESP_RST_BROWNOUT?"BROWNOUT":"OTHER";
    Serial.printf("ESP ConTL v1.1-web5 / HDZ463\n[BOOT] reset=%s (%d) heap=%lu\nSTA MAC %s\n",
      resetName,(int)reason,(unsigned long)ESP.getFreeHeap(),macText);
  }
  if(now-lastFrame>=20) {
    lastFrame=now; input.update(); logicTick(); // no catch-up / no replay after pause
  }
  now=millis();
  if(now-statsAt>=1000) {
    oledFps=(oled.frames-statsFrames)*1000U/(now-statsAt); statsFrames=oled.frames; statsAt=now;
  }
  // Live control needs fewer decorative frames; input/ESP-NOW/HID keep their own cadence.
  uint32_t interval=(page==REMOTE || page==BLE_PAGE || (page==WEB_PAGE && WebSetup::online()))?80:33;
  if(comboHolding || comboLatch || slide.active()) interval=33;
  bool waitForBleInit=!comboHolding && !comboLatch && ((page==BLE_START && now-bleStartAt>=180)||(page==WEB_PAGE && WebSetup::needsDrain()));
  if(!oled.busy() && !waitForBleInit && now-lastRender>=interval) {
    lastRender=now; drawPage(); slide.compose(display.getBuffer(),now); overlays();
    oled.submit(display.getBuffer());
  }
  oled.setInvert(cfg.invert);
  if(oled.takeBusRecovery(millis()))recoverOledBus();
  oled.service(); // at most one command/data transaction, <=32 data bytes
  if(!oled.busy()) delay(1); else yield();
}
