#pragma once
#include <Arduino.h>
#include <Preferences.h>
#include "Protocol.h"
constexpr uint8_t AXIS_PINS[4]={0,1,3,2};
constexpr uint8_t BUTTON_PINS[4]={7,20,10,6}; // L,R,J1,J2
constexpr uint8_t PIN_CHRG=4,PIN_STDBY=5;
struct Settings {
  uint32_t magic=0x1100C071;
  uint16_t center[4]={2048,2048,2048,2048};
  bool flip[4]={true,true,false,false};
  uint16_t deadzone=150; // normalized units, 0..1000; UI steps: 50..400
  bool invert=false;
  bool joy2Mouse=true;
  uint8_t mouseSpeed=8;
  // J1 U,D,L,R; J2 U,D,L,R; L,R,SW1,SW2. Values index ACTIONS[].
  uint8_t mapping[12]={1,3,2,4,5,6,7,8,9,10,11,12};
};
extern Settings cfg;
void loadSettings();
void saveSettings();
void resetSettings();
struct Action { const char *name; uint8_t kind; uint8_t code; }; // kind: 0 none,1 key,2 modifier,3 mouse
extern const Action ACTIONS[];
extern const uint8_t ACTION_COUNT;
extern const char *const CONTROL_NAMES[12];
struct Input {
  uint16_t raw[4]={};
  int16_t axis[4]={};
  uint8_t buttons=0,pressed=0,released=0;
  void begin();
  void update();
  bool calibrate();
  bool hit(uint8_t mask) const { return pressed&mask; }
  bool down(uint8_t mask) const { return buttons&mask; }
 private:
  uint8_t candidate_=0;
  uint32_t changed_[4]={};
  bool first_=true;
};
ctl::HidReport mappedHid(const Input &in);
