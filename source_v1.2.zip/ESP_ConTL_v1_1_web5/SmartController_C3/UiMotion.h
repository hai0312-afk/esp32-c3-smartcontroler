#pragma once
#include <stdint.h>
#include <string.h>

namespace ui {
// Fixed-point cubic ease-out, 0..1024. Wrap-safe elapsed time is supplied by caller.
inline uint16_t easeOut(uint32_t elapsed,uint16_t duration) {
  if(!duration || elapsed>=duration) return 1024;
  uint32_t rest=1024U-elapsed*1024U/duration;
  return 1024U-(rest*rest*rest)/(1024U*1024U);
}
// SSD1306 physical framebuffer. Logical coordinates assume setRotation(2).
inline bool pixel(const uint8_t *p,int x,int y) {
  if(x<0 || x>127 || y<0 || y>63) return false;
  int xx=127-x,yy=63-y;
  return (p[xx+(yy/8)*128]>>(yy&7))&1;
}
inline void setPixel(uint8_t *p,int x,int y,bool value) {
  int xx=127-x,yy=63-y; uint8_t mask=1U<<(yy&7);
  uint8_t &b=p[xx+(yy/8)*128]; b=value?(b|mask):(b&~mask);
}
class Slide {
 public:
  void begin(const uint8_t *visible,int direction,uint32_t now,uint16_t duration=220) {
    memcpy(from_,visible,1024); direction_=direction<0?-1:1;
    since_=now; duration_=duration; active_=true;
  }
  void cancel() { active_=false; }
  bool active() const { return active_; }
  void compose(uint8_t *destination,uint32_t now) {
    if(!active_) return;
    uint32_t elapsed=now-since_;
    if(elapsed>=duration_) { active_=false; return; }
    memcpy(to_,destination,1024);
    int shift=(easeOut(elapsed,duration_)*128U)/1024U;
    // Keep OS/power bar (0..11) and navigation footer (54..63) pinned.
    for(int y=12;y<54;y++) for(int x=0;x<128;x++) {
      int oldX=x+direction_*shift;
      int newX=x-direction_*(128-shift);
      bool v=(oldX>=0 && oldX<128)?pixel(from_,oldX,y):pixel(to_,newX,y);
      setPixel(destination,x,y,v);
    }
  }
 private:
  uint8_t from_[1024]={},to_[1024]={};
  uint32_t since_=0; uint16_t duration_=220;
  int direction_=1; bool active_=false;
};
}
