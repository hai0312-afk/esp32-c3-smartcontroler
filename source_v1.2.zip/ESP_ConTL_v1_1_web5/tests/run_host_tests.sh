#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p .cache/host-tests
g++ -std=c++17 -g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer \
  -Itests/stubs -ISmartController_C3 \
  tests/host_tests.cpp SmartController_C3/Games.cpp SmartController_C3/Input.cpp \
  -o .cache/host-tests/run
ASAN_OPTIONS=detect_leaks=1 .cache/host-tests/run
g++ -std=c++17 -g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer \
  -Itests/stubs -ISmartController_C3 -IUSB_Bridge_S3 \
  tests/fix1_tests.cpp SmartController_C3/Input.cpp -o .cache/host-tests/fix1
ASAN_OPTIONS=detect_leaks=1 .cache/host-tests/fix1
g++ -std=c++17 -g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer \
  -Itests/stubs -ISmartController_C3 tests/ui_tests.cpp SmartController_C3/UiWidgets.cpp \
  -o .cache/host-tests/ui
ASAN_OPTIONS=detect_leaks=1 .cache/host-tests/ui

g++ -std=c++17 -g -O1 -fsanitize=address,undefined -ISmartController_C3 \
  tests/discovery_tests.cpp -o .cache/host-tests/discovery
ASAN_OPTIONS=detect_leaks=1 .cache/host-tests/discovery
g++ -std=c++17 -g -O1 -fsanitize=address,undefined -ISmartController_C3 \
  tests/console_input_tests.cpp -o .cache/host-tests/console-input
ASAN_OPTIONS=detect_leaks=1 .cache/host-tests/console-input
g++ -std=c++17 -g -O1 -fsanitize=address,undefined -ISmartController_C3 \
  tests/link_health_tests.cpp -o .cache/host-tests/link-health
ASAN_OPTIONS=detect_leaks=1 .cache/host-tests/link-health
g++ -std=c++17 -g -O1 -fsanitize=address,undefined -ISmartController_C3 tests/home_join_tests.cpp -o .cache/host-tests/home-join
ASAN_OPTIONS=detect_leaks=1 .cache/host-tests/home-join
