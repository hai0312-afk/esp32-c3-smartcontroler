#include <assert.h>
#include <stdio.h>
#include "Discovery.h"
int main(){
 DiscoveryDevice d[DISCOVERY_CAPACITY];int n=0;uint8_t mac[6]={2,0,0,0,0,1};
 assert(!mergeDiscovery(d,n,"home",mac,-20,6));assert(!mergeDiscovery(d,n,"espH_",mac,-20,6));
 assert(!mergeDiscovery(d,n,"espH_A",nullptr,-20,6));assert(!mergeDiscovery(d,n,"espH_A",mac,-20,0));
 assert(mergeDiscovery(d,n,"espH_A",mac,-90,6)&&n==1);assert(mergeDiscovery(d,n,"espH_A",mac,-45,6)&&n==1);
 mac[5]=2;assert(mergeDiscovery(d,n,"espH_A",mac,-30,11)&&n==2);assert(d[0].channel==11);
 for(int i=3;i<80;i++){mac[5]=i;assert(mergeDiscovery(d,n,"espH_RX",mac,-110+i,6));assert(n<=DISCOVERY_CAPACITY);for(int j=1;j<n;j++)assert(d[j-1].rssi>=d[j].rssi);}
 mac[5]=100;assert(!mergeDiscovery(d,n,"espH_weak",mac,-120,6));
 mac[5]=101;assert(mergeDiscovery(d,n,"espH_strong",mac,-10,6));assert(d[0].rssi==-10);
 puts("PASS discovery: prefix/channel/null validation, BSSID dedup, same-SSID different BSSIDs, RSSI ordering, capacity and weakest replacement");
}
