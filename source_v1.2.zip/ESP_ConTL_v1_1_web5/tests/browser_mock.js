// Test-only WS transport. Not included in served firmware assets.

window.mock={a:[0,0,0,0],b:0,d:-1,p:false,h:0,approved:false,stream:true,sockets:[]};
class MockSocket {
 static CONNECTING=0;static OPEN=1;static CLOSING=2;static CLOSED=3;
 constructor(url){this.url=url;this.readyState=0;mock.sockets.push(this);setTimeout(()=>{if(this.readyState===3)return;this.readyState=1;this.onopen?.();this.deliver(url.endsWith('/pair')?{t:'pair',allowed:mock.approved}:{t:'auth',ok:true});},35);}
 deliver(m){if(this.readyState===1)this.onmessage?.({data:typeof m==='string'?m:JSON.stringify(m)});}
 close(){if(this.readyState===3)return;this.readyState=3;setTimeout(()=>this.onclose?.(),0);}
 send(m){if(m.startsWith('P:'))setTimeout(()=>this.deliver(m),4);}
}
window.WebSocket=MockSocket;
window.mockApprove=()=>{mock.approved=true;mock.sockets.forEach(s=>{if(s.url.endsWith('/pair'))s.deliver({t:'pair',allowed:true});});};
setInterval(()=>{if(!mock.stream)return;mock.sockets.forEach(s=>{if(s.url.endsWith('/pair')){if(mock.approved)s.deliver({t:'nav',d:mock.d,b:mock.b,p:mock.p});}else s.deliver({t:'input',a:mock.a,b:mock.b,p:mock.p,h:mock.h,s:1});});},25);
