'use strict';
const assert=require('node:assert/strict');require('../web/games.js');
const {Game,DEFS}=ContlGame;const input=(p=0,a=[0,0,0,0])=>({p,b:p,a});
assert.equal(DEFS.length,26);assert.equal(DEFS.filter(d=>d.webOnly).length,15);assert.equal(DEFS.slice(21).filter(d=>d.players===2).length,5);
let g=new Game(11);g.extra.stage=3;g.extra.attached=false;g.extra.items=[{x:100,y:100,on:true,hp:1}];g.extra.ball={x:110,y:99,vx:0,vy:100};g.step(1/60,input());assert(g.won);
g=new Game(12);g.extra.caught=19;g.extra.angle=0;g.extra.items=[{a:0,r:150.1,dead:false}];g.step(1/60,input());assert(g.won);
g=new Game(13);g.extra.goals=2;g.extra.y=0;g.step(1/60,input());assert(g.won);
g=new Game(14);g.extra.caught=19;g.extra.color=1;g.extra.items=[{x:400,y:379,color:1,dead:false}];g.step(1/60,input());assert(g.won);
g=new Game(15);Object.assign(g.extra,{x:500,pad:500,y:385,vx:0,vy:5});g.step(1/60,input());assert(g.won);
g=new Game(15);Object.assign(g.extra,{x:500,pad:500,y:385,vx:0,vy:100});g.step(1/60,input());assert.equal(g.lives,2);assert(!g.over);
for(let seed=1;seed<31;seed++){g=new Game(16,seed);g.step(1/60,input(2));assert.equal(g.extra.cells.filter(v=>v.mine).length,12);assert(!g.extra.cells[0].mine);assert(g.extra.cells[0].open);assert.equal(g.lives,3);}
g=new Game(16);g.extra.placed=true;g.extra.cells.forEach((c,n)=>{c.mine=n>=68;c.open=n<67;c.n=1;});g.extra.cx=7;g.extra.cy=6;g.step(1/60,input(2));assert(g.won);
g=new Game(17);for(let value=0;value<8;value++)for(let n=0;n<16;n++)if(g.extra.cards[n].value===value){g.extra.cx=n%4;g.extra.cy=Math.floor(n/4);g.step(1/60,input(2));}assert(g.won&&g.score===800);
// Solve the actual warehouse with legal walking and pushes, not by placing crates on goals.
g=new Game(18);let e=g.extra,dirs=[[1,0],[0,1],[-1,0],[0,-1]],goals=e.targets.map(p=>p.y*9+p.x).sort((a,b)=>a-b).join(',');
let queue=[{x:e.x,y:e.y,boxes:e.crates.map(p=>p.y*9+p.x),path:[]}],seen=new Set(),solution=null;
for(let at=0;at<queue.length&&at<150000;at++){
 const s=queue[at],occupied=new Set(s.boxes),reach=new Map([[s.y*9+s.x,[]]]),walk=[s.y*9+s.x];
 for(let j=0;j<walk.length;j++){let v=walk[j],x=v%9,y=Math.floor(v/9);dirs.forEach(([dx,dy],d)=>{let xx=x+dx,yy=y+dy,n=yy*9+xx;if(!e.wall(xx,yy)&&!occupied.has(n)&&!reach.has(n)){reach.set(n,reach.get(v).concat(d));walk.push(n);}});}
 const canonical=s.boxes.slice().sort((a,b)=>a-b).join(',');if(canonical===goals){solution=s.path;break;}
 let key=canonical+'|'+Math.min(...walk);if(seen.has(key))continue;seen.add(key);
 s.boxes.forEach((v,box)=>{let x=v%9,y=Math.floor(v/9);dirs.forEach(([dx,dy],d)=>{let behind=(y-dy)*9+x-dx,n=(y+dy)*9+x+dx;if(reach.has(behind)&&!e.wall(x+dx,y+dy)&&!occupied.has(n)){let boxes=s.boxes.slice();boxes[box]=n;queue.push({x,y,boxes,path:s.path.concat(reach.get(behind),d)});}});});
}
assert(solution,'warehouse must have a legal solution');
for(const d of solution){e.lastDir=-1;g.step(1/60,input(0,[...dirs[d],0,0]));}assert(g.won);console.log('PASS Warehouse legal solution:',solution.length,'moves');
g=new Game(18);g.step(1/60,input(0,[1,0,0,0]));assert.equal(g.extra.x,5);g.step(1/60,input(1));assert.equal(g.extra.x,4);
g=new Game(19);e=g.extra;e.grid=Array.from({length:7},()=>Array(12).fill(0));e.grid[0][5]=e.grid[0][6]=1;e.bubble={x:342,y:48,vx:0,vy:-20,color:1};g.step(1/60,input());assert(g.won&&g.score===30);
g=new Game(20);g.extra.delivered=7;g.extra.truck=400;g.extra.parcels=[{x:400,y:389,vy:150,dead:false}];g.step(1/60,input());assert(g.won);
console.log('PASS 10 new solo games: win conditions, landing crash, first-click mine safety, undo, bubble cluster');
for(const id of [21,22,23,25]){g=new Game(id);const x=g.extra.players[0].x,y=g.extra.players[1].y;g.step(1/60,input(0,[1,0,0,-1]));assert(g.extra.players[0].x>x&&g.extra.players[1].y<y,'independent axes '+id);}
g=new Game(22);g.step(1/60,input(8));assert.equal(g.extra.bullets.length,1);assert.equal(g.extra.bullets[0].owner,1);g.step(1/60,input(4));assert.equal(g.extra.bullets[1].owner,0);
g=new Game(22);g.step(1/60,input(1));assert(g.extra.players[0].shield>0&&g.extra.players[1].shield===0);g.step(1/60,input(2));assert(g.extra.players[1].shield>0);
g=new Game(21);g.extra.players[0].score=4;g.extra.ball={x:799,y:225,vx:100,vy:0};g.step(1/60,input());assert(g.won&&g.result.includes('PLAYER 1'));
g=new Game(22);g.extra.players[1].hp=1;g.extra.bullets=[{x:620,y:225,vx:0,vy:0,owner:0,life:1}];g.step(1/60,input());assert(g.won&&g.result.includes('PLAYER 1'));
g=new Game(23);g.extra.players[0].score=19;g.extra.items=[{x:180,y:225}];g.step(1/60,input());assert(g.won);
g=new Game(24);for(let n=0;n<6;n++)g.step(1/60,{a:[0,0,0,0],b:4,p:n===0?4:0});assert.equal(g.extra.riders[0].x,7);assert.equal(g.extra.riders[1].x,29,'SW1 must not accelerate P2');
g=new Game(24);g.extra.players[0].score=2;Object.assign(g.extra.riders[1],{x:0,y:0,dir:2,want:2});for(let n=0;n<9;n++)g.step(1/60,input());assert(g.won&&g.result.includes('PLAYER 1'));
g=new Game(25);g.extra.hazards=[];for(let n=0;n<2;n++)for(let j=0;j<3;j++){const a=g.extra.items[n*3+j],p=g.extra.players[n];p.x=a.x;p.y=a.y;g.step(1/60,input(n?8:4));assert.equal(p.carrying,n*3+j);p.x=n?740:60;g.step(1/60,input(n?8:4));assert.equal(p.carrying,-1);}assert(g.won&&g.extra.players.every(p=>p.score===3));
console.log('PASS 5 new multiplayer games: split axes/SW1/SW2/L/R, independent turbo, individual outcomes and shared rescue win');
