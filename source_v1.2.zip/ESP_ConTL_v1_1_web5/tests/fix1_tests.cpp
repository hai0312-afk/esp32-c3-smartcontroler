#include <Arduino.h>
#include <cassert>
#include <cstdio>
#include "Input.h"
#include "ChargeIndicator.h"
#include "HidState.h"

int main() {
  for(uint32_t t=0;t<10000;t+=100) {
    assert(chargeIconVisible(false,false,t)); // unplug: steady, never blinks
    assert(chargeIconVisible(true,true,t));   // invalid status: steady warning
    assert(chargeIconVisible(true,false,t)==((t/500)%2==0));
    assert(chargeIconVisible(false,true,t)==((t/500)%2==0));
  }
  HidState bridge; Input in; cfg=Settings{};
  in.axis[1]=-1000; in.axis[2]=1000; in.axis[3]=-1000; in.buttons=ctl::B_L|ctl::B_R;
  ctl::Packet p; p.flags=ctl::FLAG_USB; p.hid=mappedHid(in);
  assert(bridge.accept(p,100));
  uint8_t key[8],mouse[5]; bridge.keyboardReport(key); bridge.mouseReport(mouse);
  assert(key[0]==2 && key[1]==0 && key[2]==0x1A && key[3]==0x2C); // Shift+W+Space
  assert(mouse[0]==0 && (int8_t)mouse[1]==8 && (int8_t)mouse[2]==-8 && mouse[4]==0);
  bridge.keyboardDone(true,101); bridge.mouseDone(true,102);
  assert(!bridge.wantKeyboard(103)); assert(!bridge.wantMouse(103));
  bridge.mouseReport(mouse); assert(mouse[1]==0 && mouse[2]==0); // NEVER replay relative motion
  assert(bridge.fresh(400)); assert(!bridge.fresh(401));
  assert(bridge.wantKeyboard(351)); assert(bridge.wantMouse(352)); // neutral/held state refresh
  bridge.neutral(); bridge.keyboardReport(key); bridge.mouseReport(mouse);
  for(auto x:key) assert(!x); for(auto x:mouse) assert(!x);
  assert(!bridge.fresh(103)); assert(bridge.wantKeyboard(104) && bridge.wantMouse(104));
  bridge.accept(p,200); bridge.keyboardDone(false,201); bridge.mouseDone(false,201);
  assert(bridge.txErrors==2); assert(bridge.wantKeyboard(201) && bridge.wantMouse(201));
  bridge.mouseReport(mouse); assert(!mouse[1] && !mouse[2]); // uncertain transfer: don't double movement
  bridge.accept(p,250); bridge.hostUnavailable(); bridge.mouseReport(mouse);
  assert(!mouse[1] && !mouse[2]); assert(!bridge.keyboardRecent(250));
  p.flags=0; assert(!bridge.accept(p,251)); assert(bridge.wrongMode==1);
  bridge.keyboardReport(key); for(auto x:key) assert(!x);
  p.flags=ctl::FLAG_USB; bridge.accept(p,0xFFFFFFF0U);
  assert(bridge.fresh(10)); assert(!bridge.fresh(300)); // millis wrap
  puts("PASS fix1: charging blink, C3 mapping -> S3 keyboard/mouse, neutral release, timeout, wrong mode, no stale motion, TX retry");
}
