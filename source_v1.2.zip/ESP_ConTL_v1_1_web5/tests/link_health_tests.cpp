#include <assert.h>
#include <stdio.h>
#include "LinkHealth.h"
int main(){
 LinkHealth h;h.reset(100);assert(!h.healthy(100));assert(!h.timedOut(2099));assert(h.timedOut(2100));
 h.sent(1,10000,110);h.sent(2,20000,360);
 assert(!h.acknowledge(1,9999,120,120));assert(!h.acknowledge(3,20000,370,370));
 assert(h.acknowledge(2,20000,380,400));assert(h.healthy(979));assert(!h.healthy(980));
 assert(h.acknowledge(1,10000,200,450));assert(h.lastReply==380); // reordered packet does not move time backwards
 assert(!h.acknowledge(1,10000,200,450));
 h.sent(3,30000,450);h.expire(800);assert(h.lost==1);h.expire(900);assert(h.lost==1);
 assert(!h.acknowledge(3,30000,460,900)); // stale callback queue
 assert(h.acknowledge(3,30000,820,900));assert(h.healthy(1419));assert(h.timedOut(2820));
 h.reset(0xfffffff0u);h.sent(1,42,0xfffffff0u);assert(h.acknowledge(1,42,20,30));assert(h.healthy(619));assert(!h.healthy(620));assert(h.timedOut(2020));
 h.reset(0);for(int i=0;i<20;i++)h.sent(i,i*10,i*250);assert(!h.acknowledge(0,0,4800,4800));assert(h.acknowledge(19,190,4810,4810));
 puts("PASS heartbeat: bounded probe window, reordered/duplicate/wrong nonce rejection, late reply, stale queue, neutral/lost thresholds, millis wrap");
}
