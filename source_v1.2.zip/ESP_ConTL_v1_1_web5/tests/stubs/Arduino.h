#pragma once
// Minimal host-only mocks. NOT installed in the Arduino sketch folders.
#include <cstdint>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <random>
#include <type_traits>
using std::min; using std::max; using std::abs;
class String:public std::string {
 public:
  String():std::string() {} String(const char *s):std::string(s) {} String(const std::string &s):std::string(s) {}
  template<class T,typename=std::enable_if_t<std::is_arithmetic_v<T>>> String(T n):std::string(std::to_string(n)) {}
};
inline String operator+(const String &a,const String &b) { return String(static_cast<const std::string&>(a)+static_cast<const std::string&>(b)); }
template<class T> inline T constrain(T v,T lo,T hi) { return std::max(lo,std::min(hi,v)); }
inline std::mt19937 rng(123456);
inline long random(long hi) { return hi>0?rng()%hi:0; }
inline long random(long lo,long hi) { return lo+random(hi-lo); }
inline void randomSeed(unsigned n) { rng.seed(n); }
inline uint32_t fakeMillis=0;
inline uint16_t fakeAnalog[32]={};
inline int fakeDigital[32]={};
constexpr int INPUT=0,INPUT_PULLUP=1,LOW=0,HIGH=1,ADC_11db=3;
inline uint32_t millis() { return fakeMillis; }
inline void delay(int n) { fakeMillis+=n; }
inline void pinMode(int,int) {}
inline int analogRead(int pin) { return fakeAnalog[pin]; }
inline void analogReadResolution(int) {}
inline void analogSetPinAttenuation(int,int) {}
inline int digitalRead(int pin) { return fakeDigital[pin]; }

constexpr double PI=3.14159265358979323846;
