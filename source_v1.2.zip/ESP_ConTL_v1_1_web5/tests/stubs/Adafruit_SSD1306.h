#pragma once
#include "Arduino.h"
constexpr int SSD1306_WHITE=1,SSD1306_BLACK=0;
struct Adafruit_SSD1306 {
  uint8_t frame[1024]={}; int cx=0,cy=0;
  uint8_t *getBuffer() { return frame; }
  void drawFastVLine(int,int,int,int) {} void drawFastHLine(int,int,int,int) {}
  void fillTriangle(int,int,int,int,int,int,int) {}

  void fillRect(int,int,int,int,int) {} void drawRect(int,int,int,int,int) {}
  void drawLine(int,int,int,int,int) {} void drawPixel(int x,int y,int color) {
    if(x<0 || x>127 || y<0 || y>63) return;
    int xx=127-x,yy=63-y; uint8_t &b=frame[xx+(yy/8)*128],mask=1U<<(yy&7);
    if(color) b|=mask; else b&=~mask;
  }
  void drawCircle(int,int,int,int) {} void fillCircle(int,int,int,int) {}
  void drawRoundRect(int,int,int,int,int,int) {} void fillRoundRect(int,int,int,int,int,int) {}
  void drawTriangle(int,int,int,int,int,int,int) {}
  void setCursor(int x,int y) { cx=x; cy=y; }
  // Block glyphs only, used to test clipping, NOT to simulate the real Adafruit font.
  void print(const String &s) { for(size_t n=0;n<s.length();n++) { for(int yy=0;yy<7;yy++) for(int xx=0;xx<5;xx++) drawPixel(cx+xx,cy+yy,1); cx+=6; } }
  template<class T> void print(const T&) {}

};
