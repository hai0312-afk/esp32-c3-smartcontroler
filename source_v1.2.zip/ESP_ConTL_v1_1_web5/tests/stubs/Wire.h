#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>
// Host-only fake I2C bus. No electrical timing or actual SSD1306 emulation.
class TwoWire {
 public:
  std::vector<std::vector<uint8_t>> transactions;
  std::vector<uint8_t> current;
  uint32_t clock=0;
  uint16_t timeout=0;
  uint8_t address=0,errorNext=0;
  void setClock(uint32_t hz) { clock=hz; }
  void setTimeOut(uint16_t ms) { timeout=ms; }
  void beginTransmission(uint8_t addr) { address=addr; current.clear(); }
  size_t write(uint8_t value) { current.push_back(value); return 1; }
  size_t write(const uint8_t *data,size_t length) { current.insert(current.end(),data,data+length); return length; }
  uint8_t endTransmission() { transactions.push_back(current); uint8_t e=errorNext; errorNext=0; return e; }
};
