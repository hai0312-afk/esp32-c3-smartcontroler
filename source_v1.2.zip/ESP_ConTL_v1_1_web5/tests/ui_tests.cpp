#include <cassert>
#include <cstdio>
#include <cstring>
#include "UiMotion.h"
#include "OledPump.h"
#include "UiWidgets.h"

int main() {
  int previous=0;
  for(int t=0;t<=220;t++) {
    int value=ui::easeOut(t,220); assert(value>=previous && value<=1024); previous=value;
  }
  assert(ui::easeOut(0,220)==0 && ui::easeOut(220,220)==1024 && ui::easeOut(0,0)==1024);
  uint8_t a[1024],b[1024],dest[1024];
  for(int i=0;i<1024;i++) { a[i]=(uint8_t)(i*37+11); b[i]=(uint8_t)(i*17+101); }
  for(int direction: {-1,1}) for(int t=0;t<=240;t+=10) {
    ui::Slide slide; slide.begin(a,direction,1000); memcpy(dest,b,1024); slide.compose(dest,1000+t);
    int shift=ui::easeOut(t,220)*128/1024;
    for(int y=0;y<64;y++) for(int x=0;x<128;x++) {
      bool expected=ui::pixel(b,x,y);
      if(t<220 && y>=12 && y<54) {
        int xx=x+direction*shift;
        expected=(xx>=0 && xx<128)?ui::pixel(a,xx,y):ui::pixel(b,x-direction*(128-shift),y);
      }
      assert(ui::pixel(dest,x,y)==expected);
    }
    assert(slide.active()==(t<220));
  }
  ui::Slide wrap; wrap.begin(a,1,0xFFFFFFF0U); memcpy(dest,b,1024); wrap.compose(dest,10); assert(wrap.active());
  wrap.compose(dest,210); assert(!wrap.active());
  wrap.begin(a,1,0); wrap.cancel(); memcpy(dest,b,1024); wrap.compose(dest,10); assert(!memcmp(dest,b,1024));

  fakeMillis=0;TwoWire wire;OledPump pump(wire);pump.begin();
  assert(wire.timeout==8&&pump.submit(a));assert(!pump.submit(b));
  pump.service();assert(wire.transactions[0].back()==0xAF&&pump.refreshes==1);
  for(auto v:wire.transactions[0])assert(v!=0xAE); // refresh must not blank the panel
  pump.service();const uint8_t expected[]={0,0x20,0,0x21,0,127,0x22,0,7};
  assert(wire.transactions[1].size()==9&&!memcmp(wire.transactions[1].data(),expected,9));
  for(int i=0;i<32;i++)pump.service();
  assert(!pump.busy()&&pump.frames==1&&wire.clock==400000);
  for(int n=0;n<32;n++){auto tx=wire.transactions[n+2];assert(tx.size()==33&&tx[0]==0x40);assert(!memcmp(tx.data()+1,a+n*32,32));}
  for(int n=0;n<3;n++){
    assert(pump.submit(b));wire.errorNext=2;pump.service();assert(!pump.busy());
    assert(!pump.submit(b));fakeMillis+=120;
  }
  assert(pump.errors==3&&pump.clockHz()==100000);
  assert(pump.takeBusRecovery(fakeMillis)&&pump.recoveries==1);assert(!pump.takeBusRecovery(fakeMillis));
  fakeMillis+=20;pump.setInvert(true);assert(pump.submit(b));pump.service();
  assert(wire.transactions.back()[23]==0xA7);for(int i=0;i<33;i++)pump.service();
  assert(pump.frames==2&&wire.clock==100000);
  // Crossing the refresh deadline in the middle of a frame cannot reset its address pointer.
  fakeMillis=4900;assert(pump.submit(a));pump.service();pump.service();uint32_t before=pump.refreshes;
  fakeMillis=6000;while(pump.busy())pump.service();assert(pump.refreshes==before);
  assert(pump.submit(a));pump.service();assert(pump.refreshes==before+1);while(pump.busy())pump.service();

  // A deadline flag must not make a healthy panel stop after 2^31 ms uptime.
  fakeMillis=0x80001000u;assert(pump.submit(b));while(pump.busy())pump.service();
  fakeMillis=0xfffffff0u;assert(pump.submit(b));wire.errorNext=2;pump.service();
  fakeMillis=20;assert(!pump.submit(b));fakeMillis=120;assert(pump.submit(b));while(pump.busy())pump.service();
  for(int y=0;y<=56;y++) for(int offset: {0,11,43,90}) {
    Adafruit_SSD1306 screen; memcpy(screen.getBuffer(),a,1024);
    ui::clippedText(screen,44,y,79,String("Long text to clip outside this box"),offset);
    for(int yy=0;yy<64;yy++) for(int x=0;x<128;x++) {
      if(x<44 || x>=123 || yy<y || yy>=y+8) assert(ui::pixel(screen.getBuffer(),x,yy)==ui::pixel(a,x,yy));
    }
  }
  for(int t=0;t<10000;t++) {
    assert(ui::marquee(40,79,t)==0);
    int v=ui::marquee(130,79,t); assert(v>=0 && v<=51);
  }
  puts("PASS UI: easing, slide directions/pinned bars/wrap/cancel, 32-byte OLED pump/snapshot/NACK backoff/100k recovery/invert/periodic repair, text clipping, marquee bounds");
}
