"""Viewport bounds AND content bounds, so overflow:hidden cannot hide a layout failure."""
from pathlib import Path
import sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
URL=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:5175'
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1366,'height':768});errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(URL+'/?demo=1');page.locator('[data-device="desktop"]').click()
 page.wait_for_function('contlInspect().bootPhase==="wait"&&contlInspect().bootReady')
 page.keyboard.down('Shift');page.keyboard.down('Space')
 page.wait_for_function('contlInspect().bootPhase==="intro"')
 page.keyboard.up('Space');page.keyboard.up('Shift')
 page.wait_for_function('contlInspect().view==="library"&&!contlInspect().releaseInput');page.wait_for_timeout(500)
 # Genuine native Chromium Fullscreen API, with a trusted button click.
 def inside(selector):
  info=page.locator(selector).evaluate('e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height,iw:innerWidth,ih:innerHeight}}')
  assert info['w']>0 and info['h']>0 and info['x']>=-1 and info['y']>=-1 and info['x']+info['w']<=info['iw']+1 and info['y']+info['h']<=info['ih']+1,(selector,info)
 def no_scroll():
  v=page.evaluate('({h:innerHeight,dh:document.documentElement.scrollHeight,bh:document.body.scrollHeight,y:scrollY,w:innerWidth,dw:document.documentElement.scrollWidth})')
  assert v['dh']<=v['h']+1 and v['bh']<=v['h']+1 and v['dw']<=v['w']+1 and v['y']==0,v
 for w,h in [(1920,1080),(1366,768),(1280,720),(1024,600),(1280,560)]:
  if page.evaluate('!!document.fullscreenElement'):page.evaluate('document.exitFullscreen()');page.wait_for_function('!document.fullscreenElement')
  page.set_viewport_size({'width':w,'height':h});page.wait_for_timeout(500)
  page.locator('#optionalFullscreen').click();page.wait_for_function('!!document.fullscreenElement')
  for sel in ['.topbar','#optionalFullscreen','#filters','#settingsOpen','#heroTitle','#heroDescription','#heroPlay','#heroControls','.shelf-heading','#gameGrid','.library-note','.control-strip']:
   inside(sel)
  # Verify all 26 hero copy blocks fit inside their parent (not just inside viewport).
  page.locator('.game-card[data-id="0"]').evaluate('e=>e.scrollIntoView({block:"nearest",inline:"nearest"})')
  # Navigate from first card using real keyboard input, not just DOM focus.
  page.locator('#gameGrid').evaluate('e=>e.scrollLeft=0')
  page.locator('.game-card[data-id="0"]').dispatch_event('pointerdown')
  for i in range(26):
   page.keyboard.press('ArrowRight');page.wait_for_timeout(150)
   bounds=page.evaluate('(()=>{let a=document.querySelector(".spot-copy").getBoundingClientRect(),b=document.querySelector(".spotlight").getBoundingClientRect();return {top:a.top,bottom:a.bottom,parentTop:b.top,parentBottom:b.bottom}})()')
   assert bounds['top']>=bounds['parentTop']-1 and bounds['bottom']<=bounds['parentBottom']+1,(w,h,bounds)
  no_scroll()
  if (w,h)==(1366,768):page.screenshot(path=str(ROOT/'verification/web5_desktop_library.png'))
  page.locator('.game-card[data-id="6"]').click();page.wait_for_function('!contlInspect().releaseInput');page.wait_for_timeout(500)
  for sel in ['#gameTitle','.scorebar','#gameCanvas','#gameControls','#pauseBtn','#keyboardControls','.control-strip']:inside(sel)
  assert page.locator('#gameCanvas').evaluate('e=>getComputedStyle(e).objectFit')=='contain'
  page.locator('#pauseBtn').click();assert page.locator('#overlayTitle').inner_text()=='Menu game'
  for sel in ['#overlayTitle','#overlayText','#overlayContinue','#overlayRestart','#overlayLibrary','#overlaySettings']:inside(sel)
  no_scroll()
  if (w,h)==(1366,768):page.screenshot(path=str(ROOT/'verification/web5_desktop_menu.png'))
  page.locator('#overlayLibrary').click();page.locator('#confirmYes').click();page.wait_for_function('!contlInspect().releaseInput');page.wait_for_timeout(500)
  print(f'PASS native fullscreen + resize {w}x{h}: library, 26 hero blocks, game, Menu game; content bounds + no vertical page scroll')
 page.evaluate('document.exitFullscreen()');page.wait_for_function('!document.fullscreenElement');page.wait_for_timeout(100);no_scroll()
 page.close()
 for profile in ['desktop','tv']:
  for w,h in [(1920,1080),(1366,768),(1280,720),(1024,600),(1280,560)]:
   page=b.new_page(viewport={'width':w,'height':h});page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto(URL+'/index.html');page.wait_for_function('window.contlInspect');page.wait_for_timeout(500);no_scroll()
   for sel in ['.device-page h1','[data-device="tv"]','[data-device="phone"]','[data-device="desktop"]','[data-device="tablet"]','.device-page>.tiny','.control-strip']:inside(sel)
   page.locator('[data-device="'+profile+'"]').click();page.wait_for_timeout(500);no_scroll()
   for sel in ['.gate-copy','.pin-panel','#pinDigits','#pinPad','#pinFullscreen','#localPlay','#pairDevice','.pin-panel>.tiny','.control-strip']:inside(sel)
   bounds=page.evaluate('({panel:document.querySelector(".pin-panel").getBoundingClientRect().bottom,footer:document.querySelector(".control-strip").getBoundingClientRect().top})')
   assert bounds['panel']<=bounds['footer'],bounds
   page.close();print(f'PASS entry screens {profile} {w}x{h}: chooser, PIN and buttons fit above footer; no vertical page scroll')
 assert not errors,errors
 b.close();print('PASS exit fullscreen. Chromium only; no physical PC/TV test.')
