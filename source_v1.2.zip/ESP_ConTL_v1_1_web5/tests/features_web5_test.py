"""New web5 UI features; mocked Wake Lock is not an OS sleep measurement."""
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];URL='http://127.0.0.1:5175'
MOCK=(ROOT/'tests/browser_mock.js').read_text()
WAKE="""window.wakeRequests=0;window.locks=[];window.hiddenForTest=false;
Object.defineProperty(document,'hidden',{get:()=>hiddenForTest,configurable:true});
Object.defineProperty(window,'isSecureContext',{value:true,configurable:true});
Object.defineProperty(navigator,'wakeLock',{value:{request:async()=>{wakeRequests++;const l=new EventTarget();l.released=false;l.release=async()=>{l.released=true;l.dispatchEvent(new Event('release'))};locks.push(l);return l}},configurable:true});"""
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,args=['--no-sandbox']);errors=[]
 def page(**kw):
  pg=b.new_page(**kw);pg.on('pageerror',lambda e:errors.append(str(e)));return pg
 def boot(pg,device='desktop'):
  pg.locator('[data-device="'+device+'"]').click();pg.wait_for_function('contlInspect().bootPhase==="wait"');pg.locator('#bootStart').click();pg.wait_for_function('contlInspect().view==="library"&&!contlInspect().releaseInput');pg.wait_for_timeout(500)
 # Native fullscreen at PIN must retain partial PIN and stay on the same view.
 pg=page(viewport={'width':1366,'height':768});pg.add_init_script(WAKE);pg.goto(URL+'/index.html');pg.wait_for_function('window.contlInspect');pg.locator('[data-device="desktop"]').click();pg.keyboard.type('123');pg.locator('#pinFullscreen').click();pg.wait_for_function('!!document.fullscreenElement')
 assert pg.evaluate('contlInspect().view==="pair"&&contlInspect().pinLength===3')
 pg.wait_for_timeout(500);pg.screenshot(path=str(ROOT/'verification/web5_pin_fullscreen.png'))
 pg.wait_for_function('contlInspect().wakeState==="active"');assert pg.evaluate('wakeRequests')==1
 pg.evaluate("hiddenForTest=true;document.dispatchEvent(new Event('visibilitychange'))");pg.wait_for_function('contlInspect().wakeState==="hidden"');assert pg.evaluate('locks[0].released')
 pg.evaluate("hiddenForTest=false;document.dispatchEvent(new Event('visibilitychange'))");pg.wait_for_function('contlInspect().wakeState==="active"');assert pg.evaluate('wakeRequests')==2
 pg.evaluate('locks[1].release()');pg.wait_for_function('contlInspect().wakeState==="released"')
 pg.evaluate("document.getElementById('wakeRetry').click()");pg.wait_for_function('contlInspect().wakeState==="active"')
 pg.evaluate("document.getElementById('wakeBtn').click()");pg.wait_for_function('contlInspect().wakeState==="off"');assert pg.evaluate('locks[2].released');pg.close()
 print('PASS native fullscreen at PIN preserves view/digits; Wake Lock acquire/release/reacquire/OS release/retry/disable (mock)')
 for mode in ['insecure','unsupported','denied','pending']:
  pg=page();pg.add_init_script(WAKE)
  pg.add_init_script({'insecure':"Object.defineProperty(window,'isSecureContext',{value:false})",'unsupported':"Object.defineProperty(navigator,'wakeLock',{value:undefined})",'denied':"navigator.wakeLock.request=()=>Promise.reject(new Error('NotAllowedError'))",'pending':"navigator.wakeLock.request=()=>new Promise(r=>window.resolveWake=r)"}[mode])
  pg.goto(URL+'/?demo=1');pg.wait_for_function('window.contlInspect');pg.wait_for_function('contlInspect().wakeState==="'+('requesting' if mode=='pending' else mode)+'"')
  if mode=='pending':
   pg.locator('[data-device="tv"]').click();pg.evaluate("window.lateLock=new EventTarget();lateLock.released=false;lateLock.release=async()=>{lateLock.released=true};resolveWake(lateLock)");pg.wait_for_function('lateLock.released');assert pg.evaluate('contlInspect().wakeState')=='off'
  pg.close();print('PASS Wake Lock '+mode+' branch; never falsely reports active')
 # C3 WS packets, specifically bit 8 -> P2 fire, and L+R menu chord.
 pg=page(viewport={'width':1440,'height':900});pg.add_init_script(MOCK);pg.add_init_script(WAKE)
 pg.route('**/api/auth',lambda r:r.fulfill(json={'token':'b'*32}));pg.route('**/api/status',lambda r:r.fulfill(json={'apIP':'192.168.4.1','lanIP':'','clients':1}))
 pg.goto(URL+'/index.html');pg.locator('[data-device="desktop"]').click();pg.keyboard.type('123456');pg.locator('[data-pin="pair"]').click();pg.wait_for_function('contlInspect().bootPhase==="wait"');pg.locator('#bootStart').click();pg.wait_for_function('contlInspect().view==="library"&&!contlInspect().releaseInput');pg.wait_for_timeout(500)
 assert pg.locator('.game-card').count()==26
 pg.locator('[data-filter="duo"]').click();assert pg.locator('.game-card').count()==6
 pg.locator('.game-card[data-id="22"]').click();pg.wait_for_function('!contlInspect().releaseInput')
 pg.evaluate("()=>{const old=ContlGame.Game.prototype.step;window.events=[];ContlGame.Game.prototype.step=function(dt,i){window.lastGame=this;if(i.p)events.push(i.p);return old.call(this,dt,i)}}")
 pg.evaluate('mock.b=8');pg.wait_for_timeout(120);pg.evaluate('mock.b=0');pg.wait_for_timeout(100)
 assert pg.evaluate('events.some(p=>p&8)&&lastGame.extra.bullets.some(b=>b.owner===1)&&!contlInspect().paused')
 pg.evaluate('mock.b=4');pg.wait_for_timeout(100);pg.evaluate('mock.b=0');pg.wait_for_timeout(100)
 assert pg.evaluate('lastGame.extra.bullets.some(b=>b.owner===0)')
 pg.evaluate('mock.a=[1000,0,0,-1000]');pg.wait_for_timeout(150);pg.evaluate('mock.a=[0,0,0,0]')
 assert pg.evaluate('lastGame.extra.players[0].x>180&&lastGame.extra.players[1].y<225')
 pg.evaluate('mock.b=3');pg.wait_for_timeout(850);pg.evaluate('mock.b=0');pg.wait_for_timeout(100);assert pg.evaluate('contlInspect().paused')
 pg.locator('#overlayContinue').click();pg.wait_for_timeout(200);assert not pg.evaluate('contlInspect().paused')
 pg.screenshot(path=str(ROOT/'verification/web5_duel.png'));pg.close();print('PASS C3 2P split axes, SW1 + SW2 preserved; SW2 never pauses; L+R 0.7s menu; six 2P entries including old Pong')
 # Local keyboard split and TV animations (including reduced-motion accessibility).
 for reduced in ['no-preference','reduce']:
  pg=page(viewport={'width':1280,'height':720},reduced_motion=reduced);pg.goto(URL+'/?demo=1');pg.locator('[data-device="tv"]').click();pg.wait_for_function('contlInspect().bootPhase==="wait"');pg.locator('#bootStart').click();pg.wait_for_timeout(1250)
  anim=pg.locator('#bootLogo .logo-shell').evaluate('e=>getComputedStyle(e).animationName')
  assert (anim!='none')==(reduced=='no-preference'),anim
  if reduced=='no-preference':pg.screenshot(path=str(ROOT/'verification/web5_tv_intro.png'))
  pg.wait_for_function('contlInspect().view==="library"&&!contlInspect().releaseInput');pg.wait_for_timeout(500)
  ambient=pg.locator('.ambient').evaluate('e=>getComputedStyle(e).animationName');assert (ambient!='none')==(reduced=='no-preference')
  pg.close()
 pg=page(viewport={'width':1366,'height':768});pg.goto(URL+'/?demo=1');boot(pg)
 pg.locator('.game-card[data-id="22"]').click();pg.wait_for_function('!contlInspect().releaseInput')
 pg.evaluate("()=>{const old=ContlGame.Game.prototype.step;ContlGame.Game.prototype.step=function(dt,i){window.localGame=this;return old.call(this,dt,i)}}")
 for key in ['d','ArrowUp','e','o']:pg.keyboard.down(key)
 pg.wait_for_timeout(150)
 for key in ['d','ArrowUp','e','o']:pg.keyboard.up(key)
 assert pg.evaluate('!contlInspect().paused&&localGame.extra.players[0].x>180&&localGame.extra.players[1].y<225&&localGame.extra.bullets.some(b=>b.owner===0)&&localGame.extra.bullets.some(b=>b.owner===1)')
 pg.keyboard.press('Escape');pg.wait_for_function('contlInspect().paused');pg.locator('#overlayContinue').click();pg.wait_for_function('!contlInspect().paused');pg.evaluate("localGame.end(false,'TEST END')");pg.wait_for_function('contlInspect().focused==="overlayRestart"');pg.keyboard.press('ArrowRight',delay=100);pg.wait_for_function('contlInspect().focused==="overlayLibrary"');pg.close()
 print('PASS TV logo/intro/ambient animation and prefers-reduced-motion; local 2P WASD/E/Q + arrows/O/U and Esc')
 assert not errors,errors;b.close()
 print('PASS web5 new-feature suite. Browser/API/WS simulation, not physical OS sleep or board testing.')
