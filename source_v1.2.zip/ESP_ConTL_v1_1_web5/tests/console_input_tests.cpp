#include <assert.h>
#include <stdio.h>
#include <set>
#include "ConsoleInput.h"
int main(){
 ConsoleRepeat r;assert(r.step(0,0,0)==-1);assert(r.step(700,0,10)==0);assert(r.step(700,0,389)==-1);assert(r.step(700,0,390)==0);assert(r.step(700,0,514)==-1);assert(r.step(700,0,515)==0);assert(r.step(400,0,520)==-1);assert(r.step(0,-800,521)==3);assert(r.step(0,0,522)==-1);
 assert(r.step(-900,0,0xfffffff0u)==2);assert(r.step(-900,0,0x100)==-1);assert(r.step(-900,0,0x170)==2);
 OledKeyboard k;std::set<char> chars;for(int p=0;p<3;p++){k.page=p;for(int i=0;i<36;i++)chars.insert(k.character(i));}for(int c=32;c<=126;c++)assert(chars.count((char)c));
 k.clear();k.move(2);assert(k.cell==9);k.move(3);assert(k.cell==39);assert(k.select());k.clear();
 for(int i=0;i<80;i++)k.select();assert(k.length==63&&k.value[63]==0);k.cell=36;k.select();assert(k.length==62);k.cell=37;k.select();assert(k.page==1);k.cell=38;k.select();assert(k.value[62]==' ');k.clear();for(char c:k.value)assert(c==0);
 puts("PASS OLED keyboard: all printable ASCII, lowercase/uppercase/symbols, 63-byte bound, erase/space/OK, wrap and wipe; joystick deadzone, repeat and millis wrap");
}
