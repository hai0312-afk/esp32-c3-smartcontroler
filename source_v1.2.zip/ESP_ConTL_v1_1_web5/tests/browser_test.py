"""Web5 UI/compatibility regression. Chromium + browser-side mocks, NOT actual TV/RF."""
from pathlib import Path
from urllib.parse import parse_qs
import sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
URL=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:5175'
MOCK=(ROOT/'tests/browser_mock.js').read_text()
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,args=['--no-sandbox'])
 errors=[]
 def create(**kw):
  pg=browser.new_page(**kw);pg.on('pageerror',lambda e:errors.append(str(e)));return pg
 def enter_local(pg):
  pg.wait_for_function('contlInspect().bootPhase==="wait"');pg.locator('#bootStart').click();pg.wait_for_function('contlInspect().view==="library"&&!contlInspect().releaseInput')
 # Missing, rejected AND never-settling fullscreen must never block PIN -> library.
 for fs in ['missing','reject','pending']:
  page=create(viewport={'width':1440,'height':1000});page.add_init_script(MOCK)
  page.add_init_script("window.globalThis=undefined;String.prototype.padStart=undefined;CanvasRenderingContext2D.prototype.roundRect=undefined;Element.prototype.replaceChildren=undefined;")
  page.add_init_script("Element.prototype.requestFullscreen="+{'missing':'undefined','reject':"()=>Promise.reject(new Error('Blocked'))",'pending':'()=>new Promise(()=>{})'}[fs]+";Element.prototype.webkitRequestFullscreen=undefined;")
  page.route('**/api/status',lambda r:r.fulfill(json={'apIP':'192.168.4.1','lanIP':'192.168.1.7','clients':1}))
  attempts=[]
  def auth(r):
   code=parse_qs(r.request.post_data or '').get('code',[''])[0];attempts.append(code)
   r.fulfill(status=200 if code=='123456' else 401,json={'token':'a'*32} if code=='123456' else {'error':'PIN sai'})
  page.route('**/api/auth',auth);page.goto(URL+'/index.html');page.wait_for_function('window.contlInspect')
  assert page.evaluate('contlInspect().view')=='device'
  if fs=='missing':page.screenshot(path=str(ROOT/'verification/web5_device.png'),full_page=True)
  page.locator('[data-device="tv"]').click();page.wait_for_function('contlInspect().view==="pair"')
  def state():return page.evaluate('contlInspect()')
  def menu():
   if state()['game']['players']==2:tap(b=3,ms=850)
   else:tap(b=8)
  def tap(d=-1,b=0,ms=130):
   a=[[900,0,0,0],[0,900,0,0],[-900,0,0,0],[0,-900,0,0]][d] if d>=0 else [0,0,0,0]
   page.evaluate('(v)=>Object.assign(mock,v)',{'d':d,'b':b,'a':a});page.wait_for_timeout(ms)
   page.evaluate('Object.assign(mock,{d:-1,b:0,a:[0,0,0,0]})');page.wait_for_timeout(100)
  tap(d=0);assert state()['focused']=='1'
  page.evaluate('mockApprove()');page.wait_for_function('contlInspect().pairAllowed')
  if fs=='missing':
   for _ in range(6):tap(b=4)
   tap(b=2);page.wait_for_function('contlInspect().pinLength===0');assert attempts==['111111']
   pad=['1','2','3','4','5','6','7','8','9','del','0','pair']
   for digit in '123456':
    target=pad.index(digit)
    for _ in range(8):
     at=pad.index(state()['focused'])
     if at==target:break
     tap(d=(1 if at//3<target//3 else 3) if at//3!=target//3 else (0 if at%3<target%3 else 2))
    assert state()['focused']==digit;tap(b=4)
  else:
   for digit in '123456':page.keyboard.press(digit)
  tap(b=2);page.wait_for_function('contlInspect().view==="boot"')
  assert state()['bootPhase']=='black'
  if fs=='missing':
   page.evaluate('mock.b=3');page.wait_for_function('contlInspect().bootPhase==="wait"');page.wait_for_timeout(150)
   assert not state()['bootReady'] and state()['bootPhase']=='wait','Held L/R carried through PIN'
   page.evaluate('mock.stream=false');page.wait_for_timeout(500)
   assert state()['bootPhase']=='wait','Stale input started intro'
   page.evaluate('Object.assign(mock,{stream:true,b:0})')
  page.wait_for_function('contlInspect().bootPhase==="wait"&&contlInspect().bootReady')
  tap(b=1);assert state()['bootPhase']=='wait'
  tap(b=2);assert state()['bootPhase']=='wait'
  if fs=='missing':page.screenshot(path=str(ROOT/'verification/web5_start.png'))
  tap(b=3);assert state()['bootPhase']=='intro'
  if fs=='missing':page.screenshot(path=str(ROOT/'verification/web5_intro.png'))
  page.wait_for_function('contlInspect().view==="library"')
  assert state()['inputMode']=='esp' and attempts[-1]=='123456'
  assert state()['filter']=='all','PIN-submit R must not leak into library'
  assert page.evaluate("'12345'.padStart(4,'0')")=="12345"
  page.locator('#optionalFullscreen').click();page.wait_for_timeout(1650 if fs=='pending' else 150)
  assert state()['view']=='library';assert not page.evaluate('!!document.fullscreenElement')
  if fs=='missing':
   page.screenshot(path=str(ROOT/'verification/web5_tv.png'),full_page=True)
   # All 26 engines plus controller-only pause/restart/library/confirm navigation.
   page.locator('.game-card[data-id="0"]').focus()
   # focus() is not the app focus; use a single initial click only to put first game into play.
   for id in range(26):
    if id==0:page.locator('.game-card[data-id="0"]').click()
    else:
     tap(d=0);assert state()['selected']==id,(id,state());tap(b=4)
    assert state()['game']['id']==id
    if id==0:
     page.wait_for_function('!contlInspect().releaseInput')
     page.evaluate("()=>{window.testPresses=[];const original=ContlGame.Game.prototype.step;ContlGame.Game.prototype.step=function(dt,i){if(i.p)testPresses.push(i.p);return original.call(this,dt,i)}}")
     page.keyboard.down('Space');page.wait_for_timeout(120);page.keyboard.up('Space')
     assert not page.evaluate('testPresses.length'),'Local fire leaked into C3 gameplay'
     page.keyboard.down('Escape');page.wait_for_timeout(200)
     assert state()['paused'],'Held Escape must pause once, not toggle repeatedly'
     page.keyboard.up('Escape');page.locator('#overlayContinue').click()
     page.evaluate("document.getElementById('inputSource').click()")
     assert state()['inputMode']=='local' and state()['paused']
     focused=state()['focused'];tap(d=0);tap(b=8)
     assert state()['paused'] and state()['focused']==focused,'C3 leaked into local UI'
     page.locator('#overlayContinue').click();page.evaluate('testPresses=[]')
     tap(b=2);tap(b=8)
     assert not state()['paused'] and not page.evaluate('testPresses.length'),'C3 leaked into local gameplay'
     page.evaluate("document.getElementById('inputSource').click()")
     page.locator('#overlayContinue').click()
     print('PASS source isolation: C3/local game edges and local UI; held Escape pauses once')
    tap(d=0,b=2,ms=120)
    menu();assert state()['paused'];assert page.locator('#overlayTitle').inner_text()=='Menu game';assert state()['focused']=='overlayContinue'
    tap(d=0);assert state()['focused']=='overlayRestart';tap(b=4);tap(d=0);tap(b=4)
    assert not state()['confirm'] and state()['game']['id']==id
    menu();tap(d=0);tap(d=0);assert state()['focused']=='overlayLibrary';tap(b=4);tap(d=0);tap(b=4)
    assert state()['view']=='library'
   tap(b=4);page.evaluate('mock.stream=false');page.wait_for_function('contlInspect().blocked',timeout=2000);assert state()['paused']
   page.evaluate('Object.assign(mock,{stream:true,p:true,h:1500})');page.wait_for_function("document.getElementById('overlayTitle').textContent.includes('Giữ để thoát')")
   page.evaluate('Object.assign(mock,{p:false,h:0})');page.wait_for_function('!contlInspect().paused')
  page.close();print('PASS PIN -> black -> L+R -> intro -> TV library with fullscreen '+fs+'; roundRect/replaceChildren fallbacks')
 # Legacy remote keyCode without KeyboardEvent.code. No fullscreen API necessary.
 page=create(viewport={'width':1280,'height':720});page.goto(URL+'/?demo=1');page.wait_for_function('window.contlInspect')
 page.locator('[data-device="tv"]').click();enter_local(page)
 def remote_key(code):
  for kind in ['keydown','keyup']:
   page.evaluate("([kind,code])=>window.dispatchEvent(new KeyboardEvent(kind,{keyCode:code,which:code,bubbles:true,cancelable:true}))",[kind,code]);page.wait_for_timeout(130)
 remote_key(39);assert page.evaluate('contlInspect().selected')==1
 remote_key(13);assert page.evaluate('contlInspect().view')=='play'
 remote_key(10009);assert page.evaluate('contlInspect().paused')
 page.close();print('PASS legacy TV Right/OK/Samsung Back keyCode events; no forced fullscreen')
 # Actual Chromium touch dispatch, including multi-touch and cancel, in two layouts.
 for device,viewport,fallback in [('phone',{'width':390,'height':844},False),('tablet',{'width':1024,'height':768},True)]:
  page=create(viewport=viewport,is_mobile=True,has_touch=True,device_scale_factor=1)
  if fallback:page.add_init_script('window.PointerEvent=undefined;')
  page.goto(URL+'/?demo=1');page.wait_for_function('window.contlInspect');page.locator('[data-device="'+device+'"]').tap();enter_local(page);page.locator('.game-card[data-id="6"]').tap()
  page.locator('#touchControls').scroll_into_view_if_needed();page.wait_for_timeout(150)
  assert page.locator('#touchControls').is_visible()
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
  def point(sel,id):
   r=page.locator(sel).bounding_box();return {'x':r['x']+r['width']/2,'y':r['y']+r['height']/2,'id':id,'radiusX':3,'radiusY':3,'force':1}
  one=point('#touchJoy1',1);two=point('#touchJoy2',2);button=point('[data-touch="2"]',3)
  session=page.context.new_cdp_session(page)
  session.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[one,two,button]})
  one['x']+=24;two['y']-=24
  session.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[one,two,button]});page.wait_for_timeout(120)
  t=page.evaluate('contlInspect().touch');assert t['a'][0]>.2 and t['a'][3]<-.2 and t['b']&2,(device,t)
  session.send('Input.dispatchTouchEvent',{'type':'touchCancel','touchPoints':[]});page.wait_for_timeout(120)
  t=page.evaluate('contlInspect().touch');assert t=={'a':[0,0,0,0],'b':0},t
  page.screenshot(path=str(ROOT/f'verification/web5_{device}.png'),full_page=True)
  page.evaluate("window.dispatchEvent(new Event('blur'))");page.wait_for_function('contlInspect().paused')
  page.close();print('PASS '+device+' multi-touch dual sticks + button, cancel/blur neutral, responsive; '+('TouchEvent fallback' if fallback else 'PointerEvent'))
 # Plain desktop profile can also skip PIN intentionally for keyboard-only local play.
 page=create(viewport={'width':1366,'height':768});page.goto(URL+'/index.html');page.wait_for_function('window.contlInspect');page.locator('[data-device="desktop"]').click();page.locator('#localPlay').click();enter_local(page)
 assert page.evaluate('contlInspect().view==="library"&&contlInspect().inputMode==="local"')
 page.close();assert not errors,errors;browser.close()
 print('PASS all browser tests. MOCK networking + Chromium viewport/touch emulation, NOT real TV/phone/tablet or ESP hardware.')
