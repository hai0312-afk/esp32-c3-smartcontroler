#include <Arduino.h>
#include <Adafruit_SSD1306.h>
#include <Preferences.h>
#include <cassert>
#include <cstdio>
// Expose state for invariants; this does not change the firmware sources.
#define private public
#include "Games.h"
#undef private

static void protocolTests() {
  ctl::Packet p; assert(ctl::valid(p)); assert(sizeof(p)==41); assert(sizeof(ctl::Hello)==20);
  p.bytes=40; assert(!ctl::valid(p)); p.bytes=41; p.version=2; assert(!ctl::valid(p));
  assert(ctl::newer(1,0xFFFFFFFF)); assert(!ctl::newer(7,7)); assert(!ctl::newer(6,7));
}
static void inputTests() {
  cfg=Settings{}; Input in;
  in.axis[1]=-1000; in.axis[2]=1000; in.buttons=15;
  auto h=mappedHid(in);
  assert(h.keys[0]==0x1A); assert(h.modifiers==2); assert(h.dx==8); assert(h.dy==0);
  in=Input{}; h=mappedHid(in);
  ctl::HidReport empty; assert(!memcmp(&h,&empty,sizeof(h)));
  cfg.joy2Mouse=false; in.axis[2]=1000; h=mappedHid(in); assert(h.keys[0]==0x4F); assert(!h.dx);
  cfg.mapping[0]=cfg.mapping[2]=1; in=Input{}; in.axis[0]=in.axis[1]=-1000;
  h=mappedHid(in); assert(h.keys[0]==0x1A && h.keys[1]==0);
  cfg=Settings{};
  for(int &d:fakeDigital) d=HIGH;
  for(auto pin:AXIS_PINS) fakeAnalog[pin]=2048;
  Input hw; hw.begin(); hw.update();
  for(int a:hw.axis) assert(a==0);
  fakeDigital[7]=LOW; fakeMillis=100; hw.update(); assert(!hw.buttons);
  fakeMillis=126; hw.update(); assert(hw.buttons==ctl::B_L && hw.hit(ctl::B_L));
  fakeMillis=150; hw.update(); assert(!hw.pressed);
  fakeDigital[7]=HIGH; hw.update(); fakeMillis=180; hw.update(); assert(!hw.buttons && hw.released==ctl::B_L);
  for(auto pin:AXIS_PINS) fakeAnalog[pin]=2000;
  assert(hw.calibrate()); for(int c:cfg.center) assert(c==2000);
  fakeAnalog[0]=0; assert(!hw.calibrate());
  cfg=Settings{};
}
static void focusedGames() {
  Games g; Input in;
  g.start(3);
  for(int p=0;p<7;p++) for(int r=0;r<4;r++) {
    g.piece=p; assert(g.blockFits(3,0,r));
    assert(!g.blockFits(-4,0,r)); assert(!g.blockFits(10,0,r)); assert(!g.blockFits(3,12,r));
  }
  g.start(3); g.piece=0; g.rotation=0; g.tx=3; g.ty=10;
  for(int x=0;x<10;x++) g.cells[11][x]=(x<3 || x>6);
  g.lockPiece(); assert(g.score==100 && g.a==1);
  for(int x=0;x<10;x++) assert(!g.cells[11][x]);
  g.start(9); g.length=288; g.snakeFood(); assert(g.over && g.won);
  g.start(5); g.a=6; g.aux=127; g.vx=1; g.aux2=1; g.py=25;
  g.tick(in); assert(g.over && g.won && g.a==7);
  g.start(8); g.aux=1201; g.tick(in); assert(g.over && g.won);
  g.start(2); assert(g.solid(1,41)); assert(!g.solid(12*8+1,41));
  float old=g.enemies[0].x; for(int i=0;i<3;i++) g.tick(in); assert(g.enemies[0].x!=old);
  g.start(7); in.pressed=ctl::B_R; g.enemies[0]={5,5,0,0,true,0};
  g.tick(in); assert(!g.enemies[0].live && g.a==2 && g.score==10);
}
int main() {
  protocolTests(); inputTests(); focusedGames();
  Adafruit_SSD1306 d;
  for(int game=0;game<Games::COUNT;game++) {
    Games g; g.start(game); Input in; int restarts=0;
    for(int frame=0;frame<30000;frame++) {
      uint8_t old=in.buttons;
      if(frame%8==0) {
        for(auto &a:in.axis) a=random(-1000,1001);
        in.buttons=random(16);
      }
      in.pressed=in.buttons&~old;
      if(g.over) { in.pressed=ctl::B_R; restarts++; }
      g.tick(in); g.draw(d);
      assert(std::isfinite(g.px) && std::isfinite(g.py));
      if(game==9) assert(g.length>=4 && g.length<=288);
      if(game==0) assert(g.px>=0 && g.px<21 && g.py>=0 && g.py<8);
    }
    printf("PASS %s: 30000 ticks, %d restarts\n",Games::names[game],restarts);
  }
  puts("PASS protocol, HID mapping, debounce, calibration and focused game invariants");
}
