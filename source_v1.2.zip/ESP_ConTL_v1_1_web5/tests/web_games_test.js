'use strict';
const assert=require('node:assert/strict');
require('../web/games.js');
const {Game,DEFS}=globalThis.ContlGame;
assert.equal(DEFS.length,26);
const noop=()=>{};
const ctx=new Proxy({}, {get:(o,k)=>k in o?o[k]:(k==='createLinearGradient'||k==='createRadialGradient'?()=>({addColorStop:noop}):noop),set:(o,k,v)=>(o[k]=v,true)});
function finite(v,path='game') {if(typeof v==='number')assert(Number.isFinite(v),path);else if(v&&typeof v==='object')for(const [k,x]of Object.entries(v))finite(x,path+'.'+k);}
let state=784322;const rand=()=>((state=(Math.imul(state,1664525)+1013904223)>>>0)/4294967296);
for(let id=0;id<DEFS.length;id++) {let g=new Game(id,123+id),restarts=0,prev=0;
 for(let tick=0;tick<30000;tick++) {if(g.over){g=new Game(id,123+tick);restarts++;prev=0;}const b=Math.floor(rand()*16),a=Array.from({length:4},()=>rand()*2-1);g.step(1/60,{a,b,p:b&~prev});prev=b;if(tick%61===0){finite(g);g.render(ctx);}assert(g.particles.length<=160);assert(g.shots.length<=100);}
 console.log(`PASS web ${DEFS[id].name}: 30000 ticks, ${restarts} restarts`);
}
let maze=new Game(0),seen=new Set(['1,1']),queue=[[1,1]];
while(queue.length){const [x,y]=queue.shift();for(const [dx,dy]of [[1,0],[-1,0],[0,1],[0,-1]]){let xx=x+dx,yy=y+dy,key=xx+','+yy;if(maze.grid[yy]?.[xx]&&maze.grid[yy][xx]!=='#'&&!seen.has(key)){seen.add(key);queue.push([xx,yy]);}}}
let dots=0;maze.grid.forEach((r,y)=>r.forEach((c,x)=>{if(c==='.'||c==='o'){dots++;assert(seen.has(x+','+y),'unreachable dot');}}));assert.equal(dots,maze.left);
let vector=new Game(7);vector.enemies=[{x:vector.p.x,y:vector.p.y,alive:true}];vector.step(1/60,{a:[0,0,0,0],b:2,p:2});assert.equal(vector.lives,3);assert.equal(vector.bombs,2);assert.equal(vector.score,20);
let pong=new Game(5);pong.step(1/60,{a:[0,-1,0,1],b:0,p:0});assert(pong.p.y<225&&pong.right>225);
console.log(`PASS maze connectivity (${dots} dots), same-tick bomb safety, independent Pong axes; 780000 web simulation ticks total (not real hardware timing)`);

let platform=new Game(2);platform.p={x:100,y:369,vx:0,vy:0};let top=369;
for(let t=0;t<80;t++){platform.step(1/60,{a:[0,0,0,0],b:t===0?2:0,p:t===0?2:0});top=Math.min(top,platform.p.y+19);}
assert(top<205,'jump must reach the highest platform height');
let blocks=new Game(3);for(let y=18;y<20;y++){blocks.board[y].fill(1);blocks.board[y][0]=blocks.board[y][1]=0;}blocks.piece=1;blocks.rotation=0;blocks.tx=-1;blocks.ty=18;blocks.lockPiece();assert.equal(blocks.lines,2);assert.equal(blocks.score,400);
let snake=new Game(9);snake.snake=Array.from({length:576},(_,i)=>({x:i%32,y:Math.floor(i/32)}));snake.food();assert(snake.over&&snake.won);
console.log('PASS platform jump height, two-line block clear, full snake board win');
