#include <cassert>
#include <cstdio>
#include "HomeJoinPolicy.h"
int main(){
 using P=HomeJoinPolicy;P p;
 assert(p.tick(0,true)==P::NONE&&p.stage==P::IDLE);
 assert(p.begin(100)==P::CONNECT&&p.attempt==1);
 assert(p.tick(101,false)==P::NONE);
 assert(p.tick(25100,false)==P::DISCONNECT&&p.stage==P::RETRY_WAIT);
 assert(p.tick(26099,true)==P::NONE); // A late IP does not bypass a cancelled attempt.
 assert(p.tick(26100,false)==P::CONNECT&&p.attempt==2);
 assert(p.tick(51100,false)==P::DISCONNECT&&p.stage==P::FAILED);
 for(unsigned i=0;i<100;i++)assert(p.tick(100000+i,true)==P::NONE&&p.stage==P::FAILED);
 assert(p.begin(200000)==P::CONNECT); // Explicit OLED retry.
 assert(p.tick(200900,true)==P::NONE&&p.stage==P::ONLINE);
 assert(p.tick(201000,true)==P::NONE&&p.stage==P::ONLINE);
 assert(p.tick(202000,false)==P::CONNECT&&p.stage==P::JOINING&&p.attempt==1);
 p.stop();assert(p.stage==P::IDLE&&p.attempt==0);
 p.begin(0xfffffff0u);assert(p.tick(0xfffffff0u+24999u,false)==P::NONE);
 assert(p.tick(0xfffffff0u+25000u,false)==P::DISCONNECT);
 assert(p.tick(0xfffffff0u+26000u,false)==P::CONNECT);
 assert(p.tick(0xfffffff0u+26001u,true)==P::NONE&&p.stage==P::ONLINE);
 puts("PASS home join: bounded 2 x 25s attempts, 1s retry wait, late IP, explicit retry, reconnect, stop, millis wrap; no automatic AP transition");
}
