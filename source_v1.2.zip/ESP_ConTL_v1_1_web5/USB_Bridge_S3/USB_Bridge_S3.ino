// ESP ConTL v1.1-fix1 / HDZ463
// ESP32-S3: USB Mode = USB-OTG (TinyUSB), USB CDC On Boot = Enabled.
// Native USB (GPIO19 D-, GPIO20 D+) MUST connect to a USB HOST with a data cable.
#include "USB.h"
#include "USBHIDKeyboard.h"
#include "USBHIDMouse.h"
#include "tusb.h"
#include "ReceiverLink.h"
#include "HidState.h"
#if !CONFIG_IDF_TARGET_ESP32S3
#error "Select an ESP32-S3 board"
#endif
#if ARDUINO_USB_MODE
#error "Tools > USB Mode must be USB-OTG (TinyUSB), not Hardware CDC/JTAG"
#endif
// Register standard core descriptors before USB.begin(). Use the transport directly below
// because Keyboard.sendReport()/Mouse.move() have no success return and default to long waits.
USBHIDKeyboard keyboard;
USBHIDMouse mouse;
USBHID transport;
ReceiverLink receiver;
HidState hidState;
ctl::HidReport lastInput; // diagnostics: last received values, not a pending USB delta

void stopOutputs() { hidState.neutral(); lastInput=ctl::HidReport{}; }
void onControl(const ctl::Packet &p) {
  if(hidState.accept(p,millis())) lastInput=p.hid;
  else lastInput=ctl::HidReport{};
}

uint8_t usbStatus() {
  const uint32_t now=millis();
  bool mounted=tud_mounted(),suspended=tud_suspended();
  uint8_t flags=ctl::PONG_USB_STATUS;
  if(mounted) flags|=ctl::PONG_USB_MOUNTED;
  if(suspended) flags|=ctl::PONG_USB_SUSPENDED;
  if(mounted && !suspended) {
    flags|=ctl::PONG_USB_READY;
    if(hidState.keyboardRecent(now)) flags|=ctl::PONG_USB_KEY_TX;
    if(hidState.mouseRecent(now)) flags|=ctl::PONG_USB_MOUSE_TX;
  }
  if(hidState.fresh(now)) flags|=ctl::PONG_USB_CONTROL;
  return flags;
}

void updateUsb() {
  static bool mouseTurn=false;
  bool ready=tud_mounted() && !tud_suspended();
  if(!ready) { hidState.hostUnavailable(); return; }
  if(!transport.ready()) return; // endpoint busy: wait, do not block Wi-Fi processing
  uint32_t now=millis();
  bool k=hidState.wantKeyboard(now),m=hidState.wantMouse(now);
  // One transfer per loop iteration, alternating when both reports are pending.
  if(m && (!k || mouseTurn)) {
    uint8_t report[5]; hidState.mouseReport(report);
    bool ok=transport.SendReport(HID_REPORT_ID_MOUSE,report,sizeof(report),10);
    hidState.mouseDone(ok,millis()); mouseTurn=false;
  } else if(k) {
    uint8_t report[8]; hidState.keyboardReport(report);
    bool ok=transport.SendReport(HID_REPORT_ID_KEYBOARD,report,sizeof(report),10);
    hidState.keyboardDone(ok,millis()); mouseTurn=true;
  }
}
void logStatus() {
  static uint32_t lastLog=0;
  static uint8_t previous=0xFF;
  uint32_t now=millis(); uint8_t flags=usbStatus();
  // USB CDC is only for logging; opening Serial Monitor is NOT required for HID.
  if(Serial && (flags!=previous || (hidState.fresh(now) && now-lastLog>=1000))) {
    previous=flags; lastLog=now;
    Serial.printf("[USB] mounted=%u suspended=%u RX=%lu active=%u K_OK=%lu M_OK=%lu err=%lu modeErr=%lu k0=%02X mod=%02X dx=%d dy=%d mb=%u\n",
      !!(flags&ctl::PONG_USB_MOUNTED),!!(flags&ctl::PONG_USB_SUSPENDED),
      (unsigned long)hidState.controls,hidState.fresh(now),
      (unsigned long)hidState.keyOK,(unsigned long)hidState.mouseOK,
      (unsigned long)hidState.txErrors,(unsigned long)hidState.wrongMode,
      lastInput.keys[0],lastInput.modifiers,lastInput.dx,lastInput.dy,lastInput.mouseButtons);
  }
}
void setup() {
  Serial.begin(115200);
  USB.productName("ESP ConTL S3 HID");
  keyboard.begin(); mouse.begin(); transport.begin();
  USB.begin(); // Never wait for Serial/USB host before starting ESP-NOW.
  receiver.setStatusProvider(usbStatus);
  if(!receiver.begin("espH_USB-S3",ctl::ROLE_USB,onControl,stopOutputs)) {
    Serial.println("[ERROR] Receiver init failed"); while(true) delay(1000);
  }
}
void loop() {
  receiver.update(); // validate frames, update desired state, process ping and watchdog
  updateUsb();      // actual USB sends happen here, not in the receive handler
  logStatus();
  delay(1);
}
