#pragma once
#include "Protocol.h"

// Pure state/serialization layer: USB calls stay outside the ESP-NOW handler.
// Sizes match Arduino-ESP32 3.0.7 keyboard and relative-mouse descriptors (8 and 5 bytes).
class HidState {
 public:
  uint32_t controls=0,wrongMode=0,keyOK=0,mouseOK=0,txErrors=0;
  void neutral() {
    current_=ctl::HidReport{}; dx_=dy_=wheel_=0;
    dirtyKeys_=dirtyMouse_=true; hasControl_=false;
  }
  bool accept(const ctl::Packet &p,uint32_t now) {
    if(!(p.flags&ctl::FLAG_USB)) { wrongMode++; neutral(); return false; }
    if(current_.modifiers!=p.hid.modifiers || memcmp(current_.keys,p.hid.keys,6)) dirtyKeys_=true;
    if(current_.mouseButtons!=p.hid.mouseButtons) dirtyMouse_=true;
    current_=p.hid;
    dx_=constrain(dx_+(int)p.hid.dx,-127,127);
    dy_=constrain(dy_+(int)p.hid.dy,-127,127);
    wheel_=constrain(wheel_+(int)p.hid.wheel,-127,127);
    lastControl_=now; hasControl_=true; controls++; return true;
  }
  bool fresh(uint32_t now) const { return hasControl_ && now-lastControl_<=ctl::FAILSAFE_MS; }
  void hostUnavailable() {
    // Never replay a backlog of motion when the host resumes/reconnects.
    dx_=dy_=wheel_=0; dirtyKeys_=dirtyMouse_=true;
    keySuccess_=mouseSuccess_=false;
  }
  bool wantKeyboard(uint32_t now) const { return dirtyKeys_ || now-keyAt_>=250; }
  bool wantMouse(uint32_t now) const { return dirtyMouse_ || dx_ || dy_ || wheel_ || now-mouseAt_>=250; }
  void keyboardReport(uint8_t out[8]) const {
    out[0]=current_.modifiers; out[1]=0; memcpy(out+2,current_.keys,6);
  }
  void mouseReport(uint8_t out[5]) const {
    out[0]=current_.mouseButtons&0x1F; out[1]=(uint8_t)(int8_t)dx_;
    out[2]=(uint8_t)(int8_t)dy_; out[3]=(uint8_t)(int8_t)wheel_; out[4]=0; // pan
  }
  void keyboardDone(bool ok,uint32_t now) {
    if(ok) { keyOK++; dirtyKeys_=false; keyAt_=now; keySuccess_=true; }
    else { txErrors++; dirtyKeys_=true; }
  }
  void mouseDone(bool ok,uint32_t now) {
    // A timeout can occur AFTER transfer: do not retry relative deltas and double movement.
    dx_=dy_=wheel_=0;
    if(ok) { mouseOK++; dirtyMouse_=false; mouseAt_=now; mouseSuccess_=true; }
    else { txErrors++; dirtyMouse_=true; }
  }
  bool keyboardRecent(uint32_t now) const { return keySuccess_ && now-keyAt_<1000; }
  bool mouseRecent(uint32_t now) const { return mouseSuccess_ && now-mouseAt_<1000; }
 private:
  ctl::HidReport current_;
  int dx_=0,dy_=0,wheel_=0;
  bool dirtyKeys_=true,dirtyMouse_=true,hasControl_=false,keySuccess_=false,mouseSuccess_=false;
  uint32_t lastControl_=0,keyAt_=0,mouseAt_=0;
};
