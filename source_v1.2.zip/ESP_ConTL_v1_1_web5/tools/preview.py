#!/usr/bin/env python3
"""PC-only preview: static browser games, no simulated ESP board or saved Wi-Fi credentials."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import argparse
ROOT=Path(__file__).resolve().parents[1]/'web'
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
    def do_GET(self):
        if self.path=='/':
            self.send_response(302);self.send_header('Location','/?demo=1');self.end_headers();return
        super().do_GET()
    def end_headers(self):
        self.send_header('Cache-Control','no-cache')
        super().end_headers()
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=5173);args=parser.parse_args()
    print(f'PC keyboard preview: http://0.0.0.0:{args.port}/?demo=1',flush=True)
    ThreadingHTTPServer(('0.0.0.0',args.port),Handler).serve_forever()
