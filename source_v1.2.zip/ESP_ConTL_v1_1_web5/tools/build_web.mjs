import {transform} from 'esbuild';
import {readFile,writeFile} from 'node:fs/promises';
for(const name of ['app','games']){
 let source=await readFile(new URL('../web/src/'+name+'.js',import.meta.url),'utf8');
 if(name==='games')source=(await readFile(new URL('../web/src/extra_games.js',import.meta.url),'utf8'))+'\n'+source;
 if(name==='app')source=(await readFile(new URL('../web/src/wake_lock.js',import.meta.url),'utf8'))+'\n'+source;
 const result=await transform(source,{target:['chrome58','safari11'],format:'iife',charset:'utf8',legalComments:'inline',minify:false});
 await writeFile(new URL('../web/'+name+'.js',import.meta.url),'// Generated from web/src/'+name+'.js by npm run web.\n'+result.code);
}
let css=await readFile(new URL('../web/src/style.css',import.meta.url),'utf8');
css=css.replace(/#([0-9a-f]{8}|[0-9a-f]{4})\b/gi,(_,v)=>{if(v.length===4)v=v.split('').map(c=>c+c).join('');return `rgba(${parseInt(v.slice(0,2),16)},${parseInt(v.slice(2,4),16)},${parseInt(v.slice(4,6),16)},${+(parseInt(v.slice(6),16)/255).toFixed(3)})`;});
await writeFile(new URL('../web/style.css',import.meta.url),'/* Generated from web/src/style.css */\n'+css);
console.log('Built JS for Chrome 58 / Safari 11 syntax; CSS alpha-color fallbacks. Actual device support still needs testing.');
