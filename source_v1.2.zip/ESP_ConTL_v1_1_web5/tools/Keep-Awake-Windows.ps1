# Optional Windows-only helper. Run manually; nothing is installed or persisted.
# It asks Windows to keep display/system awake while this PowerShell process runs.
# Ctrl+C closes the request. OS/enterprise policies and closing the lid may override it.
$ErrorActionPreference = 'Stop'
if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
    throw 'This optional helper is for Windows only.'
}
if (-not ('ContlSessionPower' -as [type])) {
    Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class ContlSessionPower {
    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern UInt32 SetThreadExecutionState(UInt32 flags);
}
'@
}
Write-Host 'ESP ConTL: temporary display/system wake request.'
Write-Host 'Leave this window open while playing. Press Ctrl+C when finished.'
Write-Host 'No registry, power-plan, startup-task or browser changes are made.'
try {
    while ($true) {
        # ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
        $result = [ContlSessionPower]::SetThreadExecutionState([uint32]2147483651)
        if ($result -eq 0) { throw 'Windows rejected the wake request.' }
        Start-Sleep -Seconds 20
    }
}
finally {
    # Return this thread to normal execution requirements.
    [void][ContlSessionPower]::SetThreadExecutionState([uint32]2147483648)
}
